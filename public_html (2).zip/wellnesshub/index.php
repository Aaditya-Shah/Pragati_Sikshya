<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mental Sector Dashboard</title>
    
    <!-- Tailwind CSS -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- marked.js for rendering markdown responses in the chat -->
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    
    <!-- Google Fonts: Inter -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet">

    <style>
        /* --- Combined Styles from both files --- */

        /* Font setup */
        body {
            font-family: 'Inter', sans-serif;
        }
        
        /* --- Theme Variables from Wellbeing Hub (will apply to whole page) --- */
        :root {
            --bg-start: #e0f7fa; /* Light cyan */
            --bg-mid: #e1bee7;   /* Light purple */
            --bg-end: #dcedc8;     /* Light green */
            --card-bg: rgba(255, 255, 255, 0.6);
            --text-color: #1f2937; /* Gray-800 */
            --heading-color: #374151; /* Gray-700 */
            --border-color: rgba(0, 0, 0, 0.1);
            --shadow-color: rgba(128, 90, 213, 0.2);
            --shadow-hover-color: rgba(128, 90, 213, 0.4);
            --quote-bg: rgba(255, 255, 255, 0.5);
        }

        body.dark-mode {
            --bg-start: #0f172a; /* Slate-900 */
            --bg-mid: #1e293b;   /* Slate-800 */
            --bg-end: #334155;   /* Slate-700 */
            --card-bg: rgba(51, 65, 85, 0.6); /* Slate-700 with alpha */
            --text-color: #e2e8f0; /* Slate-200 */
            --heading-color: #f8fafc; /* Slate-50 */
            --border-color: rgba(255, 255, 255, 0.1);
            --shadow-color: rgba(99, 102, 241, 0.2);
            --shadow-hover-color: rgba(99, 102, 241, 0.4);
            --quote-bg: rgba(30, 41, 59, 0.5); /* Slate-800 with alpha */
        }
        
        /* --- General Styling from Wellbeing Hub --- */
        body {
            background: linear-gradient(135deg, var(--bg-start), var(--bg-mid), var(--bg-end));
            color: var(--text-color);
            transition: background 0.5s ease, color 0.5s ease;
            overflow-x: hidden;
        }

        /* --- Styles from Dashboard --- */
        .glass-card {
            background-color: rgba(255, 255, 255, 0.75);
            backdrop-filter: blur(16px) saturate(180%);
            -webkit-backdrop-filter: blur(16px) saturate(180%);
            border-radius: 1rem;
            border: 1px solid rgba(209, 213, 219, 0.3);
            box-shadow: 0 8px 32px 0 rgba(0, 0, 0, 0.15);
        }
        body.dark-mode .glass-card {
             background-color: rgba(30, 41, 59, 0.75);
             border: 1px solid rgba(71, 85, 105, 0.3);
        }

        .card {
            background-color: white;
            border-radius: 1rem;
            box-shadow: 0 4px 6px -1px rgb(0 0 0 / 0.1), 0 2px 4px -2px rgb(0 0 0 / 0.1);
            transition: all 0.3s ease;
        }
        .card:hover {
            transform: translateY(-4px);
            box-shadow: 0 10px 15px -3px rgb(0 0 0 / 0.1), 0 4px 6px -4px rgb(0 0 0 / 0.1);
        }
        .modal-overlay {
            position: fixed; top: 0; left: 0; right: 0; bottom: 0;
            background-color: rgba(0, 0, 0, 0.75);
            display: flex; align-items: center; justify-content: center;
            z-index: 50; opacity: 0; visibility: hidden;
            transition: opacity 0.3s ease, visibility 0.3s ease;
        }
        .modal-overlay.active { opacity: 1; visibility: visible; }
        .modal-content {
            background-color: #1f2937; border-radius: 1rem; padding: 1rem;
            width: 90%; max-width: 800px; position: relative;
        }
        .aspect-video { position: relative; width: 100%; padding-bottom: 56.25%; height: 0; }
        .aspect-video iframe { position: absolute; top: 0; left: 0; width: 100%; height: 100%; }
        .accordion-content {
            max-height: 0; overflow: hidden;
            transition: max-height 0.5s ease-out, padding 0.3s ease-out;
            padding: 0 1.5rem;
        }
        .accordion-icon { transition: transform 0.3s ease-in-out; }
        .accordion-trigger.active .accordion-icon { transform: rotate(180deg); }
        #chat-container { overflow-y: auto; border-radius: 0.5rem; padding: 1rem; background-color: rgba(255, 255, 255, 0.6); border: 1px solid rgba(209, 213, 219, 0.4); }
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: #f1f1f1; }
        ::-webkit-scrollbar-thumb { background: #888; border-radius: 10px; }
        ::-webkit-scrollbar-thumb:hover { background: #555; }
        .prose p { margin-bottom: 1rem; } .prose ul, .prose ol { margin-left: 1.5rem; } .prose li { margin-bottom: 0.5rem; }
        .prose pre { background-color: #1f2937; color: #f3f4f6; padding: 1rem; border-radius: 0.5rem; overflow-x: auto; }
        .prose code { background-color: #e5e7eb; padding: 0.125rem 0.25rem; border-radius: 0.25rem; font-family: monospace; }
        .prose pre code { background-color: transparent; padding: 0; }

        /* --- Styles from Wellbeing Hub --- */
        .glowing-title {
            background: linear-gradient(90deg, #84fab0, #8fd3f4, #a18cd1, #fbc2eb);
            -webkit-background-clip: text; background-clip: text; color: transparent;
            animation: gradient-flow 10s ease infinite; background-size: 400% 400%;
            filter: drop-shadow(0 0 15px rgba(161, 140, 209, 0.5));
        }
        @keyframes gradient-flow { 0% { background-position: 0% 50%; } 50% { background-position: 100% 50%; } 100% { background-position: 0% 50%; } }
        .exercise-card {
            background: var(--card-bg); backdrop-filter: blur(10px); -webkit-backdrop-filter: blur(10px);
            border: 1px solid var(--border-color); box-shadow: 0 10px 25px -5px var(--shadow-color);
            transition: transform 0.3s ease, box-shadow 0.3s ease; opacity: 0;
            transform: translateY(30px); animation: fade-in-up 0.6s forwards;
        }
        .exercise-card:hover { transform: translateY(-8px); box-shadow: 0 20px 35px -10px var(--shadow-hover-color); }
        .exercise-instructions { max-height: 0; overflow: hidden; transition: max-height 0.7s cubic-bezier(0.4, 0, 0.2, 1); }
        .exercise-instructions.expanded { max-height: 500px; }
        #quote-banner { transition: opacity 0.5s ease-in-out; }
        @keyframes fade-in-up { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        .visible { animation: fade-in-up 0.6s forwards; }
        .toggle-switch { position: relative; display: inline-block; width: 50px; height: 28px; }
        .toggle-switch input { opacity: 0; width: 0; height: 0; }
        .slider { position: absolute; cursor: pointer; top: 0; left: 0; right: 0; bottom: 0; background-color: #7f9cf5; transition: .4s; border-radius: 28px; }
        .slider:before { position: absolute; content: "☀️"; height: 20px; width: 20px; left: 4px; bottom: 4px; background-color: white; transition: .4s; border-radius: 50%; display: flex; align-items: center; justify-content: center; font-size: 12px; }
        input:checked + .slider { background-color: #4a5568; }
        input:checked + .slider:before { transform: translateX(22px); content: "🌙"; }
        .timer-modal { background: var(--card-bg); backdrop-filter: blur(10px); }
    </style>
</head>
<body class="p-4 sm:p-6 lg:p-8 transition-colors duration-500">
    <div class="max-w-7xl mx-auto">
        <header class="mb-8 text-center">
            <div class="flex items-center justify-center gap-3">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-12 w-12 text-blue-600" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.5">
                    <path stroke-linecap="round" stroke-linejoin="round" d="M4.874 5.126c.36-.592.959-1.013 1.62-1.258C7.156 3.628 7.87 3.5 8.625 3.5c.755 0 1.469.128 2.13.368.66.245 1.259.666 1.62 1.258.36.592.54 1.26.54 1.984 0 .724-.18 1.392-.54 1.984-.36.592-.96 1.013-1.62 1.258-.66.24-1.375.36-2.13.36-.755 0-1.469-.12-2.13-.36-.66-.245-1.26-.666-1.62-1.258-.36-.592-.54-1.26-.54-1.984 0-.724.18-1.392.54-1.984z"></path>
                    <path stroke-linecap="round" stroke-linejoin="round" d="M15.375 3.5c.755 0 1.469.128 2.13.368.66.245 1.259.666 1.62 1.258.36.592.54 1.26.54 1.984 0 .724-.18 1.392-.54 1.984-.36.592-.96 1.013-1.62 1.258-.66.24-1.375.36-2.13.36a4.48 4.48 0 01-3.375-1.625M8.625 12.5a4.482 4.482 0 003.375 1.625c.755 0 1.469-.128 2.13-.368.66.245 1.259.666 1.62-1.258m-6.345 5.25a4.482 4.482 0 003.375-1.625c.71-.933 1.066-2.012 1.066-3.225m-9.75 3.938c1.23-.933 2.64-1.5 4.125-1.5s2.895.567 4.125 1.5M4.5 15.25a8.96 8.96 0 00-1.625 3.375c-.245.66-.368 1.375-.368 2.13s.123 1.47.368 2.13a4.503 4.503 0 001.625 3.375m15-11.25a8.96 8.96 0 011.625 3.375c.245.66.368 1.375.368 2.13s-.123 1.47-.368 2.13a4.503 4.503 0 01-1.625 3.375"></path>
                </svg>
                <h1 class="text-5xl font-bold bg-gradient-to-r from-teal-600 to-blue-700 bg-clip-text text-transparent">Mental Sector</h1>
            </div>
            <p class="mt-2 text-lg" style="color: var(--heading-color)">Your personal space for wellness and focus.</p>
        </header>

        <main class="space-y-4" id="accordion-container">
            <div class="glass-card overflow-hidden">
                <button class="accordion-trigger w-full text-left p-6 flex justify-between items-center hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2 transition-colors">
                    <span class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-teal-600 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
                        </svg>
                        <span class="text-xl font-bold" style="color: var(--heading-color);">Mental Health Info</span>
                    </span>
                    <svg class="accordion-icon h-6 w-6" style="color: var(--heading-color);" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="accordion-content">
                    <div class="pb-6">
                        <div class="space-y-4">
                            <p>Mental health is about your emotional, psychological, and social well-being—it affects how you think, feel, and deal with stress. Good mental health helps with learning by improving focus, memory, and motivation, making it easier to absorb new information and succeed in school or work. On the flip side, issues like anxiety or depression can cause trouble concentrating, low energy, and missed opportunities. Factors like family support, exercise, and a positive environment play a big role in building strong mental health.</p>
                            <h3 class="text-xl font-semibold pt-2" style="color: var(--heading-color);">Relation to Learning</h3>
                            <p>Strong mental health boosts learning by sharpening concentration, creativity, and problem-solving skills, leading to better grades and personal growth. Poor mental health, however, can lead to absenteeism, forgetfulness, and low motivation, creating barriers to education. To bridge this, schools and communities should promote early support, reduce stigma around mental health, and integrate emotional care with learning for overall success.</p>
                        </div>
                    </div>
                </div>
            </div>

            <div class="glass-card overflow-hidden">
                <button class="accordion-trigger w-full text-left p-6 flex justify-between items-center hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2 transition-colors">
                    <span class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-teal-600 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M9 19V6l12-3v13M9 19c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zm12-3c0 1.105-1.343 2-3 2s-3-.895-3-2 1.343-2 3-2 3 .895 3 2zM9 6l12-3" />
                        </svg>
                        <span class="text-xl font-bold" style="color: var(--heading-color);">Music Therapy Sector</span>
                    </span>
                    <svg class="accordion-icon h-6 w-6" style="color: var(--heading-color);" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="accordion-content">
                    <div class="pb-6 pt-2 space-y-8">
                        <section id="music-therapy">
                            <div id="music-cards-container" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"></div>
                        </section>
                        <section id="reviews" class="bg-white/50 dark:bg-slate-800/20 rounded-xl p-6 md:p-8 border border-slate-100/50 dark:border-slate-700/50 shadow-inner">
                            <h2 class="text-3xl font-bold mb-6" style="color: var(--heading-color);">Leave a Review</h2>
                            <form id="review-form" class="space-y-4">
                                <div>
                                    <label for="music-select" class="block text-sm font-medium">Select Music</label>
                                    <select id="music-select" name="music-select" class="mt-1 block w-full pl-3 pr-10 py-2 text-base border-slate-300 focus:outline-none focus:ring-indigo-500 focus:border-indigo-500 sm:text-sm rounded-md"></select>
                                </div>
                                <div>
                                    <label for="rating" class="block text-sm font-medium">Rating</label>
                                    <div class="flex items-center mt-1" id="star-rating"></div>
                                    <input type="hidden" id="rating-value" name="rating" value="0">
                                </div>
                                <div>
                                    <label for="review-text" class="block text-sm font-medium">Review</label>
                                    <textarea id="review-text" name="review-text" rows="3" class="mt-1 shadow-sm focus:ring-indigo-500 focus:border-indigo-500 block w-full sm:text-sm border border-slate-300 rounded-md p-2" placeholder="Share your thoughts..."></textarea>
                                </div>
                                <button type="submit" class="inline-flex justify-center py-2 px-4 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">Submit Review</button>
                            </form>
                            <div id="review-list" class="mt-8">
                                <h3 class="text-2xl font-bold mb-4" style="color: var(--heading-color);">Community Reviews</h3>
                                <div id="reviews-container" class="space-y-4">
                                    <p>Loading reviews...</p>
                                </div>
                            </div>
                        </section>
                    </div>
                </div>
            </div>

            <!-- New Energy HUB Accordion -->
            <div class="glass-card overflow-hidden">
                <button class="accordion-trigger w-full text-left p-6 flex justify-between items-center hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2 transition-colors">
                    <span class="flex items-center">
                         <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-teal-600 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                           <path stroke-linecap="round" stroke-linejoin="round" d="M13 10V3L4 14h7v7l9-11h-7z" />
                         </svg>
                        <span class="text-xl font-bold" style="color: var(--heading-color);">Energy HUB</span>
                    </span>
                    <svg class="accordion-icon h-6 w-6" style="color: var(--heading-color);" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="accordion-content">
                    <div class="w-full p-4 sm:p-6 lg:p-8">
                        <header class="flex justify-between items-center mb-6">
                            <div id="quote-banner" class="text-center md:text-left text-sm sm:text-base p-3 rounded-lg flex-grow" style="background: var(--quote-bg);">
                                <span class="font-medium">A healthy mind creates a powerful future.</span>
                            </div>
                            <div class="ml-4 flex-shrink-0">
                                <label class="toggle-switch">
                                    <input type="checkbox" id="theme-toggle">
                                    <span class="slider"></span>
                                </label>
                            </div>
                        </header>
                        <main>
                            <h1 class="glowing-title text-4xl sm:text-5xl md:text-6xl font-bold text-center mb-4">Mental Wellbeing Exercises</h1>
                            <p class="text-center max-w-2xl mx-auto mb-8 text-base sm:text-lg" style="color: var(--heading-color);">Discover simple exercises to calm your mind, reduce stress, and improve your focus.</p>
                            <div class="flex justify-center mb-10">
                                <div class="relative w-full max-w-md">
                                    <input type="text" id="search-input" placeholder="Search for an exercise..." class="w-full py-3 px-5 pr-12 rounded-full border-2 transition-all duration-300 focus:ring-4 focus:outline-none" style="background: var(--card-bg); border-color: var(--border-color); color: var(--text-color); --tw-ring-color: var(--shadow-hover-color);">
                                    <svg class="absolute right-4 top-1/2 -translate-y-1/2 h-5 w-5" style="color: var(--text-color);" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                                </div>
                            </div>
                            <div id="exercise-grid" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"></div>
                            <p id="no-results" class="text-center text-xl mt-8 hidden" style="color: var(--heading-color);">No exercises found. Try another search!</p>
                        </main>
                    </div>
                </div>
            </div>

            <div class="glass-card overflow-hidden">
                <button class="accordion-trigger w-full text-left p-6 flex justify-between items-center hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2 transition-colors">
                    <span class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-teal-600 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M11 4a2 2 0 114 0v1a1 1 0 001 1h3a1 1 0 011 1v3a1 1 0 01-1 1h-1a2 2 0 100 4h1a1 1 0 011 1v3a1 1 0 01-1 1h-3a1 1 0 01-1-1v-1a2 2 0 10-4 0v1a1 1 0 01-1 1H7a1 1 0 01-1-1v-3a1 1 0 00-1-1H4a2 2 0 110-4h1a1 1 0 001-1V7a1 1 0 011-1h3a1 1 0 001-1V4z" />
                        </svg>
                        <span class="text-xl font-bold" style="color: var(--heading-color);">Mental Agility Test</span>
                    </span>
                    <svg class="accordion-icon h-6 w-6" style="color: var(--heading-color);" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="accordion-content">
                    <div class="p-6">
                        <h3 class="text-xl font-semibold" style="color: var(--heading-color);">Challenge Your Mind</h3>
                        <p class="mt-2 mb-4">This test is designed to measure your logic, reasoning, and problem-solving skills under a time limit. Click the button below to proceed to the test.</p>
                        <a href="trail-anik.php" class="inline-flex justify-center py-2 px-6 border border-transparent shadow-sm text-sm font-medium rounded-md text-white bg-teal-600 hover:bg-teal-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-teal-500">Start the Test</a>
                    </div>
                </div>
            </div>

            <div class="glass-card overflow-hidden">
                <button class="accordion-trigger w-full text-left p-6 flex justify-between items-center hover:bg-white/20 focus:outline-none focus-visible:ring-2 focus-visible:ring-indigo-500 focus-visible:ring-offset-2 transition-colors">
                    <span class="flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 text-teal-600 mr-4" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M8 10h.01M12 10h.01M16 10h.01M9 16H5a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v8a2 2 0 01-2 2h-5l-5 5v-5z" />
                        </svg>
                        <span class="text-xl font-bold" style="color: var(--heading-color);">Gemini Chat Assistant</span>
                    </span>
                    <svg class="accordion-icon h-6 w-6" style="color: var(--heading-color);" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 9l-7 7-7-7" />
                    </svg>
                </button>
                <div class="accordion-content">
                    <div class="p-6 flex flex-col" style="height: 60vh;">
                        <div id="chat-container" class="flex-1 p-4 mb-4 rounded-lg bg-gray-50 dark:bg-gray-700 overflow-y-auto"></div>
                        <div id="loading" class="hidden p-2 text-sm text-gray-500 dark:text-gray-400">
                            <div class="flex items-center space-x-2">
                                <div class="w-2 h-2 rounded-full bg-gray-500 animate-pulse"></div>
                                <div class="w-2 h-2 rounded-full bg-gray-500 animate-pulse [animation-delay:0.2s]"></div>
                                <div class="w-2 h-2 rounded-full bg-gray-500 animate-pulse [animation-delay:0.4s]"></div>
                                <span>Gemini is thinking...</span>
                            </div>
                        </div>
                        <div id="error-display" class="hidden px-2 pb-2 text-sm text-red-500"></div>
                        <div class="relative">
                            <input type="text" id="user-input" class="w-full pl-4 pr-12 py-3 bg-gray-100 dark:bg-gray-700 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300" placeholder="Type your message...">
                            <button id="send-button" class="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-transform duration-200 active:scale-90">
                                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" /></svg>
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>

    <!-- Modals from both files -->
    <div id="video-modal" class="modal-overlay">
        <div class="modal-content">
            <button id="close-modal" class="absolute -top-4 -right-4 text-white bg-slate-700 rounded-full p-1 focus:outline-none focus:ring-2 focus:ring-white">
                <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
            </button>
            <div id="youtube-player-container" class="aspect-video"></div>
        </div>
    </div>
    <div id="timer-modal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50 hidden">
        <div class="timer-modal w-full max-w-sm text-center p-8 rounded-2xl shadow-2xl border" style="border-color: var(--border-color);">
            <h2 id="timer-title" class="text-2xl font-bold mb-2" style="color: var(--heading-color);"></h2>
            <p class="text-7xl font-mono font-bold my-6" id="timer-display">00:00</p>
            <div id="timer-message" class="text-xl font-semibold mb-6 h-8"></div>
            <button id="close-timer" class="w-full bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-3 px-4 rounded-lg transition-transform transform hover:scale-105">Close</button>
        </div>
    </div>

    <!-- Dashboard Script -->
    <script type="module">
        import { initializeApp } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-app.js";
        import { getFirestore, collection, addDoc, onSnapshot, query, orderBy } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-firestore.js";
        import { getAuth, signInAnonymously, onAuthStateChanged, signInWithCustomToken } from "https://www.gstatic.com/firebasejs/11.6.1/firebase-auth.js";
        
        document.addEventListener('DOMContentLoaded', () => {

            // --- Firebase Configuration ---
            const firebaseConfig = typeof __firebase_config !== 'undefined' 
                ? JSON.parse(__firebase_config)
                : {
                    apiKey: "AIzaSyYOUR_API_KEY",
                    authDomain: "your-project-id.firebaseapp.com",
                    projectId: "your-project-id",
                    storageBucket: "your-project-id.appspot.com",
                    messagingSenderId: "your-sender-id",
                    appId: "your-app-id"
                };

            const appId = typeof __app_id !== 'undefined' ? __app_id : 'default-app-id';
            
            let db;
            let auth;
            let userId;

            try {
               const app = initializeApp(firebaseConfig);
               db = getFirestore(app);
               auth = getAuth(app);
            } catch(e) {
                console.error("Firebase initialization failed. Using mock data. Error:", e);
                db = null;
                auth = null;
            }


            // --- Music Data (mock database) ---
            const musicTherapyData = [
                { id: 1, name: "Deep Sleep Ambient", purpose: "Helps improve deep sleep, reduces insomnia", link: "https://www.youtube.com/watch?v=1ZYbU82GVz4", frequency: "432 Hz" },
                { id: 2, name: "Relaxing Rain Sounds", purpose: "Reduces stress and anxiety, calming background", link: "https://www.youtube.com/watch?v=e3L6bS1-7k8", frequency: "528 Hz" },
                { id: 3, name: "Meditation Music for Mindfulness", purpose: "Enhances focus, meditation, and mental clarity", link: "https://www.youtube.com/watch?v=inpok4MKVLM", frequency: "528 Hz" },
                { id: 4, name: "Motivational Study Beats", purpose: "Boosts concentration and productivity while studying", link: "https://www.youtube.com/watch?v=WPni755-Krg", frequency: "440 Hz" },
                { id: 5, name: "Morning Energy Uplift", purpose: "Increases motivation and positive mindset", link: "https://www.youtube.com/watch?v=2Lz0VOltZKA", frequency: "440 Hz" },
                { id: 6, name: "Calming Ocean Waves", purpose: "Stress relief and relaxation", link: "https://www.youtube.com/watch?v=OdIJ2x3nxzQ", frequency: "528 Hz" },
                { id: 7, name: "432Hz Healing Music", purpose: "Restores inner balance, improves mood", link: "https://www.youtube.com/watch?v=1ZYbU82GVz4", frequency: "432 Hz" },
                { id: 8, name: "Focus & Concentration Instrumental", purpose: "Enhances learning efficiency and attention span", link: "https://www.youtube.com/watch?v=WPni755-Krg", frequency: "440 Hz" },
                { id: 9, name: "Guided Sleep Meditation", purpose: "Helps fall asleep faster, improves sleep quality", link: "https://www.youtube.com/watch?v=2OEL4P1Rz04", frequency: "432 Hz" },
                { id: 10, name: "Stress Relief Piano Music", purpose: "Reduces anxiety, promotes calmness", link: "https://www.youtube.com/watch?v=lFcSrYw-ARY", frequency: "528 Hz" }
            ];

            const musicCardsContainer = document.getElementById('music-cards-container');
            const musicSelect = document.getElementById('music-select');

            // --- Render Music Cards ---
            function renderMusicCards() {
                if (!musicCardsContainer) return;
                musicCardsContainer.innerHTML = '';
                musicTherapyData.forEach(music => {
                    const card = document.createElement('div');
                    card.className = 'card p-6 flex flex-col justify-between';
                    card.innerHTML = `
                        <div>
                            <div class="flex justify-between items-start mb-2">
                                <h3 class="text-xl font-bold text-slate-800">${music.name}</h3>
                                <span class="text-sm font-semibold text-indigo-600 bg-indigo-100 px-2 py-1 rounded-full">${music.frequency}</span>
                            </div>
                            <p class="text-slate-500 mb-4">${music.purpose}</p>
                        </div>
                        <button data-video-id="${getYouTubeID(music.link)}" class="play-button w-full mt-2 bg-slate-800 text-white font-semibold py-2 px-4 rounded-lg hover:bg-slate-900 transition-colors flex items-center justify-center">
                            <svg xmlns="http://www.w3.org/2000/svg" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" class="mr-2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg>
                            Play
                        </button>
                    `;
                    musicCardsContainer.appendChild(card);
                });
            }
            
            // --- Populate Music Select for Reviews ---
            function populateMusicSelect() {
                if (!musicSelect) return;
                musicTherapyData.forEach(music => {
                    const option = document.createElement('option');
                    option.value = music.name;
                    option.textContent = music.name;
                    musicSelect.appendChild(option);
                });
            }

            // --- YouTube Video Modal Logic ---
            const videoModal = document.getElementById('video-modal');
            const closeModalButton = document.getElementById('close-modal');
            const youtubePlayerContainer = document.getElementById('youtube-player-container');
            
            document.body.addEventListener('click', (e) => {
                const button = e.target.closest('.play-button');
                if (button && videoModal && youtubePlayerContainer) {
                    const videoId = button.dataset.videoId;
                    youtubePlayerContainer.innerHTML = `<iframe src="https://www.youtube.com/embed/${videoId}?autoplay=1" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>`;
                    videoModal.classList.add('active');
                }
            });

            function closeModal() {
                 if (youtubePlayerContainer && videoModal) {
                    youtubePlayerContainer.innerHTML = '';
                    videoModal.classList.remove('active');
                }
            }
            if(closeModalButton) closeModalButton.addEventListener('click', closeModal);
            if(videoModal) videoModal.addEventListener('click', (e) => {
                if (e.target === videoModal) {
                    closeModal();
                }
            });

            function getYouTubeID(url) {
                const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|\&v=)([^#\&\?]*).*/;
                const match = url.match(regExp);
                return (match && match[2].length === 11) ? match[2] : null;
            }
            
            // --- Star Rating Logic ---
            const starRatingContainer = document.getElementById('star-rating');
            const ratingValueInput = document.getElementById('rating-value');
            if (starRatingContainer && ratingValueInput) {
                for (let i = 1; i <= 5; i++) {
                    const star = document.createElement('span');
                    star.innerHTML = `<svg class="w-8 h-8 cursor-pointer" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M11.049 2.927c.3-.921 1.603-.921 1.902 0l1.519 4.674a1 1 0 00.95.69h4.915c.969 0 1.371 1.24.588 1.81l-3.976 2.888a1 1 0 00-.363 1.118l1.518 4.674c.3.922-.755 1.688-1.539 1.118l-3.975-2.888a1 1 0 00-1.175 0l-3.976 2.888c-.783.57-1.838-.196-1.539-1.118l1.518-4.674a1 1 0 00-.363-1.118l-3.976-2.888c-.783-.57-.38-1.81.588-1.81h4.914a1 1 0 00.951-.69l1.519-4.674z"></path></svg>`;
                    star.dataset.value = i;
                    star.classList.add('star', 'text-slate-300');
                    starRatingContainer.appendChild(star);
                }

                const stars = document.querySelectorAll('.star');
                starRatingContainer.addEventListener('click', e => {
                    const star = e.target.closest('.star');
                    if (!star) return;
                    const rating = star.dataset.value;
                    ratingValueInput.value = rating;
                    stars.forEach(s => {
                        s.classList.remove('text-amber-400');
                        s.classList.add('text-slate-300');
                        if (s.dataset.value <= rating) {
                            s.classList.add('text-amber-400');
                            s.classList.remove('text-slate-300');
                        }
                    });
                });
            }

            // --- Review Form Submission ---
            const reviewForm = document.getElementById('review-form');
            if (reviewForm) {
                reviewForm.addEventListener('submit', async (e) => {
                    e.preventDefault();
                    if(!db || !auth.currentUser) {
                        const reviewSection = document.getElementById('reviews');
                        let msg = document.createElement('p');
                        msg.textContent = "You must be signed in to leave a review.";
                        msg.className = "text-red-500 text-sm mt-2";
                        if(!reviewSection.querySelector('.text-red-500')) {
                           reviewForm.appendChild(msg);
                           setTimeout(()=> msg.remove(), 3000);
                        }
                        return;
                    }
                    const musicName = musicSelect.value;
                    const rating = parseInt(ratingValueInput.value);
                    const reviewText = document.getElementById('review-text').value;

                    if (rating === 0 || !reviewText.trim()) {
                        const reviewSection = document.getElementById('reviews');
                        let msg = document.createElement('p');
                        msg.textContent = "Please provide a rating and a review.";
                        msg.className = "text-red-500 text-sm mt-2";
                        if(!reviewSection.querySelector('.text-red-500.review-error')) {
                            reviewForm.appendChild(msg);
                            setTimeout(()=> msg.remove(), 3000);
                        }
                        return;
                    }
                    try {
                        const reviewsCollectionPath = `/artifacts/${appId}/public/data/music_reviews`;
                        await addDoc(collection(db, reviewsCollectionPath), {
                            musicName,
                            rating,
                            reviewText,
                            createdAt: new Date(),
                            userId: auth.currentUser.uid,
                        });
                        reviewForm.reset();
                        document.querySelectorAll('.star').forEach(s => s.classList.replace('text-amber-400', 'text-slate-300'));
                        ratingValueInput.value = 0;
                    } catch (error) {
                        console.error("Error adding document: ", error);
                        const reviewSection = document.getElementById('reviews');
                        let msg = document.createElement('p');
                        msg.textContent = "Failed to submit review. Please try again.";
                        msg.className = "text-red-500 text-sm mt-2";
                        if(!reviewSection.querySelector('.text-red-500.review-error')) {
                            reviewForm.appendChild(msg);
                            setTimeout(()=> msg.remove(), 3000);
                        }
                    }
                });
            }
            
            // --- Render Reviews ---
            const reviewsContainer = document.getElementById('reviews-container');
            function renderReviews(reviews) {
                 if (!reviewsContainer) return;
                reviewsContainer.innerHTML = '';
                if (reviews.length === 0) {
                    reviewsContainer.innerHTML = '<p class="text-slate-500">No reviews yet. Be the first to share your thoughts!</p>';
                    return;
                }
                reviews.forEach(review => {
                    const reviewCard = document.createElement('div');
                    reviewCard.className = 'p-4 border-t border-slate-200/50';
                    const starsHTML = Array(5).fill(0).map((_, i) => `
                        <svg class="w-5 h-5 ${i < review.rating ? 'text-amber-400' : 'text-slate-300'}" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg"><path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"></path></svg>
                    `).join('');
                    reviewCard.innerHTML = `
                        <div class="flex items-center justify-between">
                            <h4 class="font-bold text-slate-700">${review.musicName}</h4>
                            <div class="flex">${starsHTML}</div>
                        </div>
                        <p class="text-slate-600 mt-2">"${review.reviewText}"</p>
                    `;
                    reviewsContainer.appendChild(reviewCard);
                });
            }
            
            // --- Authentication and Firestore Listener ---
            async function setupFirebase() {
                if (!auth) {
                    if(reviewsContainer) reviewsContainer.innerHTML = '<p class="text-slate-500 bg-yellow-100 p-4 rounded-lg">Could not connect to the review database. Displaying reviews is currently unavailable.</p>';
                    return;
                }

                onAuthStateChanged(auth, (user) => {
                    if (user) {
                        userId = user.uid;
                        const reviewsCollectionPath = `/artifacts/${appId}/public/data/music_reviews`;
                        const q = query(collection(db, reviewsCollectionPath), orderBy("createdAt", "desc"));
                        onSnapshot(q, (querySnapshot) => {
                            const reviews = [];
                            querySnapshot.forEach((doc) => {
                                reviews.push({ id: doc.id, ...doc.data() });
                            });
                            renderReviews(reviews);
                        }, (error) => {
                            console.error("Error with snapshot listener:", error);
                            if(reviewsContainer) reviewsContainer.innerHTML = `<p class="text-red-500 bg-red-100 p-4 rounded-lg">Error loading reviews: ${error.message}</p>`;
                        });
                    } else {
                        userId = null;
                    }
                });

                if (!auth.currentUser) {
                    try {
                        if (typeof __initial_auth_token !== 'undefined' && __initial_auth_token) {
                            await signInWithCustomToken(auth, __initial_auth_token);
                        } else {
                            await signInAnonymously(auth);
                        }
                    } catch (error) {
                        console.error("Anonymous sign-in failed:", error);
                    }
                }
            }
            
            // --- Accordion Logic ---
            const accordionTriggers = document.querySelectorAll('.accordion-trigger');
            accordionTriggers.forEach(trigger => {
                trigger.addEventListener('click', () => {
                    const content = trigger.nextElementSibling;
                    const isAlreadyOpen = trigger.classList.contains('active');

                    accordionTriggers.forEach(otherTrigger => {
                        if (otherTrigger !== trigger) {
                            otherTrigger.classList.remove('active');
                            otherTrigger.nextElementSibling.style.maxHeight = null;
                            otherTrigger.nextElementSibling.style.paddingTop = null;
                            otherTrigger.nextElementSibling.style.paddingBottom = null;
                        }
                    });
                    
                    if (isAlreadyOpen) {
                        trigger.classList.remove('active');
                        content.style.maxHeight = null;
                        content.style.paddingTop = null;
                        content.style.paddingBottom = null;
                    } else {
                        trigger.classList.add('active');
                        content.style.maxHeight = content.scrollHeight + "px";
                        if (content.querySelector('div')) {
                            content.style.paddingTop = '1.5rem';
                            content.style.paddingBottom = '1.5rem';
                        }
                    }
                });
            });


            // --- Chat Box Logic ---
            const chatContainer = document.getElementById('chat-container');
            const userInput = document.getElementById('user-input');
            const sendButton = document.getElementById('send-button');
            const loadingIndicator = document.getElementById('loading');
            const errorDisplay = document.getElementById('error-display');

            const GEMINI_API_KEY = "AIzaSyDDg1BZqVWCxkl0nPj1l5s7NgIrwYxq3XE"; 
            const GEMINI_API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${GEMINI_API_KEY}`;
            
            let conversationHistory = [];

            // Function to render messages to the UI
            const renderMessages = () => {
                if(!chatContainer) return;
                chatContainer.innerHTML = '';
                conversationHistory.forEach(message => {
                    const messageElement = document.createElement('div');
                    messageElement.classList.add('mb-4', 'flex', 'flex-col');
                    
                    const bubble = document.createElement('div');
                    bubble.classList.add('p-3', 'rounded-lg', 'max-w-xs', 'md:max-w-md', 'lg:max-w-lg', 'break-words');
                    
                    bubble.classList.add('prose', 'prose-sm', 'dark:prose-invert');
                    bubble.innerHTML = marked.parse(message.parts[0].text);

                    if (message.role === 'user') {
                        messageElement.classList.add('items-end');
                        bubble.classList.add('bg-blue-500', 'text-white', 'rounded-br-none');
                    } else {
                        messageElement.classList.add('items-start');
                        bubble.classList.add('bg-gray-200', 'dark:bg-gray-700', 'text-gray-900', 'dark:text-gray-100', 'rounded-bl-none', 'border', 'border-gray-300', 'shadow-md');
                    }
                    
                    messageElement.appendChild(bubble);
                    chatContainer.appendChild(messageElement);
                });
                chatContainer.scrollTop = chatContainer.scrollHeight;
            };

            // Function to handle API call with exponential backoff
            const callGeminiAPI = async (prompt, retries = 3, delay = 1000) => {
                if(loadingIndicator) loadingIndicator.classList.remove('hidden');
                if(errorDisplay) errorDisplay.classList.add('hidden');
                
                try {
                    const payload = {
                        contents: [...conversationHistory, { role: 'user', parts: [{ text: prompt }] }]
                    };

                    const response = await fetch(GEMINI_API_URL, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(payload)
                    });

                    if (!response.ok) {
                        const errorData = await response.json();
                        throw new Error(errorData.error ? errorData.error.message : `HTTP error! status: ${response.status}`);
                    }

                    const data = await response.json();
                    
                    if (data.candidates && data.candidates.length > 0 && data.candidates[0].content) {
                        const botMessage = data.candidates[0].content;
                        conversationHistory.push(botMessage);
                        renderMessages();
                    } else {
                       const blockReason = data.promptFeedback?.blockReason;
                       let errorMessage = "I'm sorry, I can't provide a response to that.";
                       if(blockReason) {
                           errorMessage += ` (Reason: ${blockReason})`;
                       }
                       displayChatError(errorMessage);
                    }

                } catch (error) {
                    if (retries > 0) {
                        await new Promise(res => setTimeout(res, delay));
                        return callGeminiAPI(prompt, retries - 1, delay * 2);
                    } else {
                        console.error('Error calling Gemini API:', error);
                        displayChatError(`Failed to get a response after multiple attempts. Please check your connection or API key. Error: ${error.message}`);
                    }
                } finally {
                    if(loadingIndicator) loadingIndicator.classList.add('hidden');
                }
            };

            const displayChatError = (message) => {
                  const botMessage = { role: 'model', parts: [{ text: `*Error:* ${message}` }] };
                  conversationHistory.push(botMessage);
                  renderMessages();
            };

            // Function to handle user input
            const handleUserInput = async () => {
                const prompt = userInput.value.trim();
                if (!prompt) return;

                const userMessage = { role: 'user', parts: [{ text: prompt }] };
                conversationHistory.push(userMessage);
                renderMessages();

                userInput.value = '';
                
                await callGeminiAPI(prompt);
            };

            // Event listeners for chat
            if(sendButton) sendButton.addEventListener('click', handleUserInput);
            if(userInput) userInput.addEventListener('keydown', (e) => {
                if (e.key === 'Enter') {
                    e.preventDefault();
                    handleUserInput();
                }
            });

            // Initial welcome message for chat
            const addWelcomeMessage = () => {
                const welcomeMessage = {
                    role: 'model',
                    parts: [{ text: "Hello! I'm your Mental Sector chat assistant, powered by Gemini. How can I assist you with your mental wellness today?" }]
                };
                conversationHistory.push(welcomeMessage);
                renderMessages();
            };

            // --- Initial Load ---
            renderMusicCards();
            populateMusicSelect();
            setupFirebase();
            addWelcomeMessage(); // Initialize chat with welcome message
        });
    </script>

    <!-- Wellbeing Hub Script -->
    <script>
        document.addEventListener('DOMContentLoaded', () => {

            // --- DATA ---
            const exercises = [
                {
                    name: 'Deep Breathing',
                    duration: 5,
                    instructions: [
                        "Find a comfortable, quiet place to sit or lie down.",
                        "Close your eyes gently. Place one hand on your belly and the other on your chest.",
                        "Inhale slowly through your nose for a count of 4, feeling your belly expand. Your chest should move very little.",
                        "Hold your breath for a count of 4.",
                        "Exhale slowly through your mouth for a count of 6, feeling your belly fall.",
                        "Repeat this cycle for 5 minutes, focusing on the sensation of your breath."
                    ]
                },
                {
                    name: 'Gratitude Writing',
                    duration: 10,
                    instructions: [
                        "Find a notebook and a pen, or open a new document on your computer.",
                        "Set a timer for 10 minutes.",
                        "Think of at least three specific things you are grateful for today. They can be big or small.",
                        "For each item, write a few sentences about why you are grateful for it. Describe the feeling it gives you.",
                        "Don't worry about grammar or spelling. Just let your thoughts flow freely.",
                        "When the time is up, read over your list and let the positive feelings sink in."
                    ]
                },
                {
                    name: 'Mindful Walking',
                    duration: 15,
                    instructions: [
                        "Find a place where you can walk without distractions, either indoors or outdoors.",
                        "Begin to walk at a slow, natural pace.",
                        "Pay close attention to the sensation of your feet touching the ground. Notice the heel, the ball of the foot, and the toes.",
                        "Focus on the rhythm of your steps and your breath.",
                        "If your mind wanders, gently guide it back to the physical sensation of walking.",
                        "Engage your other senses. What do you see, hear, or smell? Acknowledge it without judgment."
                    ]
                },
                {
                    name: 'Progressive Muscle Relaxation',
                    duration: 15,
                    instructions: [
                        "Lie down on your back in a comfortable position.",
                        "Start with your feet. Tense all the muscles in your feet and toes, squeezing tightly for 5 seconds.",
                        "Release the tension completely and notice the feeling of relaxation for 10 seconds.",
                        "Move up to your lower legs. Tense your calf muscles for 5 seconds, then release for 10 seconds.",
                        "Continue this pattern, moving up your body: thighs, abdomen, chest, arms, hands, shoulders, neck, and face.",
                        "End by taking a few deep breaths, enjoying the feeling of total body relaxation."
                    ]
                },
                {
                    name: 'Positive Affirmations',
                    duration: 3,
                    instructions: [
                        "Stand in front of a mirror or sit in a comfortable position.",
                        "Choose a few positive statements that resonate with you. For example: 'I am capable and strong,' or 'I choose to be happy today.'",
                        "Speak these affirmations out loud to yourself with conviction.",
                        "As you say each one, try to truly believe it and feel the emotion behind the words.",
                        "Repeat your affirmations several times, focusing on their positive message.",
                        "Carry this positive mindset with you throughout your day."
                    ]
                },
                {
                    name: 'Visualization',
                    duration: 10,
                    instructions: [
                        "Find a quiet place where you won't be disturbed.",
                        "Close your eyes and take a few deep breaths to relax.",
                        "Imagine a place where you feel completely safe and peaceful. It could be a beach, a forest, or a cozy room.",
                        "Use all your senses to build this mental image. What do you see? What sounds do you hear? What do you smell? How does the air feel on your skin?",
                        "Spend time exploring this peaceful place in your mind.",
                        "Whenever you feel stressed, you can return to this mental sanctuary for a few moments of calm."
                    ]
                }
            ];
            
            const quotes = [
                "The greatest weapon against stress is our ability to choose one thought over another.",
                "Your calm mind is the ultimate weapon against your challenges.",
                "Just when the caterpillar thought the world was over, it became a butterfly.",
                "Take a deep breath. It's just a bad day, not a bad life.",
                "A healthy mind creates a powerful future."
            ];

            // --- DOM Elements ---
            const grid = document.getElementById('exercise-grid');
            const searchInput = document.getElementById('search-input');
            const noResults = document.getElementById('no-results');
            const themeToggle = document.getElementById('theme-toggle');
            const quoteBanner = document.getElementById('quote-banner').querySelector('span');
            const timerModal = document.getElementById('timer-modal');
            const timerDisplay = document.getElementById('timer-display');
            const timerTitle = document.getElementById('timer-title');
            const closeTimerBtn = document.getElementById('close-timer');
            const timerMessage = document.getElementById('timer-message');

            let timerInterval = null;

            // --- Functions ---
            
            // Function to render exercises to the grid
            const renderExercises = (exerciseList) => {
                if (!grid) return;
                grid.innerHTML = '';
                if (exerciseList.length === 0) {
                    noResults.classList.remove('hidden');
                } else {
                    noResults.classList.add('hidden');
                }

                exerciseList.forEach(exercise => {
                    const instructionsHtml = exercise.instructions.map(step => `<li class="mb-2">${step}</li>`).join('');

                    const card = document.createElement('div');
                    card.className = 'exercise-card rounded-2xl p-6 flex flex-col';
                    card.innerHTML = `
                        <h2 class="text-2xl font-bold mb-3" style="color: var(--heading-color);">${exercise.name}</h2>
                        <div class="flex items-center text-sm mb-4 opacity-80">
                            <svg class="w-5 h-5 mr-2" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="10"></circle><polyline points="12 6 12 12 16 14"></polyline></svg>
                            <span>${exercise.duration} minutes</span>
                        </div>
                        <div class="exercise-instructions">
                            <h3 class="font-semibold text-lg mb-2 mt-2" style="color: var(--heading-color);">How to Do:</h3>
                            <ul class="list-disc list-inside space-y-2 text-sm opacity-90">${instructionsHtml}</ul>
                        </div>
                        <div class="mt-auto pt-4 flex gap-4">
                            <button class="read-more-btn flex-1 bg-black/10 hover:bg-black/20 font-semibold py-2 px-4 rounded-lg transition-colors">Read More</button>
                            <button class="start-timer-btn flex-1 bg-indigo-500 hover:bg-indigo-600 text-white font-bold py-2 px-4 rounded-lg transition-transform transform hover:scale-105" data-name="${exercise.name}" data-duration="${exercise.duration}">Start Timer</button>
                        </div>
                    `;
                    grid.appendChild(card);
                });
                observeCards(); // Re-observe cards after rendering
            };
            
            // Function to handle card expansion
            const handleCardClick = (e) => {
                const button = e.target.closest('.read-more-btn');
                if (button) {
                    const instructions = button.closest('.exercise-card').querySelector('.exercise-instructions');
                    const isExpanded = instructions.classList.toggle('expanded');
                    button.textContent = isExpanded ? 'Read Less' : 'Read More';
                }
            };

            // Function to handle starting the timer
            const handleTimerStart = (e) => {
                const button = e.target.closest('.start-timer-btn');
                if (button) {
                    const duration = parseInt(button.dataset.duration, 10);
                    const name = button.dataset.name;
                    startTimer(duration, name);
                }
            };
            
            // Function to start the countdown timer
            const startTimer = (minutes, name) => {
                clearInterval(timerInterval);
                let seconds = minutes * 60;
                timerTitle.textContent = name;
                timerMessage.textContent = "Time to focus and relax...";
                
                const updateDisplay = () => {
                    const min = Math.floor(seconds / 60).toString().padStart(2, '0');
                    const sec = (seconds % 60).toString().padStart(2, '0');
                    timerDisplay.textContent = `${min}:${sec}`;
                };

                updateDisplay();
                timerModal.classList.remove('hidden');

                timerInterval = setInterval(() => {
                    seconds--;
                    updateDisplay();
                    if (seconds <= 0) {
                        clearInterval(timerInterval);
                        timerMessage.textContent = "Time's up! Well done.";
                        // You could add a sound here if desired
                    }
                }, 1000);
            };

            const closeTimer = () => {
                clearInterval(timerInterval);
                timerModal.classList.add('hidden');
            }

            // Function to handle theme toggling
            const toggleTheme = () => {
                document.body.classList.toggle('dark-mode');
                localStorage.setItem('theme', document.body.classList.contains('dark-mode') ? 'dark' : 'light');
            };
            
            // Function to load saved theme
            const loadTheme = () => {
                const savedTheme = localStorage.getItem('theme');
                if (savedTheme === 'dark') {
                    document.body.classList.add('dark-mode');
                    if(themeToggle) themeToggle.checked = true;
                }
            };
            
            // Function to update quote
            const updateQuote = () => {
                if(!quoteBanner) return;
                const currentQuote = quoteBanner.textContent;
                let newQuote = currentQuote;
                while (newQuote === currentQuote) {
                    newQuote = quotes[Math.floor(Math.random() * quotes.length)];
                }
                
                quoteBanner.style.opacity = '0';
                setTimeout(() => {
                    quoteBanner.textContent = newQuote;
                    quoteBanner.style.opacity = '1';
                }, 500);
            };
            
            // Function to observe cards for scroll animations
            const observeCards = () => {
                const cards = document.querySelectorAll('.exercise-card');
                const observer = new IntersectionObserver((entries) => {
                    entries.forEach(entry => {
                        if (entry.isIntersecting) {
                            entry.target.classList.add('visible');
                            observer.unobserve(entry.target);
                        }
                    });
                }, { threshold: 0.1 });

                cards.forEach(card => {
                    observer.observe(card);
                });
            };

            // --- Event Listeners ---
            
            // Search filter
            if(searchInput) searchInput.addEventListener('input', (e) => {
                const searchTerm = e.target.value.toLowerCase();
                const filteredExercises = exercises.filter(exercise => exercise.name.toLowerCase().includes(searchTerm));
                renderExercises(filteredExercises);
            });

            // Event delegation for card buttons
            if(grid) grid.addEventListener('click', (e) => {
                handleCardClick(e);
                handleTimerStart(e);
            });
            
            // Theme toggle
            if(themeToggle) themeToggle.addEventListener('change', toggleTheme);

            // Timer modal close
            if(closeTimerBtn) closeTimerBtn.addEventListener('click', closeTimer);
            if(timerModal) timerModal.addEventListener('click', (e) => {
                if(e.target === timerModal) closeTimer();
            });

            // --- Initializations ---
            loadTheme();
            renderExercises(exercises);
            setInterval(updateQuote, 7000); // Change quote every 7 seconds
        });
    </script>
</body>
</html>

