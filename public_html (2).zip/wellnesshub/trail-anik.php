<?php
// =================================================================
// MENTAL ABILITY TEST - SINGLE FILE APPLICATION
// =================================================================
// This single file contains all the PHP, HTML, CSS, and JavaScript
// needed to run the entire application.

// --- 1. INITIALIZATION & CONFIGURATION ---
error_reporting(E_ALL);
ini_set('display_errors', 1);
session_start();

// Database Configuration
$dbHost = 'localhost';
$dbUser = 'u443217448_mental';
$dbPass = 'U443217448_mental';
$dbName = 'u443217448_mental';

// Create Database Connection
$conn = new mysqli($dbHost, $dbUser, $dbPass, $dbName);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// --- 2. POST REQUEST HANDLING ---
// This section handles all form submissions before any HTML is rendered.
$page = $_GET['page'] ?? 'home';
$error = '';

// Handle User Info Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_user_info'])) {
    $name = trim($_POST['name']);
    $address = trim($_POST['address']);
    $email = trim($_POST['email']);

    if (empty($name) || empty($address) || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $error = "Please fill in all fields with valid information.";
    } else {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $_SESSION['user_id'] = $user['id'];
        } else {
            $stmt_insert = $conn->prepare("INSERT INTO users (name, address, email) VALUES (?, ?, ?)");
            $stmt_insert->bind_param("sss", $name, $address, $email);
            if ($stmt_insert->execute()) {
                $_SESSION['user_id'] = $stmt_insert->insert_id;
            } else {
                $error = "Error saving your information.";
            }
            $stmt_insert->close();
        }
        $stmt->close();
        
        if (empty($error)) {
            header("Location: ?page=select_set");
            exit();
        }
    }
}

// Handle Test Submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit_test'])) {
    if (!isset($_SESSION['user_id'])) {
        header("Location: ?page=home");
        exit();
    }

    $user_id = $_SESSION['user_id'];
    $user_answers = $_POST['answers'] ?? [];
    $question_ids_str = $_POST['question_ids'] ?? '';
    $time_taken = 20 * 60 - intval($_POST['time_left'] ?? 0); // Calculate time taken from time left
    $question_ids = !empty($question_ids_str) ? explode(',', $question_ids_str) : [];

    if (empty($question_ids)) {
        die("No questions were submitted.");
    }
    
    $placeholders = implode(',', array_fill(0, count($question_ids), '?'));
    $stmt = $conn->prepare("SELECT id, correct_answer FROM questions WHERE id IN ($placeholders)");
    $types = str_repeat('i', count($question_ids));
    $stmt->bind_param($types, ...$question_ids);
    $stmt->execute();
    $result = $stmt->get_result();
    $correct_answers = [];
    while ($row = $result->fetch_assoc()) {
        $correct_answers[$row['id']] = $row['correct_answer'];
    }
    $stmt->close();

    $score = 0;
    foreach ($correct_answers as $qid => $correct_ans) {
        if (isset($user_answers[$qid]) && strtoupper($user_answers[$qid]) === strtoupper($correct_ans)) {
            $score += 5; // 5 points per correct answer
        }
    }

    // Ranking Logic
    $rank_category = 'Poor'; // Default
    if ($score >= 90) { // 90-100
        $rank_category = 'Very Intelligent';
    } elseif ($score >= 75) { // 75-89
        $rank_category = 'Highly Intelligent';
    } elseif ($score >= 60) { // 60-74
        $rank_category = 'Intelligent';
    }


    $stmt = $conn->prepare("INSERT INTO results (user_id, score, rank_category, time_taken) VALUES (?, ?, ?, ?)");
    $stmt->bind_param("iisi", $user_id, $score, $rank_category, $time_taken);
    $stmt->execute();
    $result_id = $stmt->insert_id;
    $stmt->close();

    $stmt_ans = $conn->prepare("INSERT INTO user_answers (result_id, question_id, user_answer) VALUES (?, ?, ?)");
    foreach ($question_ids as $qid) {
        $user_ans = $user_answers[$qid] ?? NULL;
        $stmt_ans->bind_param("iis", $result_id, $qid, $user_ans);
        $stmt_ans->execute();
    }
    $stmt_ans->close();

    $_SESSION['result_id'] = $result_id;
    header("Location: ?page=result");
    exit();
}

// Redirect to home if user_id is set but they are on the home page
if ($page === 'home' && isset($_SESSION['user_id'])) {
    header("Location: ?page=select_set");
    exit();
}

// --- 3. HTML & PHP VIEW LOGIC ---
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mental Ability Test</title>
    <style>
        /* All CSS is embedded here */
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap');
        :root {
            --primary-color: #007bff; --light-glow: rgba(0, 123, 255, 0.5);
            --dark-glow: rgba(0, 123, 255, 0.8); --white-color: #ffffff;
            --light-gray: #f8f9fa; --medium-gray: #e9ecef; --dark-gray: #343a40;
            --success-color: #28a745; --danger-color: #dc3545;
            --shadow: 0 10px 30px rgba(0, 0, 0, 0.07); --border-radius: 12px;
        }
        * { margin: 0; padding: 0; box-sizing: border-box; }
        body {
            font-family: 'Poppins', sans-serif; background-color: var(--light-gray);
            color: var(--dark-gray); display: flex; justify-content: center;
            align-items: flex-start; min-height: 100vh; padding: 2rem;
        }
        .container {
            width: 100%; max-width: 800px; background-color: var(--white-color);
            padding: 2.5rem; border-radius: var(--border-radius); box-shadow: var(--shadow);
            animation: fadeIn 0.5s ease-in-out;
        }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(-20px); } to { opacity: 1; transform: translateY(0); } }
        h1, h2, h3 { text-align: center; margin-bottom: 1.5rem; color: var(--dark-gray); }
        p { line-height: 1.6; margin-bottom: 1rem; }
        .form-group { margin-bottom: 1.5rem; }
        .form-group label { display: block; margin-bottom: 0.5rem; font-weight: 500; }
        .form-control {
            width: 100%; padding: 0.8rem 1rem; border: 1px solid var(--medium-gray);
            border-radius: 8px; font-size: 1rem; transition: all 0.3s ease;
        }
        .form-control:focus { outline: none; border-color: var(--primary-color); box-shadow: 0 0 0 4px var(--light-glow); }
        .btn {
            display: inline-block; width: 100%; padding: 0.9rem 1.5rem; border: none;
            border-radius: 8px; font-size: 1.1rem; font-weight: 600; color: var(--white-color);
            background: linear-gradient(45deg, var(--primary-color), #0056b3);
            cursor: pointer; text-align: center; text-decoration: none;
            transition: all 0.3s ease; box-shadow: 0 4px 15px rgba(0, 123, 255, 0.4);
        }
        .btn:hover { transform: translateY(-3px); box-shadow: 0 6px 20px rgba(0, 123, 255, 0.6); }
        .btn-secondary { background: linear-gradient(45deg, #6c757d, #5a6268); box-shadow: 0 4px 15px rgba(108, 117, 125, 0.4); }
        .btn-secondary:hover { box-shadow: 0 6px 20px rgba(108, 117, 125, 0.6); }
        #timer {
            position: fixed; top: 20px; right: 30px; background-color: var(--dark-gray);
            color: var(--white-color); padding: 10px 20px; border-radius: var(--border-radius);
            font-size: 1.5rem; font-weight: 700; box-shadow: var(--shadow); z-index: 1000;
        }
        .question-card { margin-bottom: 2rem; padding: 1.5rem; border: 1px solid var(--medium-gray); border-radius: var(--border-radius); }
        .question-text { font-size: 1.2rem; font-weight: 600; margin-bottom: 1.5rem; }
        .options-group { display: flex; flex-direction: column; gap: 1rem; }
        .option {
            display: block; position: relative; padding: 0.8rem 1rem 0.8rem 2.5rem;
            border: 1px solid var(--medium-gray); border-radius: 8px; cursor: pointer; transition: all 0.2s ease;
        }
        .option:hover { background-color: var(--light-gray); border-color: var(--primary-color); }
        
        /* --- BUG FIX STARTS HERE --- */
        .option input[type="radio"] {
            position: absolute;
            opacity: 0;
            top: 0;
            left: 0;
            height: 100%;
            width: 100%;
            cursor: pointer;
        }
        /* --- BUG FIX ENDS HERE --- */

        .option label { cursor: pointer; }
        .option .radio-custom {
            position: absolute; left: 1rem; top: 50%; transform: translateY(-50%);
            height: 20px; width: 20px; background-color: #fff; border: 2px solid var(--medium-gray);
            border-radius: 50%; transition: all 0.2s ease;
        }
        .option:hover .radio-custom { border-color: var(--primary-color); }
        .option input[type="radio"]:checked ~ .radio-custom { background-color: var(--primary-color); border-color: var(--primary-color); }
        .option .radio-custom::after {
            content: ''; position: absolute; display: none;
            left: 5px; top: 5px; width: 6px; height: 6px;
            border-radius: 50%; background: white;
        }
        .option input[type="radio"]:checked ~ .radio-custom::after { display: block; }
        .option input[type="radio"]:checked ~ label { font-weight: 600; color: var(--primary-color); }
        .result-summary { text-align: center; padding: 2rem; background-color: var(--light-gray); border-radius: var(--border-radius); margin-bottom: 2rem; }
        .result-summary h3 { font-size: 1.8rem; margin-bottom: 0.5rem; }
        .result-summary .score { font-size: 4rem; font-weight: 700; color: var(--primary-color); }
        .result-summary .rank { font-size: 1.5rem; font-weight: 500; color: var(--dark-gray); margin-top: -10px; }
        .result-details { display: flex; justify-content: space-around; text-align: center; margin-bottom: 2rem; }
        .detail-item p { font-size: 1.5rem; font-weight: 600; }
        .detail-item span { font-size: 0.9rem; color: #6c757d; }
        .review-question { margin-bottom: 1.5rem; padding: 1.5rem; border-radius: var(--border-radius); border-left: 5px solid; }
        .review-question.correct { border-left-color: var(--success-color); background-color: #f0fff4; }
        .review-question.incorrect { border-left-color: var(--danger-color); background-color: #fff5f5; }
        .answer-key { font-weight: 600; margin-top: 1rem; }
        .answer-key .correct-ans { color: var(--success-color); }
        .answer-key .user-ans { color: var(--danger-color); }
        .answer-key .user-ans.correct { color: var(--success-color); }
        .set-selection-container { display: grid; grid-template-columns: 1fr 1fr; gap: 1.5rem; margin-top: 2rem; }
        .set-card { padding: 2rem; text-align: center; border: 1px solid var(--medium-gray); border-radius: var(--border-radius); transition: all 0.3s ease; cursor: pointer; }
        .set-card:hover { transform: translateY(-5px); box-shadow: var(--shadow); border-color: var(--primary-color); }
        .set-card h3 { margin-bottom: 0.5rem; font-size: 1.5rem; }
        .set-card p { color: #6c757d; margin-bottom: 0; }
        .set-card.selected { background: #e7f1ff; border-color: var(--primary-color); box-shadow: 0 0 0 4px var(--light-glow); }
        #start-test-btn { margin-top: 2rem; display: none; }
        @media (max-width: 768px) {
            body { padding: 1rem; }
            .container { padding: 1.5rem; }
            #timer { position: relative; top: auto; right: auto; width: 100%; text-align: center; margin-bottom: 2rem; z-index: 0; }
            .result-details { flex-direction: column; gap: 1.5rem; }
            .set-selection-container { grid-template-columns: 1fr; }
        }
    </style>
</head>
<body>
    <div class="container">
    <?php
    // --- Page specific content rendering ---
    switch ($page) {
        case 'select_set':
    ?>
            <h2>Choose Your Challenge</h2>
            <p>Select one of the question sets below. You will have <strong>20 minutes</strong> to answer <strong>10 questions</strong>.</p>
            <form action="?page=test" method="GET">
                <div class="set-selection-container">
                    <div class="set-card" data-set="1"><h3>Set 1</h3><p>Classic Riddles & Logic</p></div>
                    <div class="set-card" data-set="2"><h3>Set 2</h3><p>Patterns & Sequences</p></div>
                    <div class="set-card" data-set="3"><h3>Set 3</h3><p>Advanced Logic Puzzles</p></div>
                    <div class="set-card" data-set="4"><h3>Set 4</h3><p>Lateral & Abstract Thinking</p></div>
                </div>
                <input type="hidden" name="page" value="test">
                <input type="hidden" name="set" id="question_set" value="">
                <button type="submit" id="start-test-btn" class="btn">Start Test</button>
            </form>
    <?php
            break;
        
        case 'test':
            if (!isset($_SESSION['user_id']) || !isset($_GET['set'])) {
                header("Location: ?page=home");
                exit();
            }
            $question_set = intval($_GET['set']);
            $stmt = $conn->prepare("SELECT * FROM questions WHERE question_set = ? ORDER BY RAND() LIMIT 10");
            $stmt->bind_param("i", $question_set);
            $stmt->execute();
            $questions = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
            $stmt->close();
    ?>
            <div id="timer">20:00</div>
            <form id="test-form" action="?page=submit" method="POST">
                <h2>Mental Ability Test - Set <?php echo $question_set; ?></h2>
                <?php foreach ($questions as $index => $q): ?>
                <div class="question-card">
                    <p class="question-text"><?php echo ($index + 1) . ". " . htmlspecialchars($q['question_text']); ?></p>
                    <div class="options-group">
                        <?php foreach (['a', 'b', 'c', 'd'] as $option_key): ?>
                        <div class="option">
                            <input type="radio" id="q<?php echo $q['id'].$option_key; ?>" name="answers[<?php echo $q['id']; ?>]" value="<?php echo strtoupper($option_key); ?>">
                            <label for="q<?php echo $q['id'].$option_key; ?>"><?php echo htmlspecialchars(strtoupper($option_key) . ". " . $q['option_' . $option_key]); ?></label>
                            <span class="radio-custom"></span>
                        </div>
                        <?php endforeach; ?>
                    </div>
                </div>
                <?php endforeach; ?>
                <input type="hidden" name="question_ids" value="<?php echo implode(',', array_column($questions, 'id')); ?>">
                <input type="hidden" name="time_left" id="time_left" value="1200">
                <button type="submit" name="submit_test" class="btn">Submit Test</button>
            </form>
    <?php
            break;
        
        case 'result':
            if (!isset($_SESSION['result_id'])) {
                header("Location: ?page=home"); exit();
            }
            $result_id = $_SESSION['result_id'];
            $stmt = $conn->prepare("SELECT r.*, u.name FROM results r JOIN users u ON r.user_id = u.id WHERE r.id = ?");
            $stmt->bind_param("i", $result_id);
            $stmt->execute();
            $result = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $total_res = $conn->query("SELECT COUNT(*) as total FROM results")->fetch_assoc();
            $lower_res = $conn->query("SELECT COUNT(*) as lower_count FROM results WHERE score < " . $result['score'])->fetch_assoc();
            $percentile = ($total_res['total'] > 1) ? ($lower_res['lower_count'] / ($total_res['total'] - 1)) * 100 : 100;
    ?>
            <h2>Result for <?php echo htmlspecialchars($result['name']); ?></h2>
            <div class="result-summary">
                <h3>Your Score</h3>
                <div class="score"><?php echo $result['score']; ?> / 50</div>
                <div class="rank"><?php echo htmlspecialchars($result['rank_category']); ?></div>
            </div>
            <div class="result-details">
                <div class="detail-item"><p><?php echo round($percentile, 2); ?>%</p><span>Percentile Rank</span></div>
                <div class="detail-item"><p><?php echo floor($result['time_taken'] / 60) . "m " . ($result['time_taken'] % 60) . "s"; ?></p><span>Time Taken</span></div>
                <div class="detail-item"><p><?php echo $total_res['total']; ?></p><span>Total Participants</span></div>
            </div>
            <div style="text-align: center; margin-top: 2rem;">
                <a href="?page=review" class="btn">Review Answers</a>
                <a href="?page=select_set" class="btn btn-secondary" style="margin-top: 1rem;">Take Another Test</a>
            </div>
    <?php
            break;

        case 'review':
             if (!isset($_SESSION['result_id'])) {
                header("Location: ?page=home"); exit();
            }
            $result_id = $_SESSION['result_id'];
            $sql = "SELECT q.question_text, q.option_a, q.option_b, q.option_c, q.option_d, q.correct_answer, ua.user_answer FROM user_answers ua JOIN questions q ON ua.question_id = q.id WHERE ua.result_id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $result_id);
            $stmt->execute();
            $review_data = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);
    ?>
            <h2>Answer Review</h2>
            <p>Here's a breakdown of your performance.</p>
            <?php foreach ($review_data as $index => $data):
                $is_correct = ($data['user_answer'] === $data['correct_answer']);
                $options = ['A' => $data['option_a'], 'B' => $data['option_b'], 'C' => $data['option_c'], 'D' => $data['option_d']];
                $correct_answer_text = $options[$data['correct_answer']];
                $user_answer_text = isset($data['user_answer']) ? $options[$data['user_answer']] : 'Not Answered';
            ?>
            <div class="review-question <?php echo $is_correct ? 'correct' : 'incorrect'; ?>">
                <p class="question-text"><?php echo ($index + 1) . ". " . htmlspecialchars($data['question_text']); ?></p>
                <div class="answer-key">
                    <span class="correct-ans">Correct Answer: <?php echo htmlspecialchars($data['correct_answer'] . ". " . $correct_answer_text); ?></span><br>
                    <span class="user-ans <?php echo $is_correct ? 'correct' : ''; ?>">Your Answer: <?php echo htmlspecialchars(($data['user_answer'] ?? 'N/A') . ". " . $user_answer_text); ?></span>
                </div>
            </div>
            <?php endforeach; ?>
            <div style="text-align: center; margin-top: 2rem;"><a href="?page=select_set" class="btn">Back to Home</a></div>
    <?php
            break;

        default: // Home page
    ?>
            <h1>Mental Ability & Logic Test</h1>
            <p>Please provide your information to start the test. Your details will be used to calculate your ranking.</p>
            <?php if ($error): ?>
                <p style="color: red; text-align: center; margin-bottom: 1rem;"><?php echo htmlspecialchars($error); ?></p>
            <?php endif; ?>
            <form action="?page=home" method="POST">
                <div class="form-group"><label for="name">Full Name</label><input type="text" id="name" name="name" class="form-control" required></div>
                <div class="form-group"><label for="address">Address</label><input type="text" id="address" name="address" class="form-control" required></div>
                <div class="form-group"><label for="email">Email</label><input type="email" id="email" name="email" class="form-control" required></div>
                <button type="submit" name="submit_user_info" class="btn">Proceed to Test</button>
            </form>
    <?php
            break;
    }
    ?>
    </div>
    
    <script>
        // --- All JavaScript is embedded here ---
        const timerElement = document.getElementById('timer');
        const testForm = document.getElementById('test-form');
        if (timerElement && testForm) {
            let timeLeft = 1200; // 20 minutes
            const countdown = setInterval(() => {
                if (timeLeft <= 0) {
                    clearInterval(countdown);
                    timerElement.textContent = "Time's Up!";
                    testForm.submit();
                } else {
                    const minutes = Math.floor(timeLeft / 60);
                    let seconds = timeLeft % 60;
                    seconds = seconds < 10 ? '0' + seconds : seconds;
                    // --- SYNTAX FIX STARTS HERE ---
                    timerElement.textContent = `${minutes}:${seconds}`;
                    // --- SYNTAX FIX ENDS HERE ---
                    document.getElementById('time_left').value = timeLeft;
                    timeLeft--;
                }
            }, 1000);
        }
        
        const setCards = document.querySelectorAll('.set-card');
        const startButton = document.getElementById('start-test-btn');
        const questionSetInput = document.getElementById('question_set');
        if (setCards.length > 0) {
            setCards.forEach(card => {
                card.addEventListener('click', () => {
                    setCards.forEach(c => c.classList.remove('selected'));
                    card.classList.add('selected');
                    questionSetInput.value = card.getAttribute('data-set');
                    startButton.style.display = 'block';
                });
            });
        }
    </script>
</body>
</html>
<?php
// --- 4. CLOSE CONNECTION ---
$conn->close();
?>