// Premium UI Interactions
document.addEventListener('DOMContentLoaded', function() {
    // Initialize smooth scrolling
    document.documentElement.classList.add('smooth-scroll');

    // Add premium hover effects
    document.querySelectorAll('.premium-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-5px)';
        });
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
        });
    });

    // Handle mobile menu
    const sidebarToggle = document.querySelector('[data-sidebar-toggle]');
    const sidebar = document.querySelector('[data-sidebar]');
    const overlay = document.querySelector('[data-overlay]');

    if (sidebarToggle && sidebar && overlay) {
        sidebarToggle.addEventListener('click', toggleSidebar);
        overlay.addEventListener('click', toggleSidebar);
    }

    function toggleSidebar() {
        sidebar.classList.toggle('translate-x-0');
        overlay.classList.toggle('hidden');
        document.body.classList.toggle('overflow-hidden');
    }

    // Profile dropdown
    const profileToggle = document.querySelector('[data-profile-toggle]');
    const profileDropdown = document.querySelector('[data-profile-dropdown]');

    if (profileToggle && profileDropdown) {
        profileToggle.addEventListener('click', (e) => {
            e.stopPropagation();
            profileDropdown.classList.toggle('hidden');

            if (!profileDropdown.classList.contains('hidden')) {
                // Add click outside listener
                setTimeout(() => {
                    document.addEventListener('click', closeProfileDropdown);
                }, 0);
            }
        });
    }

    function closeProfileDropdown(e) {
        if (!profileDropdown.contains(e.target) && !profileToggle.contains(e.target)) {
            profileDropdown.classList.add('hidden');
            document.removeEventListener('click', closeProfileDropdown);
        }
    }

    // Mobile optimizations
    if ('ontouchstart' in window) {
        // Add active state for better touch feedback
        document.querySelectorAll('.touch-feedback').forEach(element => {
            element.addEventListener('touchstart', function() {
                this.classList.add('active');
            });
            element.addEventListener('touchend', function() {
                this.classList.remove('active');
            });
        });

        // Prevent pull-to-refresh on iOS
        document.body.addEventListener('touchmove', function(e) {
            if (window.innerHeight >= document.documentElement.scrollHeight) {
                e.preventDefault();
            }
        }, { passive: false });
    }

    // Fix 100vh issue on mobile browsers
    function setVHVariable() {
        let vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }

    setVHVariable();
    window.addEventListener('resize', setVHVariable);
    window.addEventListener('orientationchange', () => {
        setTimeout(setVHVariable, 100);
    });

    // Smooth loading transitions
    window.addEventListener('load', function() {
        document.body.classList.add('loaded');
    });
});

// Theme handling
function initializeTheme() {
    const themeToggle = document.getElementById('theme-toggle');
    const htmlEl = document.documentElement;
    
    function setTheme(isDark) {
        htmlEl.classList.toggle('dark', isDark);
        localStorage.setItem('theme', isDark ? 'dark' : 'light');
        
        // Update icons
        document.querySelectorAll('[data-theme-icon]').forEach(icon => {
            icon.classList.toggle('hidden', icon.dataset.themeIcon !== (isDark ? 'dark' : 'light'));
        });
    }

    // Initialize theme
    const savedTheme = localStorage.getItem('theme');
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    setTheme(savedTheme ? savedTheme === 'dark' : prefersDark);

    // Theme toggle handler
    if (themeToggle) {
        themeToggle.addEventListener('click', () => {
            setTheme(!htmlEl.classList.contains('dark'));
        });
    }

    // Listen for system theme changes
    window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change', e => {
        if (!localStorage.getItem('theme')) {
            setTheme(e.matches);
        }
    });
}
