// Mobile optimizations
document.addEventListener('DOMContentLoaded', function() {
    // Fix for 100vh issue on mobile browsers
    function fixMobileHeight() {
        let vh = window.innerHeight * 0.01;
        document.documentElement.style.setProperty('--vh', `${vh}px`);
    }
    window.addEventListener('resize', debounce(fixMobileHeight, 150));
    window.addEventListener('orientationchange', fixMobileHeight);
    fixMobileHeight();

    // Debounce helper
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Handle virtual keyboard with scroll position preservation
    const inputs = document.querySelectorAll('input:not([type="checkbox"]):not([type="radio"]), textarea');
    inputs.forEach(input => {
        let scrollPos;
        input.addEventListener('focus', () => {
            if (isMobile()) {
                scrollPos = window.scrollY;
                document.body.classList.add('has-virtual-keyboard');
                // Slight delay to ensure virtual keyboard is open
                setTimeout(() => {
                    input.scrollIntoView({ behavior: 'smooth', block: 'center' });
                }, 300);
            }
        });
        input.addEventListener('blur', () => {
            document.body.classList.remove('has-virtual-keyboard');
            if (isMobile() && scrollPos !== undefined) {
                setTimeout(() => window.scrollTo(0, scrollPos), 100);
            }
        });
    });

    // Enhanced touch handling for iOS
    if (CSS.supports('-webkit-overflow-scrolling: touch')) {
        document.body.style.webkitOverflowScrolling = 'touch';
    }

    // Prevent rubber-band scrolling on iOS with improved modal handling
    let touchStartY;
    
    document.body.addEventListener('touchstart', function(e) {
        touchStartY = e.touches[0].clientY;
    }, { passive: true });

    document.body.addEventListener('touchmove', function(e) {
        const touchY = e.touches[0].clientY;
        const touchYDelta = touchY - touchStartY;
        const modal = document.querySelector('.modal.active');
        
        // Allow scrolling in modals
        if (modal && modal.contains(e.target)) {
            const modalContent = modal.querySelector('.modal-content');
            const scrollTop = modalContent.scrollTop;
            const scrollHeight = modalContent.scrollHeight;
            const offsetHeight = modalContent.offsetHeight;
            
            if ((scrollTop <= 0 && touchYDelta > 0) || 
                (scrollTop + offsetHeight >= scrollHeight && touchYDelta < 0)) {
                e.preventDefault();
            }
            return;
        }

        // Prevent overscroll on main content
        if (window.innerHeight >= document.documentElement.scrollHeight) {
            e.preventDefault();
        }
    }, { passive: false });

    // Enhanced active state for navigation
    const currentPath = window.location.pathname;
    const navItems = document.querySelectorAll('.mobile-nav-item');
    navItems.forEach(item => {
        const href = item.getAttribute('href');
        if (href === currentPath || currentPath.startsWith(href)) {
            item.classList.add('active');
            // Add ripple effect for touch feedback
            item.classList.add('touch-ripple');
        }
    });

    // Implement touch ripple effect
    document.querySelectorAll('.touch-ripple').forEach(element => {
        element.addEventListener('touchstart', createRipple);
        element.addEventListener('mousedown', createRipple);
    });

    // Smooth scrolling with performance optimization
    if (!CSS.supports('scroll-behavior', 'smooth')) {
        // Polyfill smooth scrolling for iOS
        document.querySelectorAll('a[href^="#"]').forEach(anchor => {
            anchor.addEventListener('click', function(e) {
                e.preventDefault();
                const targetId = this.getAttribute('href');
                const targetElement = document.querySelector(targetId);
                if (targetElement) {
                    smoothScroll(targetElement);
                }
            });
        });
    } else {
        document.documentElement.style.scrollBehavior = 'smooth';
    }

    // Initialize Lucide icons if available
    if (typeof lucide !== 'undefined') {
        lucide.createIcons();
    }

    // Enhanced mobile menu with animations and gestures
    const menuToggle = document.querySelector('.menu-toggle');
    const mobileMenu = document.querySelector('.mobile-menu');
    const overlay = document.querySelector('.mobile-menu-overlay');
    
    if (menuToggle && mobileMenu) {
        // Handle menu toggle with animation
        menuToggle.addEventListener('click', toggleMenu);
        
        // Add swipe gesture support
        let touchStartX = 0;
        let touchMoveX = 0;

        mobileMenu.addEventListener('touchstart', e => {
            touchStartX = e.touches[0].clientX;
        }, { passive: true });

        mobileMenu.addEventListener('touchmove', e => {
            touchMoveX = e.touches[0].clientX;
            const deltaX = touchStartX - touchMoveX;
            
            if (deltaX > 0) { // Swipe left
                mobileMenu.style.transform = `translateX(-${deltaX}px)`;
            }
        }, { passive: true });

        mobileMenu.addEventListener('touchend', e => {
            const deltaX = touchStartX - touchMoveX;
            if (deltaX > 75) { // Swipe threshold
                closeMenu();
            } else {
                mobileMenu.style.transform = '';
            }
        });

        // Close menu on overlay click
        if (overlay) {
            overlay.addEventListener('click', closeMenu);
        }

        // Close menu on escape key
        document.addEventListener('keydown', e => {
            if (e.key === 'Escape') closeMenu();
        });
    }
});

// Utility functions
function isMobile() {
    return /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent) 
        || (window.matchMedia("(max-width: 768px)").matches);
}

function createRipple(event) {
    const element = event.currentTarget;
    const circle = document.createElement('span');
    const diameter = Math.max(element.clientWidth, element.clientHeight);
    const radius = diameter / 2;

    const rect = element.getBoundingClientRect();
    const x = (event.type === 'touchstart' ? event.touches[0].clientX : event.clientX) - rect.left;
    const y = (event.type === 'touchstart' ? event.touches[0].clientY : event.clientY) - rect.top;

    circle.style.width = circle.style.height = `${diameter}px`;
    circle.style.left = `${x - radius}px`;
    circle.style.top = `${y - radius}px`;
    circle.classList.add('ripple');

    const ripple = element.querySelector('.ripple');
    if (ripple) {
        ripple.remove();
    }

    element.appendChild(circle);
}

function smoothScroll(target) {
    const targetPosition = target.getBoundingClientRect().top + window.pageYOffset;
    const startPosition = window.pageYOffset;
    const distance = targetPosition - startPosition;
    const duration = 750;
    let start = null;

    function animation(currentTime) {
        if (start === null) start = currentTime;
        const timeElapsed = currentTime - start;
        const progress = Math.min(timeElapsed / duration, 1);
        const ease = easeInOutCubic(progress);
        
        window.scrollTo(0, startPosition + distance * ease);
        
        if (timeElapsed < duration) {
            requestAnimationFrame(animation);
        }
    }

    requestAnimationFrame(animation);
}

function easeInOutCubic(t) {
    return t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
}

function toggleMenu() {
    const mobileMenu = document.querySelector('.mobile-menu');
    const overlay = document.querySelector('.mobile-menu-overlay');
    
    if (mobileMenu) {
        mobileMenu.classList.toggle('active');
        if (overlay) overlay.classList.toggle('hidden');
        document.body.classList.toggle('menu-open');
    }
}

function closeMenu() {
    const mobileMenu = document.querySelector('.mobile-menu');
    const overlay = document.querySelector('.mobile-menu-overlay');
    
    if (mobileMenu) {
        mobileMenu.classList.remove('active');
        if (overlay) overlay.classList.add('hidden');
        document.body.classList.remove('menu-open');
        mobileMenu.style.transform = '';
    }
}

// Add mobile optimization classes
if (isMobile()) {
    document.body.classList.add('is-mobile');
    // Add touch-specific optimizations
    document.body.addEventListener('touchstart', function(){}, {passive: true});
    // Disable hover effects on mobile
    document.documentElement.classList.add('mobile-hover-disabled');
}
