<?php
// Student Navigation Items
$nav_items = [
    ['url' => 'index.php', 'icon' => 'layout-dashboard', 'title' => 'Dashboard'],
    ['url' => 'courses.php', 'icon' => 'book-open', 'title' => 'My Courses'],
    //['url' => 'batch.php', 'icon' => 'users-2', 'title' => 'My Batch'],
    ['url' => 'live_class.php', 'icon' => 'users-2', 'title' => 'Wellness Hub'],
    ['url' => 'live_class.php', 'icon' => 'video', 'title' => 'Live Classes'],
    ['url' => 'grades.php', 'icon' => 'clipboard-check', 'title' => 'Grades'],
    ['url' => '../chat/', 'icon' => 'message-square', 'title' => 'Chat'],
    ['url' => 'settings.php', 'icon' => 'settings', 'title' => 'Settings']
];

foreach ($nav_items as $item) {
    $is_active = $current_page === $item['url'];
    $classes = 'flex items-center space-x-3 px-4 py-2 rounded-lg transition-colors duration-200 ';
    $classes .= $is_active 
        ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' 
        : 'hover:bg-gray-100 dark:hover:bg-dark-bg text-gray-700 dark:text-gray-300';
    ?>
    <a href="<?php echo $item['url']; ?>" class="<?php echo $classes; ?>">
        <i data-lucide="<?php echo $item['icon']; ?>"></i>
        <span><?php echo $item['title']; ?></span>
    </a>
<?php } ?>
