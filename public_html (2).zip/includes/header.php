<?php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="en" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' . htmlspecialchars($config['academyName']) : htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
            -webkit-overflow-scrolling: touch;
            overscroll-behavior-y: none;
        }
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e5e7eb;
            z-index: 50;
            padding: 0.5rem;
            display: none;
        }
        .dark .mobile-nav {
            background: #252526;
            border-top: 1px solid #333;
        }
        @media (max-width: 768px) {
            .mobile-nav {
                display: flex;
            }
            .desktop-nav {
                display: none;
            }
            main {
                padding-bottom: 5rem;
            }
        }
        .nav-item {
            flex: 1;
            display: flex;
            flex-direction: column;
            align-items: center;
            padding: 0.5rem;
            color: #6b7280;
            text-decoration: none;
            font-size: 0.75rem;
            transition: all 0.2s;
        }
        .nav-item.active {
            color: #4f46e5;
        }
        .dark .nav-item.active {
            color: #007ACC;
        }
        .nav-item i {
            margin-bottom: 0.25rem;
            font-size: 1.25rem;
        }
        * {
            -webkit-tap-highlight-color: transparent;
            touch-action: manipulation;
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text min-h-screen">
    <?php if(isset($_SESSION['user_role'])): ?>
        <!-- Mobile Navigation -->
        <nav class="mobile-nav">
            <?php if($_SESSION['user_role'] == 'Admin'): ?>
                <a href="<?php echo BASE_URL; ?>admin/" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/index.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo BASE_URL; ?>admin/courses.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/courses.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="book"></i>
                    <span>Courses</span>
                </a>
                <a href="<?php echo BASE_URL; ?>admin/users.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/users.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="users"></i>
                    <span>Users</span>
                </a>
                <a href="<?php echo BASE_URL; ?>admin/settings.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/settings.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="settings"></i>
                    <span>Settings</span>
                </a>
            <?php elseif($_SESSION['user_role'] == 'Instructor'): ?>
                <a href="<?php echo BASE_URL; ?>instructor/" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/instructor/index.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo BASE_URL; ?>instructor/courses.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/instructor/courses.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="book"></i>
                    <span>Courses</span>
                </a>
                <a href="<?php echo BASE_URL; ?>instructor/live_class.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/instructor/live_class.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="video"></i>
                    <span>Live Class</span>
                </a>
                <a href="<?php echo BASE_URL; ?>instructor/settings.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/instructor/settings.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="settings"></i>
                    <span>Settings</span>
                </a>
            <?php elseif($_SESSION['user_role'] == 'Student'): ?>
                <a href="<?php echo BASE_URL; ?>student/" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/student/index.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="home"></i>
                    <span>Dashboard</span>
                </a>
                <a href="<?php echo BASE_URL; ?>student/courses.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/student/courses.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="book"></i>
                    <span>Courses</span>
                </a>
                <a href="<?php echo BASE_URL; ?>student/live_class.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/student/live_class.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="video"></i>
                    <span>Live Class</span>
                </a>
                <a href="<?php echo BASE_URL; ?>student/settings.php" class="nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/student/settings.php') !== false ? 'active' : ''; ?>">
                    <i data-lucide="settings"></i>
                    <span>Setting9999s</span>
                </a>
            <?php endif; ?>
        </nav>
    <?php endif; ?>
    <script>
        lucide.createIcons();
        // Theme detection and application
        const htmlEl = document.documentElement;
        if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            htmlEl.classList.add('dark');
        }
    </script>
</body>
</html>
