<?php
// Include this at the top of all pages after auth check
if(!isset($_SESSION)) session_start();
?>
<style>
/* Mobile-specific styles */
.mobile-nav {
    position: fixed;
    bottom: 0;
    left: 0;
    right: 0;
    background: white;
    border-top: 1px solid #e5e7eb;
    padding: 8px;
    display: none;
    z-index: 50;
    box-shadow: 0 -2px 10px rgba(0,0,0,0.1);
}

.dark .mobile-nav {
    background: #252526;
    border-top: 1px solid #333;
}

@media (max-width: 768px) {
    .mobile-nav {
        display: flex;
        justify-content: space-around;
        align-items: center;
    }
    
    .desktop-menu {
        display: none !important;
    }
    
    main {
        padding-bottom: 80px !important; /* Space for mobile nav */
    }

    body {
        overscroll-behavior-y: none;
        -webkit-overflow-scrolling: touch;
    }
}

.mobile-nav-item {
    display: flex;
    flex-direction: column;
    align-items: center;
    text-decoration: none;
    color: #6b7280;
    font-size: 0.75rem;
    padding: 4px 0;
    transition: color 0.2s;
}

.mobile-nav-item.active {
    color: #4f46e5;
}

.dark .mobile-nav-item.active {
    color: #007ACC;
}

.mobile-nav-item i {
    margin-bottom: 4px;
    width: 24px;
    height: 24px;
}

/* Smooth scrolling and touch improvements */
* {
    -webkit-tap-highlight-color: transparent;
    touch-action: manipulation;
}

/* Fix for content jumping */
html {
    scroll-behavior: smooth;
    height: 100%;
    overflow-x: hidden;
}

body {
    min-height: 100%;
    position: relative;
}
</style>

<?php if(isset($_SESSION['user_role'])): ?>
<nav class="mobile-nav">
    <?php if($_SESSION['user_role'] == 'Admin'): ?>
        <a href="<?php echo BASE_URL; ?>admin/" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/index.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="layout-dashboard"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/users.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/users.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="users"></i>
            <span>Users</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/courses.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/courses.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="book-open"></i>
            <span>Courses</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/settings.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/admin/settings.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="settings"></i>
            <span>Settings</span>
        </a>
    <?php elseif($_SESSION['user_role'] == 'Instructor'): ?>
        <a href="<?php echo BASE_URL; ?>instructor/" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/instructor/index.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="layout-dashboard"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>instructor/courses.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/instructor/courses.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="book-open"></i>
            <span>Courses</span>
        </a>
        <a href="<?php echo BASE_URL; ?>instructor/live_class.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/instructor/live_class.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="video"></i>
            <span>Live Class</span>
        </a>
        <a href="<?php echo BASE_URL; ?>instructor/settings.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/instructor/settings.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="settings"></i>
            <span>Settings</span>
        </a>
    <?php elseif($_SESSION['user_role'] == 'Student'): ?>
        <a href="<?php echo BASE_URL; ?>student/" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/student/index.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="layout-dashboard"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>student/courses.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/student/courses.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="book-open"></i>
            <span>Courses</span>
        </a>
        <a href="<?php echo BASE_URL; ?>student/live_class.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/student/live_class.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="video"></i>
            <span>Live Class</span>
        </a>
        <a href="<?php echo BASE_URL; ?>student/settings.php" class="mobile-nav-item <?php echo strpos($_SERVER['REQUEST_URI'], '/student/settings.php') !== false ? 'active' : ''; ?>">
            <i data-lucide="settings"></i>
            <span>Settings</span>
        </a>
    <?php endif; ?>
</nav>

<script>
// Initialize Lucide icons
lucide.createIcons();

// Prevent rubber-band scrolling on iOS
document.body.addEventListener('touchmove', function(e) {
    if (window.innerHeight >= document.documentElement.scrollHeight) {
        e.preventDefault();
    }
}, { passive: false });

// Fix for 100vh issue on mobile browsers
function fixMobileHeight() {
    let vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);
}
window.addEventListener('resize', fixMobileHeight);
fixMobileHeight();
</script>
<?php endif; ?>
