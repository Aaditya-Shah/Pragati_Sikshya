<?php
// Include this file after the head tag in all pages
?>
<link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/mobile.css">
<script src="<?php echo BASE_URL; ?>assets/js/mobile.js" defer></script>

<?php if(isset($_SESSION['user_role'])): ?>
<!-- Mobile Navigation -->
<nav class="mobile-nav">
    <?php if($_SESSION['user_role'] === 'Admin'): ?>
        <a href="<?php echo BASE_URL; ?>admin/" class="mobile-nav-item">
            <i data-lucide="layout-dashboard"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/users.php" class="mobile-nav-item">
            <i data-lucide="users"></i>
            <span>Users</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/courses.php" class="mobile-nav-item">
            <i data-lucide="book-open"></i>
            <span>Courses</span>
        </a>
        <a href="<?php echo BASE_URL; ?>admin/settings.php" class="mobile-nav-item">
            <i data-lucide="settings"></i>
            <span>Settings</span>
        </a>
    <?php elseif($_SESSION['user_role'] === 'Instructor'): ?>
        <a href="<?php echo BASE_URL; ?>instructor/" class="mobile-nav-item">
            <i data-lucide="layout-dashboard"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>instructor/courses.php" class="mobile-nav-item">
            <i data-lucide="book-open"></i>
            <span>Courses</span>
        </a>
        <a href="<?php echo BASE_URL; ?>instructor/live_class.php" class="mobile-nav-item">
            <i data-lucide="video"></i>
            <span>Live Class</span>
        </a>
        <a href="<?php echo BASE_URL; ?>instructor/settings.php" class="mobile-nav-item">
            <i data-lucide="settings"></i>
            <span>Settings</span>
        </a>
    <?php elseif($_SESSION['user_role'] === 'Student'): ?>
        <a href="<?php echo BASE_URL; ?>student/" class="mobile-nav-item">
            <i data-lucide="layout-dashboard"></i>
            <span>Dashboard</span>
        </a>
        <a href="<?php echo BASE_URL; ?>student/courses.php" class="mobile-nav-item">
            <i data-lucide="book-open"></i>
            <span>Courses</span>
        </a>
        <a href="<?php echo BASE_URL; ?>student/live_class.php" class="mobile-nav-item">
            <i data-lucide="video"></i>
            <span>Live Class</span>
        </a>
        <a href="<?php echo BASE_URL; ?>student/settings.php" class="mobile-nav-item">
            <i data-lucide="settings"></i>
            <span>Settings</span>
        </a>
    <?php endif; ?>
</nav>
<?php endif; ?>
