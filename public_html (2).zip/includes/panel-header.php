<?php
if(!isset($_SESSION)) session_start();
require_once '../auth.php';

// Get the current page name for active state
$current_page = basename($_SERVER['PHP_SELF']);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' . htmlspecialchars($config['academyName']) : htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="<?php echo BASE_URL; ?>assets/css/premium.css">
    <script src="<?php echo BASE_URL; ?>assets/js/premium.js" defer></script>
    
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif']
                    },
                    colors: {
                        dark: {
                            bg: '#1E1E1E',
                            surface: '#252526',
                            border: '#333333',
                            text: '#D4D4D4',
                            'text-secondary': '#A9A9A9',
                            primary: '#007ACC',
                            'primary-hover': '#005f9e'
                        },
                        light: {
                            primary: '#4f46e5',
                            'primary-hover': '#4338ca'
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body { 
            font-family: 'Inter', sans-serif;
            -webkit-overflow-scrolling: touch;
            overscroll-behavior-y: none;
        }
        
        #sidebar {
            transition: transform 0.3s ease-in-out;
        }
        
        .sidebar-open #sidebar {
            transform: translateX(0) !important;
        }
        
        @media (max-width: 1024px) {
            #sidebar {
                transform: translateX(-100%);
            }
        }
        
        .premium-transition {
            transition: all 0.3s ease;
        }
        
        .premium-card {
            transition: transform 0.2s ease, box-shadow 0.2s ease;
        }
        
        .premium-card:hover {
            transform: translateY(-2px);
            box-shadow: 0 8px 30px rgba(0,0,0,0.12);
        }
        
        .mobile-nav-item.active {
            color: var(--color-light-primary);
            position: relative;
        }
        
        .dark .mobile-nav-item.active {
            color: var(--color-dark-primary);
        }
        
        .mobile-nav-item.active::after {
            content: '';
            position: absolute;
            bottom: -4px;
            left: 50%;
            transform: translateX(-50%);
            width: 20px;
            height: 2px;
            background-color: currentColor;
            border-radius: 2px;
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <!-- Sidebar Overlay -->
    <div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden hidden" onclick="toggleSidebar()"></div>

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="fixed lg:static w-64 bg-white dark:bg-dark-surface p-6 flex flex-col h-full z-50">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10">
                <i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i>
                <span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span>
            </a>
            
            <nav class="space-y-2">
                <?php if($_SESSION['user_role'] === 'Student'): ?>
                    <a href="index.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'index.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="layout-dashboard"></i><span>Dashboard</span>
                    </a>
                    <a href="courses.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'courses.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="book-open"></i><span>My Courses</span>
                    </a>
                    <a href="batch.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'batch.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="users-2"></i><span>My Batch</span>
                    </a>
                    <a href="live_class.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'live_class.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="video"></i><span>Live Classes</span>
                    </a>
                    <a href="grades.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'grades.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="clipboard-check"></i><span>Grades</span>
                    </a>
                <?php elseif($_SESSION['user_role'] === 'Instructor'): ?>
                    <a href="index.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'index.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="layout-dashboard"></i><span>Dashboard</span>
                    </a>
                    <a href="courses.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'courses.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="book-open"></i><span>Courses</span>
                    </a>
                    <a href="batches.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'batches.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="users-2"></i><span>Batches</span>
                    </a>
                    <a href="live_class.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'live_class.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="video"></i><span>Live Classes</span>
                    </a>
                    <a href="mock_test.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'mock_test.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="file-text"></i><span>Mock Tests</span>
                    </a>
                <?php elseif($_SESSION['user_role'] === 'Admin'): ?>
                    <a href="index.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'index.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="layout-dashboard"></i><span>Dashboard</span>
                    </a>
                    <a href="users.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'users.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="users"></i><span>Users</span>
                    </a>
                    <a href="courses.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'courses.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="book-open"></i><span>Courses</span>
                    </a>
                    <a href="batches.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'batches.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="users-2"></i><span>Batches</span>
                    </a>
                    <a href="plugins.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'plugins.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="plug-2"></i><span>Plugins</span>
                    </a>
                    <a href="settings.php" class="nav-item flex items-center space-x-3 px-4 py-2 rounded-lg <?php echo $current_page === 'settings.php' ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold' : 'hover:bg-gray-100 dark:hover:bg-dark-bg'; ?>">
                        <i data-lucide="settings"></i><span>Settings</span>
                    </a>
                <?php endif; ?>
            </nav>

            <form action="../auth.php" method="POST" class="mt-auto">
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10">
                    <i data-lucide="log-out"></i>
                    <span>Logout</span>
                </button>
            </form>
        </aside>

        <div class="flex-1">
            <!-- Header -->
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4">
                <div class="max-w-7xl mx-auto flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <button onclick="toggleSidebar()" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-dark-bg lg:hidden">
                            <i data-lucide="menu"></i>
                        </button>
                        <h1 class="text-2xl font-bold"><?php echo isset($pageTitle) ? $pageTitle : 'Dashboard'; ?></h1>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <button id="theme-toggle" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-dark-bg">
                            <i data-lucide="sun" class="hidden" id="theme-icon-sun"></i>
                            <i data-lucide="moon" class="hidden" id="theme-icon-moon"></i>
                        </button>
                        <div class="relative" id="profile-menu">
                            <button onclick="toggleProfileMenu()" class="flex items-center space-x-3 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg p-2">
                                <img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full object-cover">
                                <div class="hidden md:block text-left">
                                    <h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
                                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($_SESSION['user_role']); ?></p>
                                </div>
                                <i data-lucide="chevron-down" class="h-5 w-5 text-gray-500"></i>
                            </button>
                            <div id="profile-dropdown" class="absolute right-0 mt-2 w-48 bg-white dark:bg-dark-surface rounded-lg shadow-lg py-2 hidden z-50">
                                <a href="settings.php" class="flex items-center space-x-2 px-4 py-2 text-gray-700 dark:text-dark-text hover:bg-gray-100 dark:hover:bg-dark-bg">
                                    <i data-lucide="settings" class="h-5 w-5"></i>
                                    <span>Settings</span>
                                </a>
                                <form action="../auth.php" method="POST" class="w-full">
                                    <input type="hidden" name="action" value="logout">
                                    <button type="submit" class="flex items-center space-x-2 w-full px-4 py-2 text-red-500 hover:bg-gray-100 dark:hover:bg-dark-bg">
                                        <i data-lucide="log-out" class="h-5 w-5"></i>
                                        <span>Logout</span>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Main Content Area -->
            <main class="p-6 md:p-8">
