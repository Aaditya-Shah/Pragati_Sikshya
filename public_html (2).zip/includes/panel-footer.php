            </main>
        </div>
    </div>

    <!-- Mobile Navigation -->
    <nav class="fixed bottom-0 left-0 right-0 bg-white dark:bg-dark-surface border-t border-gray-200 dark:border-dark-border lg:hidden z-50">
        <div class="flex justify-around items-center p-2">
            <?php if($_SESSION['user_role'] === 'Student'): ?>
                <a href="index.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="layout-dashboard" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Dashboard</span>
                </a>
                <a href="courses.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="book-open" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Courses</span>
                </a>
                <a href="live_class.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="video" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Live</span>
                </a>
                <a href="grades.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="clipboard-check" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Grades</span>
                </a>
            <?php elseif($_SESSION['user_role'] === 'Instructor'): ?>
                <a href="index.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="layout-dashboard" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Dashboard</span>
                </a>
                <a href="courses.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="book-open" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Courses</span>
                </a>
                <a href="live_class.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="video" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Live</span>
                </a>
                <a href="mock_test.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="file-text" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Tests</span>
                </a>
            <?php elseif($_SESSION['user_role'] === 'Admin'): ?>
                <a href="index.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="layout-dashboard" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Dashboard</span>
                </a>
                <a href="users.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="users" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Users</span>
                </a>
                <a href="courses.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="book-open" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Courses</span>
                </a>
                <a href="settings.php" class="mobile-nav-item p-2 flex flex-col items-center">
                    <i data-lucide="settings" class="h-6 w-6"></i>
                    <span class="text-xs mt-1">Settings</span>
                </a>
            <?php endif; ?>
        </div>
    </nav>

    <script>
        // Initialize icons
        lucide.createIcons();

        // Sidebar toggle
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            document.body.classList.toggle('sidebar-open');
            overlay.classList.toggle('hidden');
        }

        // Profile menu toggle
        function toggleProfileMenu() {
            const dropdown = document.getElementById('profile-dropdown');
            dropdown.classList.toggle('hidden');

            // Close dropdown when clicking outside
            const closeDropdown = (e) => {
                if (!dropdown.contains(e.target) && !e.target.closest('#profile-menu')) {
                    dropdown.classList.add('hidden');
                    document.removeEventListener('click', closeDropdown);
                }
            };

            if (!dropdown.classList.contains('hidden')) {
                setTimeout(() => {
                    document.addEventListener('click', closeDropdown);
                }, 0);
            }
        }

        // Set active state for mobile navigation
        document.querySelectorAll('.mobile-nav-item').forEach(item => {
            if (item.getAttribute('href') === '<?php echo basename($_SERVER['PHP_SELF']); ?>') {
                item.classList.add('active');
            }
        });

        // Add premium interactions to cards
        document.querySelectorAll('.premium-card').forEach(card => {
            card.addEventListener('mouseenter', function() {
                this.style.transform = 'translateY(-2px)';
            });
            card.addEventListener('mouseleave', function() {
                this.style.transform = 'translateY(0)';
            });
        });
    </script>
</body>
</html>
