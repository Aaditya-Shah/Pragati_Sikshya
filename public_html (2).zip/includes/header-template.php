<?php
if(!isset($_SESSION)) session_start();
require_once dirname(__DIR__) . '/auth.php';

$current_page = basename($_SERVER['PHP_SELF']);
$current_dir = basename(dirname($_SERVER['PHP_SELF']));
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title><?php echo isset($pageTitle) ? $pageTitle . ' - ' . htmlspecialchars($config['academyName']) : htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        window.userName = '<?php echo htmlspecialchars($_SESSION['user_name']); ?>';
        window.userRole = '<?php echo htmlspecialchars($_SESSION['user_role']); ?>';
        tailwind.config = {
            darkMode: 'class',
            theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } }
        }
    </script>
    <link rel="stylesheet" href="../css/style.css">
    <script src="../js/mobile-menu.js" defer></script>
    <style>
        body { 
            font-family: 'Inter', sans-serif; 
            -webkit-overflow-scrolling: touch;
            height: 100vh;
            height: calc(var(--vh, 1vh) * 100);
            overflow-x: hidden;
        }
        
        /* Sidebar Styles */
        .sidebar { 
            @apply fixed lg:sticky top-0 left-0 h-full w-64 bg-white dark:bg-dark-surface border-r dark:border-dark-border transform transition-transform duration-300 ease-in-out z-50;
            height: 100vh;
            height: calc(var(--vh, 1vh) * 100);
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
        }
        .sidebar.closed { @apply -translate-x-full lg:translate-x-0; }
        .sidebar.open { @apply translate-x-0; }
        
        /* Overlay */
        .sidebar-overlay {
            @apply fixed inset-0 bg-black/50 backdrop-blur-[2px] z-40 lg:hidden;
            touch-action: none;
        }
        
        /* Mobile Navigation */
        .mobile-nav {
            @apply fixed bottom-0 left-0 right-0 bg-white dark:bg-dark-surface border-t dark:border-dark-border z-50 
                   grid grid-cols-4 gap-1 px-2 py-1 lg:hidden;
        }
        
        /* Menu Items */
        .menu-item {
            @apply flex items-center space-x-3 px-4 py-2 rounded-lg text-gray-600 dark:text-gray-300 
                   hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200;
        }
        .menu-item.active {
            @apply bg-indigo-50 dark:bg-indigo-500/10 text-indigo-600 dark:text-indigo-400;
        }
        
        /* Profile Menu */
        .profile-dropdown {
            @apply absolute right-0 mt-2 w-48 bg-white dark:bg-dark-surface rounded-lg shadow-lg border 
                   dark:border-dark-border divide-y divide-gray-100 dark:divide-dark-border z-50;
        }
        
        /* Responsive Fixes */
        @media (max-width: 1024px) {
            .desktop-menu { display: none !important; }
            .mobile-only { display: block !important; }
            input, button, select, textarea { font-size: 16px !important; }
            .container { padding-left: 16px !important; padding-right: 16px !important; }
            main { padding-bottom: 80px !important; }
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .touch-feedback:active { transform: scale(0.98); }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text min-h-screen">
    <!-- Sidebar Overlay -->
    <div id="sidebar-overlay" class="fixed inset-0 z-40 lg:hidden hidden" onclick="toggleSidebar()"></div>

    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="fixed lg:static w-64 bg-white dark:bg-dark-surface p-6 flex flex-col h-full z-50 transform -translate-x-full lg:translate-x-0 transition-transform duration-300">
            <div class="flex items-center space-x-2 mb-10">
                <i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i>
                <span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span>
            </div>
            
            <nav class="space-y-2">
                <?php include dirname(__DIR__) . '/includes/nav-' . strtolower($_SESSION['user_role']) . '.php'; ?>
            </nav>

            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto">
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10">
                    <i data-lucide="log-out"></i>
                    <span>Logout</span>
                </button>
            </form>
        </aside>

        <div class="flex-1">
            <!-- Header -->
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4">
                <div class="max-w-7xl mx-auto flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <button onclick="toggleSidebar()" class="p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg lg:hidden">
                            <i data-lucide="menu"></i>
                        </button>
                        <h1 class="text-2xl font-bold"><?php echo isset($pageTitle) ? $pageTitle : ucfirst($current_dir); ?></h1>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <button id="theme-toggle" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-dark-bg">
                            <i data-lucide="sun" class="hidden" id="theme-icon-sun"></i>
                            <i data-lucide="moon" class="hidden" id="theme-icon-moon"></i>
                        </button>
                        <div class="relative" id="profile-menu">
                            <button onclick="toggleProfileMenu()" class="flex items-center space-x-3 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg p-2">
                                <img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full object-cover">
                                <div class="hidden md:block text-left">
                                    <h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
                                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($_SESSION['user_role']); ?></p>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
            </header>

            <!-- Main Content -->
            <main class="p-6 md:p-8">
            <?php 
            if ($current_dir === 'instructor') {
                include dirname(__DIR__) . '/includes/mobile-nav-instructor.php';
            } elseif ($current_dir === 'admin') {
                include dirname(__DIR__) . '/includes/mobile-nav-admin.php';
            }
            ?>
