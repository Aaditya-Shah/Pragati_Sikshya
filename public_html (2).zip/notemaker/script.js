document.addEventListener('DOMContentLoaded', () => {
    const noteForm = document.getElementById('note-form');
    const topicInput = document.getElementById('topic-input');
    const generateBtn = document.getElementById('generate-btn');
    const loadingSpinner = document.getElementById('loading-spinner');
    const noteContainer = document.getElementById('note-container');
    const downloadPdfBtn = document.getElementById('download-pdf-btn');

    const theUltimatePrompt = `The Ultimate Emoji-Note Prompt 🎨📝... [YOUR FULL PROMPT TEXT HERE] ...Let's go! I'm ready for the most amazing and emoji-filled note ever! 🚀`;

    noteForm.addEventListener('submit', async (e) => {
        e.preventDefault();
        const topic = topicInput.value.trim();
        if (!topic) return;

        // --- Start Loading State ---
        noteContainer.innerHTML = '';
        noteContainer.classList.add('hidden');
        downloadPdfBtn.classList.add('hidden');
        loadingSpinner.classList.remove('hidden');
        generateBtn.disabled = true;

        try {
            // --- Call Your Secure Backend ---
            const response = await fetch('api.php', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ topic: topic, prompt: theUltimatePrompt })
            });

            if (!response.ok) {
                throw new Error(`HTTP error! Status: ${response.status}`);
            }

            const result = await response.json();

            // Display the result
            // IMPORTANT: We are assuming the API returns Markdown.
            // For a real app, you would use a library like 'marked.js' to safely convert Markdown to HTML.
            // For this example, we'll do a simple conversion.
            let formattedText = result.note.replace(/\n/g, '<br>');
            noteContainer.innerHTML = formattedText;
            noteContainer.classList.remove('hidden');
            downloadPdfBtn.classList.remove('hidden');

        } catch (error) {
            console.error("Error generating note:", error);
            noteContainer.innerHTML = '<p style="color: red;">😥 Oops! Something went wrong. Please check the console for details.</p>';
            noteContainer.classList.remove('hidden');
        } finally {
            // --- End Loading State ---
            loadingSpinner.classList.add('hidden');
            generateBtn.disabled = false;
        }
    });

    downloadPdfBtn.addEventListener('click', () => {
        const { jsPDF } = window.jspdf;
        const noteContent = document.getElementById('note-container');
        
        // Use html2canvas to capture the div as an image
        html2canvas(noteContent, { scale: 2 }).then(canvas => {
            const imgData = canvas.toDataURL('image/png');
            
            // Create a PDF document
            const pdf = new jsPDF({
                orientation: 'p',
                unit: 'px',
                format: [canvas.width, canvas.height]
            });

            // Add the image to the PDF
            pdf.addImage(imgData, 'PNG', 0, 0, canvas.width, canvas.height);
            pdf.save(`${topicInput.value.trim().replace(/ /g, '_')}_note.pdf`);
        });
    });
});