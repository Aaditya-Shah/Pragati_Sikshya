<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AI Note Generator</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        .note-content h2 {
            font-size: 1.25rem;
            font-weight: 600;
            margin-top: 1rem;
            margin-bottom: 0.5rem;
        }
        .note-content h3 {
            font-size: 1.1rem;
            font-weight: 600;
            margin-top: 0.75rem;
            margin-bottom: 0.25rem;
        }
        .note-content ul {
            list-style-type: disc;
            margin-left: 1.5rem;
            margin-bottom: 1rem;
        }
         .note-content p {
            margin-bottom: 0.75rem;
        }
    </style>
</head>
<body class="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 flex items-center justify-center min-h-screen">

    <div class="container mx-auto p-4 max-w-2xl">
        <div class="bg-white dark:bg-gray-800 rounded-2xl shadow-lg p-6 sm:p-8">
            <header class="text-center mb-6 sm:mb-8">
                <h1 class="text-3xl sm:text-4xl font-bold text-gray-800 dark:text-white">AI Note Generator</h1>
                <p class="text-gray-500 dark:text-gray-400 mt-2">Enter a topic and select a subject to get AI-generated notes.</p>
            </header>

            <!-- Input Form -->
            <div class="space-y-4">
                <div>
                    <label for="topic" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Topic</label>
                    <input type="text" id="topic" class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500" placeholder="e.g., Newton's Laws of Motion">
                </div>

                <div>
                    <label for="subject" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Subject</label>
                    <select id="subject" class="w-full px-4 py-2 bg-gray-50 dark:bg-gray-700 border border-gray-300 dark:border-gray-600 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-blue-500">
                        <option value="Physics">Physics</option>
                        <option value="Chemistry">Chemistry</option>
                        <option value="Maths">Maths</option>
                    </select>
                </div>

                <button id="generate-btn" class="w-full bg-blue-600 hover:bg-blue-700 text-white font-semibold py-3 px-4 rounded-lg transition duration-300 ease-in-out transform hover:scale-105 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500">
                    Generate Notes
                </button>
            </div>

            <!-- Result Section -->
            <div id="result-container" class="mt-6 sm:mt-8">
                <!-- Loading Spinner -->
                <div id="loader" class="hidden flex flex-col items-center justify-center text-center">
                    <svg class="animate-spin -ml-1 mr-3 h-8 w-8 text-blue-600" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                        <circle class="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" stroke-width="4"></circle>
                        <path class="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                    </svg>
                    <p class="mt-2 text-gray-500 dark:text-gray-400">Generating your notes... Please wait.</p>
                </div>

                <!-- Error Message -->
                <div id="error-message" class="hidden p-4 bg-red-100 dark:bg-red-900 border border-red-400 dark:border-red-700 text-red-700 dark:text-red-200 rounded-lg"></div>

                <!-- Notes Output -->
                <div id="notes-output" class="hidden p-4 sm:p-6 bg-gray-50 dark:bg-gray-900/50 border border-gray-200 dark:border-gray-700 rounded-lg note-content">
                </div>
            </div>
        </div>
        <footer class="text-center mt-6 text-sm text-gray-500 dark:text-gray-400">
            <p>Powered by AI. Notes may require verification for accuracy.</p>
        </footer>
    </div>

    <script>
        const generateBtn = document.getElementById('generate-btn');
        const topicInput = document.getElementById('topic');
        const subjectSelect = document.getElementById('subject');
        const loader = document.getElementById('loader');
        const errorMessage = document.getElementById('error-message');
        const notesOutput = document.getElementById('notes-output');

        generateBtn.addEventListener('click', generateNote);
        topicInput.addEventListener('keydown', (event) => {
            if (event.key === 'Enter') {
                generateNote();
            }
        });

        async function generateNote() {
            const topic = topicInput.value.trim();
            const subject = subjectSelect.value;

            if (!topic) {
                showError('Please enter a topic.');
                return;
            }

            showLoading(true);
            clearOutput();

            const systemPrompt = "You are an expert educator and note-taking assistant. Your goal is to generate clear, concise, and easy-to-understand notes for a high school or early college student. Structure the notes logically with headings, subheadings, and bullet points. Explain complex concepts in simple terms. Ensure the content is accurate and directly relevant to the requested topic and subject.";

            const userQuery = `Generate notes on the topic: "${topic}" for the subject: "${subject}".`;

            try {
                const generatedText = await callGeminiAPI(systemPrompt, userQuery);
                // A simple markdown-to-HTML conversion
                const formattedHtml = generatedText
                    .replace(/\*\*(.*?)\*\*/g, '<h3>$1</h3>') // Bold for subheadings
                    .replace(/\* (.*?)(?=\n\*|\n\n|$)/g, '<li>$1</li>') // List items
                    .replace(/(\r\n|\n|\r)/g, '<br>') // Line breaks
                    .replace(/(<li>.*?<\/li>)+/g, '<ul>$&</ul>') // Wrap lists
                    .replace(/<br><ul>/g, '<ul>') // clean up extra breaks
                    .replace(/<\/ul><br>/g, '</ul>');
                
                notesOutput.innerHTML = `<h2>Notes on ${topic}</h2>` + formattedHtml;
                notesOutput.classList.remove('hidden');

            } catch (error) {
                console.error('API Error:', error);
                showError('Failed to generate notes. Please check your connection and try again.');
            } finally {
                showLoading(false);
            }
        }

        async function callGeminiAPI(systemPrompt, userQuery) {
            // In a real application, you should not expose the API key on the client side.
            // This is simplified for this example.
            const apiKey = "AIzaSyDDg1BZqVWCxkl0nPj1l5s7NgIrwYxq3XE"; // Leave empty, will be handled by the environment
            const apiUrl = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${apiKey}`;

            const payload = {
                systemInstruction: {
                    parts: [{ text: systemPrompt }]
                },
                contents: [{
                    parts: [{ text: userQuery }]
                }],
            };

            let response;
            let retries = 3;
            let delay = 1000;

            for (let i = 0; i < retries; i++) {
                try {
                    response = await fetch(apiUrl, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                        },
                        body: JSON.stringify(payload),
                    });

                    if (response.ok) {
                        const result = await response.json();
                        const candidate = result.candidates?.[0];
                        if (candidate && candidate.content?.parts?.[0]?.text) {
                            return candidate.content.parts[0].text;
                        } else {
                           throw new Error("Invalid response structure from API.");
                        }
                    } else if (response.status === 429) { // Too Many Requests
                        console.warn(`Rate limited. Retrying in ${delay / 1000}s...`);
                        await new Promise(resolve => setTimeout(resolve, delay));
                        delay *= 2; // Exponential backoff
                    } else {
                        throw new Error(`API request failed with status ${response.status}: ${response.statusText}`);
                    }
                } catch (error) {
                     if (i === retries - 1) throw error; // Rethrow last error
                     await new Promise(resolve => setTimeout(resolve, delay));
                     delay *= 2;
                }
            }
             throw new Error("Failed to get a valid response after multiple retries.");
        }

        function showLoading(isLoading) {
            if (isLoading) {
                loader.classList.remove('hidden');
                generateBtn.disabled = true;
                generateBtn.classList.add('opacity-50', 'cursor-not-allowed');
            } else {
                loader.classList.add('hidden');
                generateBtn.disabled = false;
                generateBtn.classList.remove('opacity-50', 'cursor-not-allowed');
            }
        }

        function showError(message) {
            errorMessage.textContent = message;
            errorMessage.classList.remove('hidden');
        }

        function clearOutput() {
            errorMessage.classList.add('hidden');
            notesOutput.classList.add('hidden');
            notesOutput.innerHTML = '';
        }

    </script>
</body>
</html>
