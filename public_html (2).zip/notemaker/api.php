<?php
// Set the content type to JSON
header('Content-Type: application/json');

// --- 1. YOUR SECRET API KEY ---
// This is the ONLY place your API key should be.
// Replace with your actual Gemini API Key.
$apiKey = 'AIzaSyDDg1BZqVWCxkl0nPj1l5s7NgIrwYxq3XE'; // <-- PASTE YOUR REAL KEY HERE

// --- 2. GET THE USER'S TOPIC FROM THE JAVASCRIPT 'fetch' CALL ---
$input = json_decode(file_get_contents('php://input'), true);
$userTopic = $input['topic'] ?? '';
$userPromptTemplate = $input['prompt'] ?? '';

if (empty($userTopic) || empty($userPromptTemplate)) {
    http_response_code(400);
    echo json_encode(['error' => 'Topic or prompt is missing.']);
    exit;
}

// --- 3. CONSTRUCT THE FULL PROMPT ---
$fullPrompt = str_replace('[Your Topic Here]', $userTopic, $userPromptTemplate);

// --- 4. PREPARE THE API REQUEST ---
$apiUrl = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-pro:generateContent?key=' . $apiKey;

$data = [
    'contents' => [
        [
            'parts' => [
                ['text' => $fullPrompt]
            ]
        ]
    ]
];

$jsonData = json_encode($data);

// --- 5. MAKE THE API CALL USING cURL ---
$ch = curl_init($apiUrl);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, $jsonData);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, true); // Important for security

$response = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$error = curl_error($ch);
curl_close($ch);

// --- 6. PROCESS THE RESPONSE AND SEND IT BACK TO THE JAVASCRIPT ---
if ($error) {
    http_response_code(500);
    echo json_encode(['error' => 'cURL Error: ' . $error]);
    exit;
}

if ($http_code !== 200) {
    http_response_code($http_code);
    echo json_encode(['error' => 'API Error', 'details' => json_decode($response)]);
    exit;
}

$responseData = json_decode($response, true);
// Extract the actual text content from the Gemini response structure
$noteText = $responseData['candidates'][0]['content']['parts'][0]['text'] ?? 'Sorry, I could not generate a note. Please try again.';

// Send the clean text back to the JavaScript front-end
echo json_encode(['note' => $noteText]);