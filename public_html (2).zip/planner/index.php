<!DOCTYPE html>
<html lang="en" class="light">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ikigai Day Planner & Reflection</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        // Set theme on initial load to prevent flash of unstyled content
        if (localStorage.getItem('theme') === 'dark' || (!('theme' in localStorage) && window.matchMedia('(prefers-color-scheme: dark)').matches)) {
            document.documentElement.classList.add('dark');
        } else {
            document.documentElement.classList.remove('dark');
        }
    </script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        .view { display: none; }
        .view.active { display: block; }
        .fade-in { animation: fadeIn 0.5s ease-in-out; }
        @keyframes fadeIn { from { opacity: 0; transform: translateY(10px); } to { opacity: 1; transform: translateY(0); } }
        
        /* Toast Notification */
        #toast {
            position: fixed;
            bottom: -100px;
            left: 50%;
            transform: translateX(-50%);
            transition: bottom 0.5s ease-in-out;
            z-index: 50;
        }
        #toast.show {
            bottom: 20px;
        }
        
        /* Ikigai Diagram */
        .ikigai-circle {
            transition: fill-opacity 0.5s ease-in-out;
        }

        /* Reflection Stepper */
        .step { display: none; }
        .step.active { display: block; animation: fadeIn 0.5s; }

        /* Custom scrollbar */
        ::-webkit-scrollbar { width: 8px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: #cbd5e1; border-radius: 4px; }
        .dark ::-webkit-scrollbar-thumb { background: #4a5568; }
        ::-webkit-scrollbar-thumb:hover { background: #a0aec0; }
        .dark ::-webkit-scrollbar-thumb:hover { background: #718096; }

        /* Custom range slider styles */
        input[type=range] { -webkit-appearance: none; background: transparent; width: 100%; }
        input[type=range]:focus { outline: none; }
        input[type=range]::-webkit-slider-runnable-track {
            width: 100%; height: 6px; cursor: pointer; background: #e2e8f0; border-radius: 3px;
        }
        .dark input[type=range]::-webkit-slider-runnable-track { background: #4a5568; }
        input[type=range]::-webkit-slider-thumb {
            -webkit-appearance: none; height: 18px; width: 18px; border-radius: 50%; background: #4f46e5; cursor: pointer; margin-top: -6px;
        }
        .dark input[type=range]::-webkit-slider-thumb { background: #818cf8; }
        
        /* History Modal */
        #history-modal {
            transition: opacity 0.3s ease-in-out;
        }
        #history-modal-content {
            transition: transform 0.3s ease-in-out;
        }
    </style>
</head>
<body class="bg-gray-100 dark:bg-gray-900 text-gray-800 dark:text-gray-200 antialiased transition-colors duration-300">

    <div id="app" class="min-h-screen flex flex-col items-center p-4">
        
        <nav class="w-full max-w-6xl flex justify-between items-center p-4">
            <h1 class="font-bold text-xl text-gray-800 dark:text-white">IKIGAI</h1>
            <button onclick="toggleTheme()" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500 dark:focus:ring-offset-gray-900">
                <svg id="theme-icon-light" class="h-6 w-6 hidden dark:block" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 3v1m0 16v1m9-9h-1M4 12H3m15.364 6.364l-.707-.707M6.343 6.343l-.707-.707m12.728 0l-.707.707M6.343 17.657l-.707.707M16 12a4 4 0 11-8 0 4 4 0 018 0z" /></svg>
                <svg id="theme-icon-dark" class="h-6 w-6 block dark:hidden" fill="none" viewBox="0 0 24 24" stroke="currentColor"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20.354 15.354A9 9 0 018.646 3.646 9.003 9.003 0 0012 21a9.003 9.003 0 008.354-5.646z" /></svg>
            </button>
        </nav>

        <main class="flex-grow flex items-center justify-center w-full">
            <!-- Home View -->
            <div id="home" class="view active text-center w-full max-w-4xl fade-in">
                <header class="mb-10">
                    <h1 class="text-6xl font-extrabold text-gray-800 dark:text-white mb-3">Hello, Champ!</h1>
                    <p class="text-xl text-gray-600 dark:text-gray-400">Find your purpose, one day at a time.</p>
                    <p id="daily-quote" class="text-gray-500 dark:text-gray-500 mt-6 text-sm italic"></p>
                </header>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
                    <button onclick="switchView('planner')" class="bg-white dark:bg-gray-800 text-gray-800 dark:text-white p-8 rounded-2xl shadow-lg hover:shadow-2xl dark:hover:bg-gray-700 transition-all duration-300 transform hover:-translate-y-2 focus:outline-none focus:ring-4 focus:ring-blue-400 dark:focus:ring-blue-500">
                        <span class="text-5xl">☀️</span>
                        <h2 class="text-2xl font-bold mt-4">Day Planner</h2>
                        <p class="mt-2 text-gray-500 dark:text-gray-400">Structure your day.</p>
                    </button>
                    <button onclick="switchView('reflection')" class="bg-white dark:bg-gray-800 text-gray-800 dark:text-white p-8 rounded-2xl shadow-lg hover:shadow-2xl dark:hover:bg-gray-700 transition-all duration-300 transform hover:-translate-y-2 focus:outline-none focus:ring-4 focus:ring-indigo-400 dark:focus:ring-indigo-500">
                        <span class="text-5xl">🌙</span>
                        <h2 class="text-2xl font-bold mt-4">Day Reflection</h2>
                        <p class="mt-2 text-gray-500 dark:text-gray-400">Grow through reflection.</p>
                    </button>
                     <button onclick="switchView('history')" class="bg-white dark:bg-gray-800 text-gray-800 dark:text-white p-8 rounded-2xl shadow-lg hover:shadow-2xl dark:hover:bg-gray-700 transition-all duration-300 transform hover:-translate-y-2 focus:outline-none focus:ring-4 focus:ring-yellow-400 dark:focus:ring-yellow-500">
                        <span class="text-5xl">📜</span>
                        <h2 class="text-2xl font-bold mt-4">View History</h2>
                        <p class="mt-2 text-gray-500 dark:text-gray-400">Review past entries.</p>
                    </button>
                </div>
                <div class="mt-10 border-t dark:border-gray-700 pt-6">
                     <h3 class="text-lg font-semibold text-gray-700 dark:text-gray-300 mb-4">Manage Your Data</h3>
                     <div class="flex justify-center gap-4">
                        <button onclick="exportData()" class="bg-green-500 hover:bg-green-600 text-white font-bold py-2 px-4 rounded-lg transition-colors">Export Data</button>
                        <button onclick="document.getElementById('import-file').click()" class="bg-purple-500 hover:bg-purple-600 text-white font-bold py-2 px-4 rounded-lg transition-colors">Import Data</button>
                        <input type="file" id="import-file" class="hidden" accept=".json" onchange="importData(event)">
                     </div>
                     <p class="text-gray-500 dark:text-gray-600 mt-4 text-sm">Save your progress or load a previous session.</p>
                </div>
            </div>

            <!-- Planner View -->
            <div id="planner" class="view w-full max-w-6xl fade-in">
                <button onclick="switchView('home')" class="mb-6 text-blue-600 dark:text-blue-400 hover:underline font-semibold">&larr; Back to Home</button>
                <h1 class="text-4xl font-bold text-center mb-8">Today's Planner</h1>
                <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                    <div class="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl">
                        <form id="task-form" class="space-y-6">
                           <div>
                            <label for="task-input" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">New Task:</label>
                            <input type="text" id="task-input" placeholder="What's your next mission?" class="w-full p-3 bg-gray-100 dark:bg-gray-700 border-2 border-transparent rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:text-white" required>
                        </div>
                        <div class="flex flex-col sm:flex-row gap-6">
                            <div class="flex-1">
                                <label for="task-category" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Category:</label>
                                <select id="task-category" class="w-full p-3 bg-gray-100 dark:bg-gray-700 border-2 border-transparent rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent dark:text-white">
                                    <option value="Passion">❤️ Passion</option>
                                    <option value="Profession">💼 Profession</option>
                                    <option value="Vocation">🌱 Vocation</option>
                                    <option value="Mission">🎯 Mission</option>
                                </select>
                            </div>
                            <div class="flex items-end pb-1">
                                <label for="major-focus" class="flex items-center cursor-pointer">
                                    <input type="checkbox" id="major-focus" class="h-5 w-5 text-blue-600 border-gray-300 rounded focus:ring-blue-500">
                                    <span class="ml-2 text-sm font-medium text-gray-700 dark:text-gray-300">Major Focus</span>
                                </label>
                            </div>
                        </div>
                        <button type="submit" class="w-full bg-blue-600 text-white font-bold py-3 px-8 rounded-lg hover:bg-blue-700 transition-transform transform hover:scale-105 shadow-md">Add Task</button>
                        </form>
                        <div class="mt-8">
                            <div class="flex flex-wrap justify-between items-center gap-4 mb-4">
                                <div class="flex-wrap flex gap-2">
                                   <button onclick="filterTasks('all', this)" class="filter-btn bg-blue-600 text-white py-2 px-4 rounded-full text-sm font-semibold">All</button>
                                   <button onclick="filterTasks('major', this)" class="filter-btn bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 py-2 px-4 rounded-full text-sm font-semibold">Major</button>
                                   <button onclick="filterTasks('minor', this)" class="filter-btn bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 py-2 px-4 rounded-full text-sm font-semibold">Minor</button>
                                </div>
                                <div id="progress-container" class="w-full sm:w-auto text-right">
                                    <span id="progress-text" class="text-sm font-semibold"></span>
                                </div>
                            </div>
                             <div id="task-list" class="space-y-3 max-h-[30vh] overflow-y-auto p-1"></div>
                        </div>
                    </div>
                    <div class="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl flex flex-col items-center justify-center">
                        <h2 class="text-2xl font-bold mb-4 text-center">Your Daily Ikigai</h2>
                         <svg id="ikigai-diagram" viewBox="0 0 100 100" class="w-full max-w-sm">
                            <g transform="translate(50,50)">
                                <!-- Circles -->
                                <circle cx="0" cy="-20" r="20" fill="#ef4444" fill-opacity="0.1" stroke="#ef4444" stroke-width="0.5" class="ikigai-circle" id="circle-passion"></circle>
                                <circle cx="20" cy="0" r="20" fill="#3b82f6" fill-opacity="0.1" stroke="#3b82f6" stroke-width="0.5" class="ikigai-circle" id="circle-profession"></circle>
                                <circle cx="0" cy="20" r="20" fill="#22c55e" fill-opacity="0.1" stroke="#22c55e" stroke-width="0.5" class="ikigai-circle" id="circle-vocation"></circle>
                                <circle cx="-20" cy="0" r="20" fill="#f97316" fill-opacity="0.1" stroke="#f97316" stroke-width="0.5" class="ikigai-circle" id="circle-mission"></circle>
                                <!-- Labels -->
                                <text x="0" y="-38" text-anchor="middle" font-size="5" class="fill-current font-semibold">Passion</text>
                                <text x="38" y="0" text-anchor="middle" font-size="5" class="fill-current font-semibold" dominant-baseline="middle">Profession</text>
                                <text x="0" y="42" text-anchor="middle" font-size="5" class="fill-current font-semibold" dominant-baseline="hanging">Vocation</text>
                                <text x="-38" y="0" text-anchor="middle" font-size="5" class="fill-current font-semibold" dominant-baseline="middle">Mission</text>
                                <!-- Center Text -->
                                <text x="0" y="0" text-anchor="middle" font-size="8" class="fill-current font-extrabold" dominant-baseline="middle">IKIGAI</text>
                            </g>
                        </svg>
                        <p class="text-center text-gray-500 dark:text-gray-400 mt-4 text-sm">Complete tasks to fill the circles and find your balance.</p>
                    </div>
                </div>
            </div>
            
            <!-- Reflection View -->
             <div id="reflection" class="view w-full max-w-2xl fade-in">
                <button onclick="switchView('home')" class="mb-6 text-indigo-600 dark:text-indigo-400 hover:underline font-semibold">&larr; Back to Home</button>
                <h1 class="text-4xl font-bold text-center mb-2">Today's Reflection</h1>
                <p class="text-center text-gray-500 dark:text-gray-400 mb-8">Take a moment to grow.</p>
                 <div id="reflection-stepper" class="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl">
                    <!-- Step 1: Goal -->
                    <div class="step active" data-step="1">
                        <label for="main-goal" class="block text-xl font-medium mb-2">What was your main goal today?</label>
                        <input type="text" id="main-goal" class="w-full p-3 bg-gray-100 dark:bg-gray-700 border-2 border-transparent rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="e.g., Finish the project proposal">
                        <label class="block text-xl font-medium mt-6 mb-2">Did you accomplish it?</label>
                        <div class="grid grid-cols-2 gap-4">
                            <button onclick="setGoalCompletion(true, this)" class="goal-btn bg-gray-200 dark:bg-gray-700 py-3 rounded-lg font-semibold">Yes, I did!</button>
                            <button onclick="setGoalCompletion(false, this)" class="goal-btn bg-gray-200 dark:bg-gray-700 py-3 rounded-lg font-semibold">No, not this time.</button>
                        </div>
                        <div id="reason-container" class="mt-4 hidden">
                            <label for="reason-no" class="block font-medium text-gray-700 dark:text-gray-300 mb-1">No worries. What was the reason?</label>
                            <textarea id="reason-no" rows="2" class="w-full p-2 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="e.g., An unexpected issue came up..."></textarea>
                        </div>
                        <div class="mt-6 text-right">
                           <button onclick="nextStep()" class="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-700">Next &rarr;</button>
                        </div>
                    </div>
                    <!-- Step 2: Task Analysis -->
                    <div class="step" data-step="2">
                        <h3 class="text-xl font-semibold text-center mb-4">How did you do with your tasks?</h3>
                        <div class="grid grid-cols-2 gap-4">
                            <div>
                                <label for="tasks-completed-input" class="block font-medium mb-1">Tasks Completed</label>
                                <input type="number" id="tasks-completed-input" min="0" class="w-full p-3 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="e.g., 5">
                            </div>
                            <div>
                                <label for="tasks-failed-input" class="block font-medium mb-1">Tasks Not Completed</label>
                                <input type="number" id="tasks-failed-input" min="0" class="w-full p-3 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="e.g., 2">
                            </div>
                        </div>
                        <div id="solution-container" class="mt-4 hidden">
                             <label for="solution-next-time" class="block font-medium text-gray-700 dark:text-gray-300 mb-1">What's the plan for next time?</label>
                             <textarea id="solution-next-time" rows="2" class="w-full p-2 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="e.g., I will block out my calendar to avoid distractions."></textarea>
                        </div>
                        <div class="mt-8 flex justify-between">
                            <button onclick="prevStep()" class="bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 font-bold py-2 px-6 rounded-lg hover:bg-gray-300">&larr; Back</button>
                            <button onclick="nextStep()" class="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-700">Next &rarr;</button>
                        </div>
                    </div>
                    <!-- Step 3: Wins & Learnings -->
                    <div class="step" data-step="3">
                        <h3 class="text-xl font-semibold text-center mb-4">What did you gain today?</h3>
                        <div class="space-y-4">
                            <div>
                                <label for="special-learning" class="block font-medium mb-1">A key lesson or special learning:</label>
                                <textarea id="special-learning" rows="2" class="w-full p-2 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="Today I learned that..."></textarea>
                            </div>
                            <div>
                                <label for="proud-moment" class="block font-medium mb-1">Something you're proud of (no matter how small):</label>
                                <textarea id="proud-moment" rows="2" class="w-full p-2 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="I was proud of how I handled..."></textarea>
                            </div>
                        </div>
                        <div class="mt-8 flex justify-between">
                            <button onclick="prevStep()" class="bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 font-bold py-2 px-6 rounded-lg hover:bg-gray-300">&larr; Back</button>
                            <button onclick="nextStep()" class="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-700">Next &rarr;</button>
                        </div>
                    </div>
                    <!-- Step 4: Ratings -->
                    <div class="step" data-step="4">
                        <h3 class="text-xl font-semibold text-center mb-6">How would you rate your day?</h3>
                        <div class="grid grid-cols-1 md:grid-cols-2 gap-x-8 gap-y-6">
                             <div>
                                <label for="mood" class="flex justify-between font-medium"><span>😊 Mood</span> <span id="mood-val" class="font-bold">5</span></label>
                                <input type="range" id="mood" min="0" max="10" value="5">
                            </div>
                             <div>
                                <label for="health" class="flex justify-between font-medium"><span>❤️ Health</span> <span id="health-val" class="font-bold">5</span></label>
                                <input type="range" id="health" min="0" max="10" value="5">
                            </div>
                             <div>
                                <label for="productivity" class="flex justify-between font-medium"><span>🚀 Productivity</span> <span id="productivity-val" class="font-bold">5</span></label>
                                <input type="range" id="productivity" min="0" max="10" value="5">
                            </div>
                             <div>
                                <label for="focus" class="flex justify-between font-medium"><span>🎯 Focus</span> <span id="focus-val" class="font-bold">5</span></label>
                                <input type="range" id="focus" min="0" max="10" value="5">
                            </div>
                        </div>
                        <div class="mt-8 flex justify-between">
                            <button onclick="prevStep()" class="bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 font-bold py-2 px-6 rounded-lg hover:bg-gray-300">&larr; Back</button>
                            <button onclick="nextStep()" class="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-700">Next &rarr;</button>
                        </div>
                    </div>
                     <!-- Step 5: Final Thoughts -->
                    <div class="step" data-step="5">
                        <h3 class="text-xl font-semibold text-center mb-4">Any final thoughts?</h3>
                        <div>
                           <label for="day-description" class="block font-medium mb-1">Describe your day in one powerful sentence:</label>
                           <textarea id="day-description" rows="2" class="w-full p-2 bg-gray-100 dark:bg-gray-700 rounded-lg focus:ring-2 focus:ring-indigo-500" placeholder="Today was a day of..."></textarea>
                        </div>
                        <div class="mt-8 flex justify-between">
                            <button onclick="prevStep()" class="bg-gray-200 dark:bg-gray-600 text-gray-800 dark:text-gray-200 font-bold py-2 px-6 rounded-lg hover:bg-gray-300">&larr; Back</button>
                            <button onclick="submitReflection()" class="bg-indigo-600 text-white font-bold py-2 px-6 rounded-lg hover:bg-indigo-700">Finish & See Score</button>
                        </div>
                    </div>
                 </div>
                 <div id="reflection-summary" class="hidden text-center mt-8 bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl"></div>
            </div>
            
            <!-- History View -->
            <div id="history" class="view w-full max-w-2xl fade-in">
                <button onclick="switchView('home')" class="mb-6 text-indigo-600 dark:text-indigo-400 hover:underline font-semibold">&larr; Back to Home</button>
                <h1 class="text-4xl font-bold text-center mb-2">Reflection History</h1>
                 <p class="text-center text-gray-500 dark:text-gray-400 mb-8">Review your journey of growth.</p>
                 <div id="history-list" class="space-y-4">
                    <!-- History items will be injected here -->
                 </div>
            </div>

        </main>
    </div>

    <!-- History Detail Modal -->
    <div id="history-modal" class="fixed inset-0 bg-black bg-opacity-50 hidden items-center justify-center p-4 z-50 fade-in" onclick="closeHistoryModal()">
        <div id="history-modal-content" class="bg-white dark:bg-gray-800 p-8 rounded-2xl shadow-xl w-full max-w-2xl relative max-h-[90vh] overflow-y-auto" onclick="event.stopPropagation()">
            <button onclick="closeHistoryModal()" class="absolute top-4 right-4 text-gray-500 hover:text-gray-800 dark:text-white text-3xl font-bold">&times;</button>
            <div id="history-modal-body">
                <!-- Content will be injected here by JS -->
            </div>
        </div>
    </div>

    <!-- Toast Notification -->
    <div id="toast" class="bg-gray-800 text-white py-2 px-4 rounded-lg shadow-lg">
        <p id="toast-message"></p>
    </div>

    <script>
        // --- State Management ---
        let tasks = [];
        let reflectionData = {};
        let allReflections = []; // To store history for export
        let currentFilter = 'all';
        let currentStep = 1;

        // --- DOM Elements ---
        const views = document.querySelectorAll('.view');
        const taskForm = document.getElementById('task-form');
        const taskInput = document.getElementById('task-input');
        const taskCategory = document.getElementById('task-category');
        const majorFocus = document.getElementById('major-focus');
        const taskList = document.getElementById('task-list');

        // --- Quotes ---
        const quotes = [
            "The mystery of human existence lies not in just staying alive, but in finding something to live for.",
            "The purpose of life is not to be happy. It is to be useful, to be honorable, to be compassionate, to have it make some difference that you have lived and lived well.",
            "He who has a why to live for can bear almost any how.",
            "Your purpose in life is to find your purpose and give your whole heart and soul to it.",
            "The two most important days in your life are the day you are born and the day you find out why."
        ];

        // --- Core Functions ---
        function switchView(viewId) {
            views.forEach(view => view.classList.remove('active'));
            const activeView = document.getElementById(viewId);
            activeView.classList.add('active', 'fade-in');
            setTimeout(() => activeView.classList.remove('fade-in'), 500);

            if (viewId === 'history') {
                renderHistory();
            }
        }

        function saveToLocal() {
            localStorage.setItem('plannerTasks', JSON.stringify(tasks));
            localStorage.setItem('plannerReflections', JSON.stringify(allReflections));
        }

        function loadFromLocal() {
            const localTasks = localStorage.getItem('plannerTasks');
            if (localTasks) {
                tasks = JSON.parse(localTasks);
                renderTasks();
            }
            const localReflections = localStorage.getItem('plannerReflections');
            if (localReflections) {
                allReflections = JSON.parse(localReflections);
            }
        }
        
        function toggleTheme() {
            const html = document.documentElement;
            html.classList.toggle('dark');
            localStorage.setItem('theme', html.classList.contains('dark') ? 'dark' : 'light');
        }

        function showToast(message) {
            const toast = document.getElementById('toast');
            document.getElementById('toast-message').textContent = message;
            toast.classList.add('show');
            setTimeout(() => toast.classList.remove('show'), 3000);
        }
        
        // --- Data Management ---
        function exportData() {
            if (tasks.length === 0 && allReflections.length === 0) {
                showToast("No data to export.");
                return;
            }
            const dataToExport = {
                tasks: tasks,
                reflections: allReflections
            };
            const dataStr = JSON.stringify(dataToExport, null, 2);
            const blob = new Blob([dataStr], {type: "application/json"});
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = `ikigai-data-${new Date().toISOString().split('T')[0]}.json`;
            document.body.appendChild(a);
            a.click();
            document.body.removeChild(a);
            URL.revokeObjectURL(url);
            showToast('Data exported successfully!');
        }

        function importData(event) {
            const file = event.target.files[0];
            if (!file) return;

            const reader = new FileReader();
            reader.onload = function(e) {
                try {
                    const importedData = JSON.parse(e.target.result);
                    if (importedData.tasks && Array.isArray(importedData.tasks) && importedData.reflections && Array.isArray(importedData.reflections)) {
                        tasks = importedData.tasks;
                        allReflections = importedData.reflections;
                        saveToLocal();
                        renderTasks();
                        showToast('Data imported successfully!');
                    } else {
                        showToast('Invalid data file format.');
                    }
                } catch (error) {
                    showToast('Error reading the file.');
                }
            };
            reader.readAsText(file);
            event.target.value = ''; // Reset file input
        }


        // --- Planner Logic ---
        function addTask(event) {
            event.preventDefault();
            const taskText = taskInput.value.trim();
            if (taskText === '') return;

            tasks.unshift({
                id: Date.now(),
                text: taskText,
                category: taskCategory.value,
                isMajor: majorFocus.checked,
                completed: false
            });
            taskForm.reset();
            saveToLocal();
            renderTasks();
            showToast('Task added successfully!');
        }

        function renderTasks() {
            taskList.innerHTML = '';
            const filteredTasks = tasks.filter(task => {
                if (currentFilter === 'all') return true;
                if (currentFilter === 'major') return task.isMajor;
                if (currentFilter === 'minor') return !task.isMajor;
            });

            if (filteredTasks.length === 0) {
                 taskList.innerHTML = `<p class="text-center text-gray-500 dark:text-gray-400 py-8">Your task list is clear. Ready for a new challenge?</p>`;
            } else {
                filteredTasks.forEach(task => {
                    const taskEl = document.createElement('div');
                    taskEl.className = `p-4 rounded-lg flex items-center justify-between transition-all duration-300 group ${task.completed ? 'bg-gray-100 dark:bg-gray-700 opacity-60' : 'bg-gray-50 dark:bg-gray-700/50 hover:bg-gray-100 dark:hover:bg-gray-700'} ${task.isMajor ? 'border-l-4 border-blue-500' : ''}`;
                    
                    const categoryEmoji = {'Passion': '❤️','Profession': '💼','Vocation': '🌱','Mission': '🎯'}[task.category];
                    
                    taskEl.innerHTML = `
                        <div class="flex items-center">
                            <input type="checkbox" onchange="toggleTaskCompletion(${task.id})" class="h-5 w-5 text-green-500 border-gray-300 rounded focus:ring-green-500 cursor-pointer" ${task.completed ? 'checked' : ''}>
                            <div class="ml-4">
                                <p class="font-semibold ${task.completed ? 'line-through text-gray-500' : 'text-gray-800 dark:text-gray-200'}">${task.text}</p>
                                <p class="text-sm text-gray-500 dark:text-gray-400">${categoryEmoji} ${task.category}</p>
                            </div>
                        </div>
                        <button onclick="deleteTask(${task.id})" class="text-gray-400 hover:text-red-500 dark:hover:text-red-400 font-bold text-xl p-2 opacity-0 group-hover:opacity-100 transition-opacity">
                            <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg>
                        </button>
                    `;
                    taskList.appendChild(taskEl);
                });
            }
            updateProgress();
            updateIkigaiDiagram();
        }

        function toggleTaskCompletion(id) {
            const task = tasks.find(t => t.id === id);
            if (task) {
                task.completed = !task.completed;
                saveToLocal();
                renderTasks();
            }
        }

        function updateProgress() {
            const completedTasks = tasks.filter(t => t.completed).length;
            const totalTasks = tasks.length;
            const progress = totalTasks > 0 ? Math.round((completedTasks / totalTasks) * 100) : 0;
            document.getElementById('progress-text').innerText = `${completedTasks}/${totalTasks} tasks completed (${progress}%)`;
        }

        function deleteTask(id) {
            tasks = tasks.filter(task => task.id !== id);
            saveToLocal();
            renderTasks();
        }
        
        function filterTasks(filter, element) {
            currentFilter = filter;
            document.querySelectorAll('.filter-btn').forEach(btn => {
                btn.classList.remove('bg-blue-600', 'text-white');
                btn.classList.add('bg-gray-200', 'dark:bg-gray-700', 'text-gray-800', 'dark:text-gray-200');
            });
            element.classList.add('bg-blue-600', 'text-white');
            element.classList.remove('bg-gray-200', 'dark:bg-gray-700', 'text-gray-800', 'dark:text-gray-200');
            renderTasks();
        }

        function updateIkigaiDiagram() {
            const categories = ['Passion', 'Profession', 'Vocation', 'Mission'];
            categories.forEach(cat => {
                const total = tasks.filter(t => t.category === cat).length;
                const completed = tasks.filter(t => t.category === cat && t.completed).length;
                const progress = total > 0 ? completed / total : 0;
                const circle = document.getElementById(`circle-${cat.toLowerCase()}`);
                if(circle) {
                    circle.style.fillOpacity = 0.1 + (progress * 0.9);
                }
            });
        }


        // --- Reflection Logic ---
        function setGoalCompletion(completed, element) {
            reflectionData.goalCompleted = completed;
            const reasonContainer = document.getElementById('reason-container');
            document.querySelectorAll('.goal-btn').forEach(btn => {
                btn.classList.remove('bg-green-200', 'dark:bg-green-800', 'bg-red-200', 'dark:bg-red-800');
                btn.classList.add('bg-gray-200', 'dark:bg-gray-700');
            });
            if (completed) {
                element.classList.add('bg-green-200', 'dark:bg-green-800');
                reasonContainer.classList.add('hidden');
            } else {
                element.classList.add('bg-red-200', 'dark:bg-red-800');
                reasonContainer.classList.remove('hidden');
            }
        }
        
        document.getElementById('tasks-failed-input').addEventListener('input', (e) => {
            const solutionContainer = document.getElementById('solution-container');
            if (e.target.value > 0) {
                solutionContainer.classList.remove('hidden');
            } else {
                solutionContainer.classList.add('hidden');
            }
        });

        function nextStep() {
            const currentStepEl = document.querySelector(`.step[data-step="${currentStep}"]`);
            const nextStepEl = document.querySelector(`.step[data-step="${currentStep + 1}"]`);
            if (nextStepEl) {
                currentStepEl.classList.remove('active');
                nextStepEl.classList.add('active');
                currentStep++;
            }
        }
        
        function prevStep() {
            const currentStepEl = document.querySelector(`.step[data-step="${currentStep}"]`);
            const prevStepEl = document.querySelector(`.step[data-step="${currentStep - 1}"]`);
            if (prevStepEl) {
                currentStepEl.classList.remove('active');
                prevStepEl.classList.add('active');
                currentStep--;
            }
        }
        
        function submitReflection() {
            const newReflection = {
                date: new Date().toISOString(),
                mainGoal: document.getElementById('main-goal').value,
                goalCompleted: reflectionData.goalCompleted,
                reasonNo: document.getElementById('reason-no').value,
                tasksCompleted: document.getElementById('tasks-completed-input').value || 0,
                tasksFailed: document.getElementById('tasks-failed-input').value || 0,
                solution: document.getElementById('solution-next-time').value,
                learning: document.getElementById('special-learning').value,
                proudMoment: document.getElementById('proud-moment').value,
                mood: parseInt(document.getElementById('mood').value),
                health: parseInt(document.getElementById('health').value),
                productivity: parseInt(document.getElementById('productivity').value),
                focus: parseInt(document.getElementById('focus').value),
                description: document.getElementById('day-description').value,
            };
            
            let score = 0;
            if(newReflection.goalCompleted) score+=2;
            score += parseInt(newReflection.tasksCompleted);
            score -= parseInt(newReflection.tasksFailed);
            if(newReflection.learning) score++;
            if(newReflection.proudMoment) score++;
            if(newReflection.mood > 5) score++;
            if(newReflection.health > 5) score++;
            if(newReflection.productivity > 5) score++;
            if(newReflection.focus > 5) score++;
            
            newReflection.score = Math.max(0, score); // Ensure score isn't negative
            
            allReflections.push(newReflection);
            saveToLocal();
            displayReflectionSummary(newReflection);
        }
        
        function displayReflectionSummary(data) {
            const summaryContainer = document.getElementById('reflection-summary');
            summaryContainer.innerHTML = `
                <h2 class="text-3xl font-bold mb-4 text-indigo-600 dark:text-indigo-400">Today's Recap</h2>
                <div class="text-6xl font-extrabold text-indigo-500 dark:text-indigo-400 my-4">${data.score}</div>
                <p class="text-xl font-semibold mb-6">Today's Score</p>
                <div class="text-left space-y-4 border-t dark:border-gray-700 pt-6">
                    <div><strong>Main Goal:</strong> ${data.mainGoal || 'Not set'} ${data.goalCompleted ? '✔️' : '❌'}</div>
                    ${!data.goalCompleted && data.reasonNo ? `<div><strong>Reason:</strong> ${data.reasonNo}</div>` : ''}
                    <div><strong>Key Learning:</strong> ${data.learning || 'None logged'}</div>
                    <div><strong>Proud Moment:</strong> ${data.proudMoment || 'None logged'}</div>
                    <div class="grid grid-cols-2 gap-4 pt-4">
                        <p><strong>😊 Mood:</strong> ${data.mood}/10</p>
                        <p><strong>❤️ Health:</strong> ${data.health}/10</p>
                        <p><strong>🚀 Productivity:</strong> ${data.productivity}/10</p>
                        <p><strong>🎯 Focus:</strong> ${data.focus}/10</p>
                    </div>
                </div>
                <p class="mt-8 text-lg font-semibold">"${data.description || 'Tomorrow is a new day.'}"</p>
                <button onclick="resetReflection()" class="mt-6 bg-gray-200 dark:bg-gray-700 text-gray-800 dark:text-gray-200 font-bold py-2 px-6 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-600">Start a New Reflection</button>
            `;
            summaryContainer.classList.remove('hidden');
            document.getElementById('reflection-stepper').classList.add('hidden');
        }

        function resetReflection() {
            document.getElementById('reflection-stepper').classList.remove('hidden');
            document.getElementById('reflection-summary').classList.add('hidden');
            
            reflectionData = {}; // Clear temp data

            // Reset to step 1
            document.querySelectorAll('.step').forEach(s => s.classList.remove('active'));
            document.querySelector('.step[data-step="1"]').classList.add('active');
            currentStep = 1;

            // Reset form values
            const idsToReset = ['main-goal', 'reason-no', 'tasks-completed-input', 'tasks-failed-input', 'solution-next-time', 'special-learning', 'proud-moment', 'day-description'];
            idsToReset.forEach(id => document.getElementById(id).value = '');
            ['mood', 'health', 'productivity', 'focus'].forEach(id => {
                const slider = document.getElementById(id);
                slider.value = 5;
                document.getElementById(`${id}-val`).textContent = 5;
            });
            document.querySelectorAll('.goal-btn').forEach(btn => {
                btn.classList.remove('bg-green-200', 'dark:bg-green-800', 'bg-red-200', 'dark:bg-red-800');
                btn.classList.add('bg-gray-200', 'dark:bg-gray-700');
            });
            document.getElementById('reason-container').classList.add('hidden');
            document.getElementById('solution-container').classList.add('hidden');
        }
        
        // --- History Logic ---
        function renderHistory() {
            const historyList = document.getElementById('history-list');
            historyList.innerHTML = '';

            if (allReflections.length === 0) {
                historyList.innerHTML = `<p class="text-center text-gray-500 dark:text-gray-400 py-8">You haven't completed any reflections yet. Finish one to start your history!</p>`;
                return;
            }

            const sortedReflections = [...allReflections].sort((a, b) => new Date(b.date) - new Date(a.date));

            sortedReflections.forEach((reflection, index) => {
                const date = new Date(reflection.date);
                const formattedDate = date.toLocaleDateString(undefined, { year: 'numeric', month: 'long', day: 'numeric' });
                
                const historyItem = document.createElement('div');
                historyItem.className = 'bg-white dark:bg-gray-800 p-4 rounded-lg shadow-md flex justify-between items-center cursor-pointer hover:bg-gray-50 dark:hover:bg-gray-700 transition-colors';
                historyItem.onclick = () => showHistoryDetail(sortedReflections.length - 1 - index);

                historyItem.innerHTML = `
                    <div>
                        <p class="font-semibold text-lg">${formattedDate}</p>
                        <p class="text-sm text-gray-500 dark:text-gray-400">${reflection.mainGoal || 'No goal set'}</p>
                    </div>
                    <div class="text-2xl font-bold text-indigo-500 dark:text-indigo-400">${reflection.score}</div>
                `;
                historyList.appendChild(historyItem);
            });
        }
        
        function showHistoryDetail(originalIndex) {
            const data = allReflections[originalIndex];
            const modalBody = document.getElementById('history-modal-body');
            
            modalBody.innerHTML = `
                <h2 class="text-3xl font-bold mb-4 text-indigo-600 dark:text-indigo-400">Recap for ${new Date(data.date).toLocaleDateString()}</h2>
                <div class="text-6xl font-extrabold text-indigo-500 dark:text-indigo-400 my-4 text-center">${data.score}</div>
                <p class="text-xl font-semibold mb-6 text-center">Day Score</p>
                <div class="text-left space-y-4 border-t dark:border-gray-700 pt-6">
                    <div><strong>Main Goal:</strong> ${data.mainGoal || 'Not set'} ${data.goalCompleted ? '✔️' : '❌'}</div>
                    ${!data.goalCompleted && data.reasonNo ? `<div><strong class="text-red-500">Reason for not completing:</strong> ${data.reasonNo}</div>` : ''}
                    ${data.tasksFailed > 0 && data.solution ? `<div><strong class="text-green-500">Plan for next time:</strong> ${data.solution}</div>` : ''}
                    <div class="border-t dark:border-gray-700 pt-4 mt-4"><strong>Key Learning:</strong> ${data.learning || 'None logged'}</div>
                    <div><strong>Proud Moment:</strong> ${data.proudMoment || 'None logged'}</div>
                    <div class="grid grid-cols-2 gap-4 pt-4 border-t dark:border-gray-700 mt-4">
                        <p><strong>😊 Mood:</strong> ${data.mood}/10</p>
                        <p><strong>❤️ Health:</strong> ${data.health}/10</p>
                        <p><strong>🚀 Productivity:</strong> ${data.productivity}/10</p>
                        <p><strong>🎯 Focus:</strong> ${data.focus}/10</p>
                    </div>
                </div>
                <p class="mt-8 text-lg font-semibold text-center">"${data.description || 'No final thought logged.'}"</p>
            `;

            const modal = document.getElementById('history-modal');
            modal.classList.remove('hidden');
            modal.classList.add('flex');
        }

        function closeHistoryModal() {
             const modal = document.getElementById('history-modal');
             modal.classList.add('hidden');
             modal.classList.remove('flex');
        }


        // --- Event Listeners & Initial Load ---
        taskForm.addEventListener('submit', addTask);
        
        ['mood', 'health', 'productivity', 'focus'].forEach(id => {
            document.getElementById(id).addEventListener('input', (e) => {
                document.getElementById(`${id}-val`).textContent = e.target.value;
            });
        });

        document.addEventListener('DOMContentLoaded', () => {
            loadFromLocal();
            // Display a random quote
            document.getElementById('daily-quote').innerText = `"${quotes[Math.floor(Math.random() * quotes.length)]}"`;
        });
    </script>
</body>
</html>