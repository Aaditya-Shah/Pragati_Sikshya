<?php
// Mobile Navigation Items for Admin
$mobile_nav_items = [
    ['url' => 'index.php', 'icon' => 'layout-dashboard', 'title' => 'Dashboard'],
    ['url' => 'courses.php', 'icon' => 'book-open', 'title' => 'Courses'],
    ['url' => 'users.php', 'icon' => 'users', 'title' => 'Users'],
    ['url' => 'settings.php', 'icon' => 'settings', 'title' => 'Settings']
];

$current_page = basename($_SERVER['PHP_SELF']);
?>
<!-- Mobile Navigation -->
<nav class="mobile-nav lg:hidden">
    <?php foreach ($mobile_nav_items as $item): 
        $is_active = $current_page === $item['url'];
        $classes = 'flex flex-col items-center justify-center p-2 rounded-lg ';
        $classes .= $is_active 
            ? 'bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary' 
            : 'hover:bg-gray-100 dark:hover:bg-dark-bg';
    ?>
    <a href="<?php echo $item['url']; ?>" class="<?php echo $classes; ?>">
        <i data-lucide="<?php echo $item['icon']; ?>" class="w-6 h-6"></i>
        <span class="text-xs mt-1"><?php echo $item['title']; ?></span>
    </a>
    <?php endforeach; ?>
</nav>
