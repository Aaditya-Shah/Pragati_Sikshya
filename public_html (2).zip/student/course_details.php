<?php
require_once '../auth.php';
require_login(['Student']);

if (!isset($_GET['id'])) {
    header("Location: courses.php");
    exit;
}
$course_id = $_GET['id'];
$student_id = $_SESSION['user_id'];

// Fetch course details
$stmt_course = $pdo->prepare("SELECT c.*, u.name as instructor_name FROM courses c JOIN users u ON c.instructor_id = u.id WHERE c.id = ?");
$stmt_course->execute([$course_id]);
$course = $stmt_course->fetch();

if (!$course) { die("Course not found."); }

// Fetch available tests for this course
$stmt_tests = $pdo->prepare("
    SELECT t.id, t.title, t.start_time, t.duration_minutes,
           (SELECT COUNT(*) FROM test_results tr WHERE tr.test_id = t.id AND tr.student_id = ?) as is_taken
    FROM tests t 
    WHERE t.course_id = ?
    ORDER BY t.start_time DESC
");
$stmt_tests->execute([$student_id, $course_id]);
$tests = $stmt_tests->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo htmlspecialchars($course['title']); ?> - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-white dark:bg-dark-surface p-6 hidden lg:flex flex-col">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10"><i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i><span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span></a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="batch.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="users-2"></i><span>My Batch</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="grades.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="clipboard-check"></i><span>Grades</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4 flex justify-between items-center">
                <h1 class="text-2xl font-bold">Course: <?php echo htmlspecialchars($course['title']); ?></h1>
                <div class="flex items-center space-x-4">
                    <button id="theme-toggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-bg"><i data-lucide="sun" class="hidden" id="theme-icon-sun"></i><i data-lucide="moon" class="hidden" id="theme-icon-moon"></i></button>
                    <div class="flex items-center space-x-3"><img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full"><div><h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4><p class="text-sm text-gray-500">Student</p></div></div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border p-6 mb-8">
                    <h2 class="text-2xl font-bold mb-2"><?php echo htmlspecialchars($course['title']); ?></h2>
                    <p class="text-gray-600 dark:text-dark-text-secondary"><?php echo nl2br(htmlspecialchars($course['description'])); ?></p>
                </div>

                <h3 class="text-xl font-semibold mb-4">Available Mock Tests</h3>
                <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border">
                    <div class="space-y-2 p-4">
                        <?php if(empty($tests)): ?>
                            <p class="text-gray-500 p-4">No mock tests available for this course yet.</p>
                        <?php else: ?>
                            <?php foreach($tests as $test): 
                                $is_active = time() >= strtotime($test['start_time']);
                            ?>
                            <div class="p-4 border-b dark:border-dark-border last:border-b-0 flex justify-between items-center">
                                <div>
                                    <p class="font-bold text-lg"><?php echo htmlspecialchars($test['title']); ?></p>
                                    <p class="text-sm text-gray-500">Starts: <?php echo date('M j, Y g:i A', strtotime($test['start_time'])); ?> | Duration: <?php echo $test['duration_minutes']; ?> mins</p>
                                </div>
                                <?php if ($test['is_taken']): ?>
                                    <a href="grades.php" class="px-4 py-2 text-sm bg-green-500 text-white rounded-full flex items-center space-x-2"><i data-lucide="check-circle"></i><span>Completed</span></a>
                                <?php elseif (!$is_active): ?>
                                    <button class="px-4 py-2 text-sm bg-gray-400 text-white rounded-full cursor-not-allowed">Not Started Yet</button>
                                <?php else: ?>
                                    <a href="take_test.php?test_id=<?php echo $test['id']; ?>" class="px-4 py-2 text-sm bg-light-primary dark:bg-dark-primary text-white rounded-full hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover flex items-center space-x-2"><i data-lucide="play"></i><span>Start Test</span></a>
                                <?php endif; ?>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script>
        lucide.createIcons();
        const themeToggle = document.getElementById('theme-toggle'), sunIcon = document.getElementById('theme-icon-sun'), moonIcon = document.getElementById('theme-icon-moon'), htmlEl = document.documentElement;
        const setTheme = (theme) => { htmlEl.classList.toggle('dark', theme === 'dark'); sunIcon.classList.toggle('hidden', theme !== 'dark'); moonIcon.classList.toggle('hidden', theme === 'dark'); localStorage.setItem('theme', theme); };
        themeToggle.addEventListener('click', () => setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'));
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
    </script>
</body>
</html>
