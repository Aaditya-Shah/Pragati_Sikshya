<?php
require_once '../auth.php';
require_login(['Student']);

if (!isset($_GET['result_id'])) {
    header("Location: grades.php");
    exit;
}
$result_id = $_GET['result_id'];
$student_id = $_SESSION['user_id'];

// Fetch the result, ensuring it belongs to the logged-in student
$stmt_result = $pdo->prepare("
    SELECT tr.*, t.title as test_title, c.title as course_title 
    FROM test_results tr
    JOIN tests t ON tr.test_id = t.id
    JOIN courses c ON t.course_id = c.id
    WHERE tr.id = ? AND tr.student_id = ?
");
$stmt_result->execute([$result_id, $student_id]);
$result = $stmt_result->fetch();

if (!$result) { die("Result not found or you do not have permission to view it."); }

// Fetch the questions and correct answers for this test
$stmt_questions = $pdo->prepare("SELECT id, question_text, options, correct_option FROM questions WHERE test_id = ? ORDER BY id ASC");
$stmt_questions->execute([$result['test_id']]);
$questions = $stmt_questions->fetchAll();

$student_answers = json_decode($result['answers'], true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Result: <?php echo htmlspecialchars($result['test_title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="container mx-auto p-6 md:p-8 max-w-4xl">
        <header class="mb-8 border-b dark:border-dark-border pb-4">
            <div class="flex justify-between items-center">
                <div>
                    <p class="text-indigo-600 dark:text-indigo-400 font-semibold"><?php echo htmlspecialchars($result['course_title']); ?></p>
                    <h1 class="text-4xl font-bold text-gray-900 dark:text-white"><?php echo htmlspecialchars($result['test_title']); ?></h1>
                </div>
                <div class="text-right">
                    <p class="text-sm text-gray-500">Final Score</p>
                    <p class="text-4xl font-bold text-light-primary dark:text-dark-primary"><?php echo htmlspecialchars(number_format($result['score'], 2)); ?>%</p>
                </div>
            </div>
        </header>

        <div class="space-y-8">
            <?php foreach($questions as $index => $question): ?>
            <div class="bg-white dark:bg-dark-surface p-6 rounded-lg border dark:border-dark-border">
                <div class="prose dark:prose-invert max-w-none mb-4"><?php echo ($index + 1) . ". " . $question['question_text']; ?></div>
                <div class="space-y-3">
                    <?php 
                    $options = json_decode($question['options'], true);
                    $student_answer = $student_answers[$question['id']] ?? null;
                    $correct_answer = $question['correct_option'];

                    foreach($options as $opt_index => $option):
                        $is_correct = ($opt_index == $correct_answer);
                        $is_student_choice = ($student_answer !== null && $opt_index == $student_answer);
                        
                        $bg_color = 'bg-gray-100 dark:bg-dark-bg'; // Default
                        if ($is_student_choice && $is_correct) {
                            $bg_color = 'bg-green-100 dark:bg-green-500/20 border-green-500';
                        } elseif ($is_student_choice && !$is_correct) {
                            $bg_color = 'bg-red-100 dark:bg-red-500/20 border-red-500';
                        } elseif ($is_correct) {
                            $bg_color = 'bg-green-100 dark:bg-green-500/20 border-green-500';
                        }
                    ?>
                    <div class="flex items-center p-3 rounded-lg border <?php echo $bg_color; ?>">
                        <?php if($is_correct): ?>
                            <i data-lucide="check" class="w-5 h-5 text-green-600 mr-3"></i>
                        <?php elseif($is_student_choice): ?>
                             <i data-lucide="x" class="w-5 h-5 text-red-600 mr-3"></i>
                        <?php else: ?>
                            <div class="w-5 mr-3"></div>
                        <?php endif; ?>
                        <span class="text-gray-700 dark:text-dark-text-secondary"><?php echo htmlspecialchars($option); ?></span>
                    </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <?php endforeach; ?>
        </div>
        <div class="mt-8 text-center">
            <a href="grades.php" class="text-indigo-600 hover:underline">← Back to All Grades</a>
        </div>
    </div>
    <script>
        lucide.createIcons();
    </script>
</body>
</html>
