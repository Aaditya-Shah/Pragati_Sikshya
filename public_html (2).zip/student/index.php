<?php
require_once '../auth.php';
require_login(['Student']);

$student_id = $_SESSION['user_id'];

// Fetch the NEXT upcoming, published, and untaken mock test
$stmt_upcoming_test = $pdo->prepare("
    SELECT t.id, t.title, t.start_time, c.title as course_title
    FROM tests t
    JOIN courses c ON t.course_id = c.id
    WHERE t.course_id IN (SELECT course_id FROM course_enrollments WHERE student_id = ?)
    AND t.status = 'Published'
    AND t.start_time > NOW()
    AND t.id NOT IN (SELECT test_id FROM test_results WHERE student_id = ?)
    ORDER BY t.start_time ASC
    LIMIT 1
");
$stmt_upcoming_test->execute([$student_id, $student_id]);
$upcoming_test = $stmt_upcoming_test->fetch();

// Fetch the MOST RECENT active, published, and untaken mock test
$stmt_active_test = $pdo->prepare("
    SELECT t.id, t.title, t.start_time, t.duration_minutes, c.title as course_title
    FROM tests t
    JOIN courses c ON t.course_id = c.id
    WHERE t.course_id IN (SELECT course_id FROM course_enrollments WHERE student_id = ?)
    AND t.status = 'Published'
    AND t.start_time <= NOW()
    AND DATE_ADD(t.start_time, INTERVAL t.duration_minutes MINUTE) > NOW()
    AND t.id NOT IN (SELECT test_id FROM test_results WHERE student_id = ?)
    ORDER BY t.start_time DESC
    LIMIT 1
");
$stmt_active_test->execute([$student_id, $student_id]);
$active_test = $stmt_active_test->fetch();

// Fetch enrolled courses
$stmt_courses = $pdo->prepare("SELECT c.id, c.title, ce.progress FROM course_enrollments ce JOIN courses c ON ce.course_id = c.id WHERE ce.student_id = ? LIMIT 4");
$stmt_courses->execute([$student_id]);
$enrolled_courses = $stmt_courses->fetchAll();

// Fetch recent grades
$stmt_grades = $pdo->prepare("SELECT tr.id as result_id, c.title AS course_title, t.title AS test_title, tr.score FROM test_results tr JOIN tests t ON tr.test_id = t.id JOIN courses c ON t.course_id = c.id WHERE tr.student_id = ? ORDER BY tr.submitted_at DESC LIMIT 3");
$stmt_grades->execute([$student_id]);
$recent_grades = $stmt_grades->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Dashboard - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex min-h-screen">
        <!-- Sidebar Overlay -->
        <div id="sidebar-overlay" class="fixed inset-0 bg-black bg-opacity-50 z-40 lg:hidden hidden" onclick="toggleSidebar()"></div>
        
        <!-- Sidebar -->
        <aside id="sidebar" class="fixed lg:static w-64 bg-white dark:bg-dark-surface p-6 flex flex-col h-full z-50 transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10">
                <i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i>
                <span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span>
            </a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold">
                    <i data-lucide="layout-dashboard"></i>
                    <span>Dashboard</span>
                </a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="batch.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="users-2"></i><span>My Batch</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="grades.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="clipboard-check"></i><span>Grades</span></a>
                <a href="../chat/" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="message-square"></i><span>Chat</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4">
                <div class="max-w-7xl mx-auto flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <button onclick="toggleSidebar()" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-dark-bg lg:hidden">
                            <i data-lucide="menu"></i>
                        </button>
                        <h1 class="text-2xl font-bold">Student Dashboard</h1>
                    </div>
                    <div class="flex items-center space-x-4">
                        <button id="theme-toggle" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-dark-bg flex items-center justify-center">
                            <i data-lucide="sun" class="hidden" id="theme-icon-sun"></i>
                            <i data-lucide="moon" class="hidden" id="theme-icon-moon"></i>
                        </button>
                        <div class="relative" id="profile-menu">
                            <button onclick="toggleProfileMenu()" class="flex items-center space-x-3 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg p-2">
                                <img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full object-cover">
                                <div class="hidden md:block">
                                    <h4 class="font-semibold text-left"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
                                    <p class="text-sm text-gray-500">Student</p>
                                </div>
                                <i data-lucide="chevron-down" class="h-5 w-5 text-gray-500"></i>
                            </button>
                            <!-- Profile Dropdown -->
                            <div id="profile-dropdown" class="absolute right-0 mt-2 w-48 bg-white dark:bg-dark-surface rounded-lg shadow-lg py-2 hidden z-50 border dark:border-dark-border">
                                <a href="settings.php" class="flex items-center space-x-2 px-4 py-2 text-gray-700 dark:text-dark-text hover:bg-gray-100 dark:hover:bg-dark-bg">
                                    <i data-lucide="settings" class="h-5 w-5"></i>
                                    <span>Settings</span>
                                </a>
                                <form action="../auth.php" method="POST" class="w-full">
                                    <input type="hidden" name="action" value="logout">
                                    <button type="submit" class="flex items-center space-x-2 w-full px-4 py-2 text-red-500 hover:bg-gray-100 dark:hover:bg-dark-bg">
                                        <i data-lucide="log-out" class="h-5 w-5"></i>
                                        <span>Logout</span>
                                    </button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <h2 class="text-3xl font-bold mb-6">Welcome back, <?php echo htmlspecialchars(explode(' ', $_SESSION['user_name'])[0]); ?>!</h2>
                
                <!-- Active Mock Test Section -->
                <?php if ($active_test): ?>
                <div class="bg-indigo-600 dark:bg-indigo-800 text-white p-6 rounded-lg mb-8 shadow-lg">
                    <div class="flex justify-between items-center">
                        <div>
                            <p class="text-indigo-200 font-semibold">Active Test Available</p>
                            <h3 class="text-2xl font-bold"><?php echo htmlspecialchars($active_test['title']); ?></h3>
                            <p class="text-indigo-200 text-sm"><?php echo htmlspecialchars($active_test['course_title']); ?></p>
                        </div>
                        <a href="take_test.php?test_id=<?php echo $active_test['id']; ?>" class="bg-white text-indigo-600 font-bold py-3 px-6 rounded-lg hover:bg-gray-200 flex items-center space-x-2 transition-transform hover:scale-105">
                            <i data-lucide="play-circle"></i>
                            <span>Start Test Now</span>
                        </a>
                    </div>
                </div>
                <?php elseif ($upcoming_test): ?>
                <div class="bg-sky-600 dark:bg-sky-800 text-white p-6 rounded-lg mb-8 shadow-lg">
                    <div>
                        <p class="text-sky-200 font-semibold">Next Upcoming Test</p>
                        <h3 class="text-2xl font-bold"><?php echo htmlspecialchars($upcoming_test['title']); ?></h3>
                        <p class="text-sky-200 text-sm"><?php echo htmlspecialchars($upcoming_test['course_title']); ?> - Starts on <?php echo date('M j \a\t g:i A', strtotime($upcoming_test['start_time'])); ?></p>
                    </div>
                </div>
                <?php endif; ?>

                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div class="lg:col-span-2">
                        <h3 class="text-xl font-semibold mb-4">My Courses</h3>
                        <?php if (empty($enrolled_courses)): ?>
                            <p class="text-gray-500">You are not enrolled in any courses yet.</p>
                        <?php else: ?>
                        <div class="grid md:grid-cols-2 gap-6">
                            <?php foreach($enrolled_courses as $course): ?>
                            <div class="bg-white dark:bg-dark-surface p-6 rounded-lg border dark:border-dark-border flex flex-col">
                                <h4 class="font-bold text-lg mb-2 flex-grow"><?php echo htmlspecialchars($course['title']); ?></h4>
                                <div class="w-full bg-gray-200 dark:bg-dark-bg rounded-full h-2.5"><div class="bg-light-primary dark:bg-dark-primary h-2.5 rounded-full" style="width: <?php echo htmlspecialchars($course['progress']); ?>%"></div></div>
                                <p class="text-right text-sm mt-1 mb-4"><?php echo htmlspecialchars($course['progress']); ?>% Complete</p>
                                <a href="course_details.php?id=<?php echo $course['id']; ?>" class="w-full mt-auto text-center block bg-gray-200 dark:bg-dark-border font-bold py-2 px-4 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-700">View Course</a>
                            </div>
                            <?php endforeach; ?>
                        </div>
                        <?php endif; ?>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold mb-4">Recent Grades</h3>
                         <?php if (empty($recent_grades)): ?>
                            <p class="text-gray-500">No grades have been recorded yet.</p>
                        <?php else: ?>
                        <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border">
                            <div class="divide-y dark:divide-dark-border">
                                <?php foreach($recent_grades as $grade): ?>
                                <div class="p-4">
                                    <div class="flex justify-between items-center">
                                        <div>
                                            <p class="font-semibold"><?php echo htmlspecialchars($grade['test_title']); ?></p>
                                            <p class="text-sm text-gray-500"><?php echo htmlspecialchars($grade['course_title']); ?></p>
                                        </div>
                                        <p class="font-bold text-lg text-light-primary dark:text-dark-primary"><?php echo htmlspecialchars(number_format($grade['score'], 0)); ?>%</p>
                                    </div>
                                    <a href="view_result.php?result_id=<?php echo $grade['result_id']; ?>" class="text-sm text-indigo-600 hover:underline mt-1 inline-block">View Paper</a>
                                </div>
                                <?php endforeach; ?>
                            </div>
                            <a href="grades.php" class="block w-full text-center p-3 font-semibold text-indigo-600 dark:text-indigo-400 hover:bg-gray-50 dark:hover:bg-dark-bg border-t dark:border-dark-border">View All Grades</a>
                        </div>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script>
        // Initialize Lucide icons
        lucide.createIcons();

        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle');
        const sunIcon = document.getElementById('theme-icon-sun');
        const moonIcon = document.getElementById('theme-icon-moon');
        const htmlEl = document.documentElement;

        const setTheme = (theme) => {
            htmlEl.classList.toggle('dark', theme === 'dark');
            sunIcon.classList.toggle('hidden', theme !== 'dark');
            moonIcon.classList.toggle('hidden', theme === 'dark');
            localStorage.setItem('theme', theme);
        };

        themeToggle.addEventListener('click', () => {
            setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark');
        });

        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        // Sidebar Toggle
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            
            sidebar.classList.toggle('-translate-x-full');
            overlay.classList.toggle('hidden');
            
            // Prevent body scroll when sidebar is open
            document.body.classList.toggle('overflow-hidden', !overlay.classList.contains('hidden'));
        }

        // Profile Menu Toggle
        function toggleProfileMenu() {
            const dropdown = document.getElementById('profile-dropdown');
            dropdown.classList.toggle('hidden');

            // Close dropdown when clicking outside
            const closeDropdown = (e) => {
                if (!dropdown.contains(e.target) && !e.target.closest('#profile-menu')) {
                    dropdown.classList.add('hidden');
                    document.removeEventListener('click', closeDropdown);
                }
            };

            if (!dropdown.classList.contains('hidden')) {
                setTimeout(() => {
                    document.addEventListener('click', closeDropdown);
                }, 0);
            }
        }

        // Mobile optimizations
        document.addEventListener('touchstart', function() {}, {passive: true});
        
        // Fix for iOS vh issue
        function setVHVariable() {
            let vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty('--vh', `${vh}px`);
        }
        
        window.addEventListener('resize', setVHVariable);
        setVHVariable();

        // Handle screen rotation
        window.addEventListener('orientationchange', () => {
            setTimeout(setVHVariable, 100);
        });

        // Prevent pull-to-refresh
        document.body.addEventListener('touchmove', function(e) {
            if (window.innerHeight >= document.documentElement.scrollHeight) {
                e.preventDefault();
            }
        }, { passive: false });
    </script>

    <!-- Add smooth transition styles -->
    <style>
        .transform {
            transition-property: transform;
            transition-timing-function: cubic-bezier(0.4, 0, 0.2, 1);
            transition-duration: 300ms;
        }
        
        @media (max-width: 1024px) {
            #sidebar {
                box-shadow: 0 0 50px rgba(0,0,0,0.3);
            }
        }

        .animate-fade {
            animation: fadeIn 0.3s ease-out;
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        /* Premium feel improvements */
        .hover\:scale-up {
            transition: transform 0.2s ease;
        }
        
        .hover\:scale-up:hover {
            transform: translateY(-2px);
        }

        /* Smooth scrolling */
        .smooth-scroll {
            scroll-behavior: smooth;
        }

        /* Better touch feedback */
        @media (hover: none) {
            .hover\:bg-gray-100:active {
                background-color: rgba(243, 244, 246, 0.4);
            }
        }
    </style>
</body>
</html>
