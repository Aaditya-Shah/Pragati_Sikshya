<?php
require_once '../auth.php';
require_login(['Student']);

$student_id = $_SESSION['user_id'];

// Fetch all courses the student is enrolled in
$stmt_courses = $pdo->prepare("
    SELECT c.id, c.title, c.description, c.image_url, u.name as instructor_name, ce.progress
    FROM course_enrollments ce
    JOIN courses c ON ce.course_id = c.id
    JOIN users u ON c.instructor_id = u.id
    WHERE ce.student_id = ?
");
$stmt_courses->execute([$student_id]);
$enrolled_courses = $stmt_courses->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Courses - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-white dark:bg-dark-surface p-6 hidden lg:flex flex-col">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10"><i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i><span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span></a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="batch.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="users-2"></i><span>My Batch</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="grades.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="clipboard-check"></i><span>Grades</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4 flex justify-between items-center">
                <h1 class="text-2xl font-bold">My Courses</h1>
                <div class="flex items-center space-x-4">
                    <button id="theme-toggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-bg"><i data-lucide="sun" class="hidden" id="theme-icon-sun"></i><i data-lucide="moon" class="hidden" id="theme-icon-moon"></i></button>
                    <div class="flex items-center space-x-3"><img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full"><div><h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4><p class="text-sm text-gray-500">Student</p></div></div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php if(empty($enrolled_courses)): ?>
                        <p class="text-gray-500 col-span-full">You are not enrolled in any courses yet.</p>
                    <?php else: ?>
                        <?php foreach($enrolled_courses as $course): ?>
                        <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border overflow-hidden flex flex-col">
                            <img src="<?php echo BASE_URL . htmlspecialchars($course['image_url'] ?? 'https://placehold.co/600x400/e2e8f0/e2e8f0?text=No+Image'); ?>" alt="<?php echo htmlspecialchars($course['title']); ?>" class="w-full h-40 object-cover">
                            <div class="p-6 flex flex-col flex-grow">
                                <h3 class="text-xl font-bold mb-2 flex-grow"><?php echo htmlspecialchars($course['title']); ?></h3>
                                <p class="text-sm text-gray-500 mb-4">Instructor: <?php echo htmlspecialchars($course['instructor_name']); ?></p>
                                <div class="w-full bg-gray-200 dark:bg-dark-bg rounded-full h-2.5 mb-2"><div class="bg-light-primary dark:bg-dark-primary h-2.5 rounded-full" style="width: <?php echo htmlspecialchars($course['progress']); ?>%"></div></div>
                                <p class="text-right text-sm mb-4"><?php echo htmlspecialchars($course['progress']); ?>% Complete</p>
                                <a href="course_details.php?id=<?php echo $course['id']; ?>" class="w-full mt-auto text-center block bg-light-primary dark:bg-dark-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover">View Course</a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <script>
        lucide.createIcons();
        const themeToggle = document.getElementById('theme-toggle'), sunIcon = document.getElementById('theme-icon-sun'), moonIcon = document.getElementById('theme-icon-moon'), htmlEl = document.documentElement;
        const setTheme = (theme) => { htmlEl.classList.toggle('dark', theme === 'dark'); sunIcon.classList.toggle('hidden', theme !== 'dark'); moonIcon.classList.toggle('hidden', theme === 'dark'); localStorage.setItem('theme', theme); };
        themeToggle.addEventListener('click', () => setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'));
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
    </script>
</body>
</html>
