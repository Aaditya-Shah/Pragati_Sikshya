<?php
require_once '../auth.php';
require_login(['Student']);

$stmt_grades = $pdo->prepare("SELECT tr.id as result_id, c.title AS course_title, t.title AS test_title, tr.score, tr.submitted_at FROM test_results tr JOIN tests t ON tr.test_id = t.id JOIN courses c ON t.course_id = c.id WHERE tr.student_id = ? ORDER BY tr.submitted_at DESC");
$stmt_grades->execute([$_SESSION['user_id']]);
$all_grades = $stmt_grades->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Grades - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style>
        body { 
            font-family: 'Inter', sans-serif;
            height: 100vh;
            height: calc(var(--vh, 1vh) * 100);
            overflow-x: hidden;
        }
        .sidebar {
            height: 100vh;
            height: calc(var(--vh, 1vh) * 100);
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            transition: transform 0.3s ease-in-out;
        }
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e5e7eb;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1px;
            padding: 0.5rem;
            z-index: 50;
        }
        @media (prefers-color-scheme: dark) {
            .mobile-nav {
                background: #252526;
                border-color: #333333;
            }
        }
        .dark .mobile-nav {
            background: #252526;
            border-color: #333333;
        }
        /* Add padding to main content to prevent overlap with mobile nav */
        @media (max-width: 1024px) {
            main {
                padding-bottom: 5rem !important;
            }
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <!-- Sidebar Overlay -->
    <div id="sidebar-overlay" class="fixed inset-0 bg-black/50 backdrop-blur-[2px] z-40 lg:hidden hidden" onclick="toggleSidebar()"></div>
    
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="sidebar fixed lg:relative w-64 bg-white dark:bg-dark-surface p-6 flex flex-col h-full z-50 -translate-x-full lg:translate-x-0">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10">
                <i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i>
                <span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span>
            </a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="batch.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="users-2"></i><span>My Batch</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="grades.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="clipboard-check"></i><span>Grades</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4">
                <div class="max-w-7xl mx-auto flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <button onclick="toggleSidebar()" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-dark-bg lg:hidden">
                            <i data-lucide="menu"></i>
                        </button>
                        <h1 class="text-2xl font-bold">My Grades</h1>
                    </div>
                    
                    <div class="flex items-center space-x-4">
                        <button id="theme-toggle" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-dark-bg">
                            <i data-lucide="sun" class="hidden" id="theme-icon-sun"></i>
                            <i data-lucide="moon" class="hidden" id="theme-icon-moon"></i>
                        </button>
                        <div class="relative" id="profile-menu">
                            <button onclick="toggleProfileMenu()" class="flex items-center space-x-3 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg p-2">
                                <img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full object-cover">
                                <div class="hidden md:block text-left">
                                    <h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
                                    <p class="text-sm text-gray-500">Student</p>
                                </div>
                            </button>
                        </div>
                    </div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border">
                    <table class="w-full text-left">
                        <thead class="border-b dark:border-dark-border"><tr><th class="p-4 font-semibold">Course</th><th class="p-4 font-semibold">Test</th><th class="p-4 font-semibold">Date Submitted</th><th class="p-4 font-semibold">Score</th><th class="p-4 font-semibold">Details</th></tr></thead>
                        <tbody>
                            <?php if(empty($all_grades)): ?>
                                <tr><td colspan="5" class="p-4 text-center text-gray-500">No grades recorded yet.</td></tr>
                            <?php else: ?>
                                <?php foreach($all_grades as $grade): ?>
                                <tr class="border-b dark:border-dark-border last:border-0">
                                    <td class="p-4"><?php echo htmlspecialchars($grade['course_title']); ?></td>
                                    <td class="p-4"><?php echo htmlspecialchars($grade['test_title']); ?></td>
                                    <td class="p-4 text-gray-500"><?php echo date('M j, Y', strtotime($grade['submitted_at'])); ?></td>
                                    <td class="p-4 font-bold text-light-primary dark:text-dark-primary"><?php echo htmlspecialchars(number_format($grade['score'], 2)); ?>%</td>
                                    <td class="p-4"><a href="view_result.php?result_id=<?php echo $grade['result_id']; ?>" class="text-indigo-600 hover:underline">View Paper</a></td>
                                </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </main>
        </div>
    </div>
    <!-- Mobile Navigation -->
    <nav class="mobile-nav lg:hidden">
        <a href="index.php" class="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg">
            <i data-lucide="layout-dashboard" class="w-6 h-6"></i>
            <span class="text-xs mt-1">Dashboard</span>
        </a>
        <a href="courses.php" class="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg">
            <i data-lucide="book-open" class="w-6 h-6"></i>
            <span class="text-xs mt-1">Courses</span>
        </a>
        <a href="grades.php" class="flex flex-col items-center justify-center p-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary">
            <i data-lucide="clipboard-check" class="w-6 h-6"></i>
            <span class="text-xs mt-1">Grades</span>
        </a>
        <a href="settings.php" class="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg">
            <i data-lucide="settings" class="w-6 h-6"></i>
            <span class="text-xs mt-1">Settings</span>
        </a>
    </nav>

    <script>
        // Initialize icons
        lucide.createIcons();

        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle');
        const sunIcon = document.getElementById('theme-icon-sun');
        const moonIcon = document.getElementById('theme-icon-moon');
        const htmlEl = document.documentElement;

        const setTheme = (theme) => {
            htmlEl.classList.toggle('dark', theme === 'dark');
            sunIcon.classList.toggle('hidden', theme !== 'dark');
            moonIcon.classList.toggle('hidden', theme === 'dark');
            localStorage.setItem('theme', theme);
        };

        themeToggle.addEventListener('click', () => setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'));
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        // Mobile Optimizations
        function setVHVariable() {
            let vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty('--vh', `${vh}px`);
        }

        // Initialize
        setVHVariable();
        window.addEventListener('resize', setVHVariable);
        window.addEventListener('orientationchange', () => setTimeout(setVHVariable, 100));

        // Sidebar Toggle
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            
            sidebar.classList.toggle('-translate-x-full');
            overlay.classList.toggle('hidden');
            document.body.classList.toggle('overflow-hidden');
        }

        // Profile Menu Toggle
        function toggleProfileMenu() {
            const menu = document.getElementById('profile-menu');
            const dropdownExists = menu.querySelector('.profile-dropdown');
            
            if (!dropdownExists) {
                const dropdown = document.createElement('div');
                dropdown.className = 'profile-dropdown absolute right-0 mt-2 w-48 py-2';
                dropdown.innerHTML = `
                    <a href="settings.php" class="flex items-center px-4 py-2 hover:bg-gray-100 dark:hover:bg-dark-bg">
                        <i data-lucide="settings" class="w-4 h-4 mr-2"></i>
                        Settings
                    </a>
                    <form action="../auth.php" method="POST">
                        <input type="hidden" name="action" value="logout">
                        <button type="submit" class="flex items-center w-full px-4 py-2 text-red-500 hover:bg-gray-100 dark:hover:bg-dark-bg">
                            <i data-lucide="log-out" class="w-4 h-4 mr-2"></i>
                            Logout
                        </button>
                    </form>
                `;
                menu.appendChild(dropdown);
                lucide.createIcons();
            } else {
                dropdownExists.remove();
            }
        }

        // Touch Events Optimization
        document.addEventListener('touchstart', function() {}, {passive: true});
        
        // Prevent pull-to-refresh on mobile when at top of page
        document.body.addEventListener('touchmove', function(e) {
            if (window.pageYOffset === 0 && document.documentElement.scrollTop === 0) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // Close sidebar when clicking outside
        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            if (sidebar && overlay && !sidebar.contains(e.target) && !e.target.closest('[onclick*="toggleSidebar"]')) {
                sidebar.classList.add('-translate-x-full');
                overlay.classList.add('hidden');
                document.body.classList.remove('overflow-hidden');
            }

            // Close profile dropdown when clicking outside
            const profileMenu = document.getElementById('profile-menu');
            if (profileMenu && !profileMenu.contains(e.target)) {
                const dropdown = profileMenu.querySelector('.profile-dropdown');
                if (dropdown) dropdown.remove();
            }
        });

        // Responsive table for mobile
        if (window.innerWidth < 768) {
            const table = document.querySelector('table');
            table.classList.add('block', 'overflow-x-auto', '-mx-6');
        }
    </script>
</body>
</html>
