<?php
require_once '../auth.php';
require_login(['Student']);

$student_id = $_SESSION['user_id'];

// Fetch the student's batch information
$stmt_batch = $pdo->prepare("
    SELECT b.name, b.start_year, b.end_year
    FROM batches b
    JOIN batch_enrollments be ON b.id = be.batch_id
    WHERE be.student_id = ?
");
$stmt_batch->execute([$student_id]);
$batch = $stmt_batch->fetch();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>My Batch - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style>
        body { 
            font-family: 'Inter', sans-serif;
            height: 100vh;
            height: calc(var(--vh, 1vh) * 100);
            overflow-x: hidden;
        }
        .sidebar {
            height: 100vh;
            height: calc(var(--vh, 1vh) * 100);
            overflow-y: auto;
            -webkit-overflow-scrolling: touch;
            transition: transform 0.3s ease-in-out;
        }
        .mobile-nav {
            position: fixed;
            bottom: 0;
            left: 0;
            right: 0;
            background: white;
            border-top: 1px solid #e5e7eb;
            display: grid;
            grid-template-columns: repeat(4, 1fr);
            gap: 1px;
            padding: 0.5rem;
            z-index: 50;
        }
        @media (prefers-color-scheme: dark) {
            .mobile-nav {
                background: #252526;
                border-color: #333333;
            }
        }
        .dark .mobile-nav {
            background: #252526;
            border-color: #333333;
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <!-- Sidebar Overlay -->
    <div id="sidebar-overlay" class="fixed inset-0 bg-black/50 backdrop-blur-[2px] z-40 lg:hidden hidden" onclick="toggleSidebar()"></div>
    
    <div class="flex min-h-screen">
        <!-- Sidebar -->
        <aside id="sidebar" class="sidebar fixed lg:relative w-64 bg-white dark:bg-dark-surface p-6 flex flex-col h-full z-50 -translate-x-full lg:translate-x-0">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10">
                <i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i>
                <span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span>
            </a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="batch.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="users-2"></i><span>My Batch</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="grades.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="clipboard-check"></i><span>Grades</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto">
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10">
                    <i data-lucide="log-out"></i>
                    <span>Logout</span>
                </button>
            </form>
        </aside>

        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4">
                <div class="max-w-7xl mx-auto flex justify-between items-center">
                    <div class="flex items-center space-x-4">
                        <button onclick="toggleSidebar()" class="p-2 rounded-lg hover:bg-gray-200 dark:hover:bg-dark-bg lg:hidden">
                            <i data-lucide="menu"></i>
                        </button>
                        <h1 class="text-2xl font-bold">My Batch</h1>
                    </div>
                <div class="flex items-center space-x-4">
                    <button id="theme-toggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-bg"><i data-lucide="sun" class="hidden" id="theme-icon-sun"></i><i data-lucide="moon" class="hidden" id="theme-icon-moon"></i></button>
                    <div class="flex items-center space-x-3"><img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full"><div><h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4><p class="text-sm text-gray-500">Student</p></div></div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <div class="max-w-lg mx-auto bg-white dark:bg-dark-surface p-8 rounded-lg border dark:border-dark-border">
                    <h2 class="text-2xl font-bold mb-6 text-center">Batch Information</h2>
                    <?php if($batch): ?>
                    <div class="space-y-4 text-center">
                        <div>
                            <p class="text-sm text-gray-500">Batch Name</p>
                            <p class="text-xl font-semibold"><?php echo htmlspecialchars($batch['name']); ?></p>
                        </div>
                        <div>
                            <p class="text-sm text-gray-500">Session</p>
                            <p class="text-xl font-semibold"><?php echo htmlspecialchars($batch['start_year']); ?> - <?php echo htmlspecialchars($batch['end_year']); ?></p>
                        </div>
                    </div>
                    <?php else: ?>
                    <p class="text-center text-gray-500">You have not been assigned to a batch yet.</p>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <!-- Mobile Navigation -->
    <nav class="mobile-nav lg:hidden">
        <a href="index.php" class="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg">
            <i data-lucide="layout-dashboard" class="w-6 h-6"></i>
            <span class="text-xs mt-1">Dashboard</span>
        </a>
        <a href="courses.php" class="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg">
            <i data-lucide="book-open" class="w-6 h-6"></i>
            <span class="text-xs mt-1">Courses</span>
        </a>
        <a href="grades.php" class="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg">
            <i data-lucide="clipboard-check" class="w-6 h-6"></i>
            <span class="text-xs mt-1">Grades</span>
        </a>
        <a href="settings.php" class="flex flex-col items-center justify-center p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg">
            <i data-lucide="settings" class="w-6 h-6"></i>
            <span class="text-xs mt-1">Settings</span>
        </a>
    </nav>

    <script>
        // Initialize icons
        lucide.createIcons();

        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle');
        const sunIcon = document.getElementById('theme-icon-sun');
        const moonIcon = document.getElementById('theme-icon-moon');
        const htmlEl = document.documentElement;

        const setTheme = (theme) => {
            htmlEl.classList.toggle('dark', theme === 'dark');
            sunIcon.classList.toggle('hidden', theme !== 'dark');
            moonIcon.classList.toggle('hidden', theme === 'dark');
            localStorage.setItem('theme', theme);
        };

        themeToggle.addEventListener('click', () => setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'));
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        // Mobile Optimizations
        function setVHVariable() {
            let vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty('--vh', `${vh}px`);
        }

        // Initialize
        setVHVariable();
        window.addEventListener('resize', setVHVariable);
        window.addEventListener('orientationchange', () => setTimeout(setVHVariable, 100));

        // Sidebar Toggle
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            
            sidebar.classList.toggle('-translate-x-full');
            overlay.classList.toggle('hidden');
            document.body.classList.toggle('overflow-hidden');
        }

        // Touch Events Optimization
        document.addEventListener('touchstart', function() {}, {passive: true});
        
        // Prevent pull-to-refresh on mobile when at top of page
        document.body.addEventListener('touchmove', function(e) {
            if (window.pageYOffset === 0 && document.documentElement.scrollTop === 0) {
                e.preventDefault();
            }
        }, { passive: false });
        
        // Close sidebar when clicking outside
        document.addEventListener('click', function(e) {
            const sidebar = document.getElementById('sidebar');
            const overlay = document.getElementById('sidebar-overlay');
            if (!sidebar.contains(e.target) && !e.target.closest('[onclick*="toggleSidebar"]')) {
                sidebar.classList.add('-translate-x-full');
                overlay.classList.add('hidden');
                document.body.classList.remove('overflow-hidden');
            }
        });
    </script>
</body>
</html>
