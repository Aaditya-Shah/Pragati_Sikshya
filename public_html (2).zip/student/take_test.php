<?php
require_once '../auth.php';
require_login(['Student']);

if (!isset($_GET['test_id'])) {
    header("Location: index.php");
    exit;
}
$test_id = $_GET['test_id'];
$student_id = $_SESSION['user_id'];

// Check if student has already taken this test
$stmt_check = $pdo->prepare("SELECT id FROM test_results WHERE test_id = ? AND student_id = ?");
$stmt_check->execute([$test_id, $student_id]);
$result = $stmt_check->fetch();
if ($result) {
    // Redirect to the results page if already taken
    header("Location: view_result.php?result_id=" . $result['id']);
    exit;
}

// Handle test submission
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'submit_test') {
    try {
        $answers = $_POST['answers'] ?? [];
        $stmt_correct = $pdo->prepare("SELECT id, correct_option FROM questions WHERE test_id = ?");
        $stmt_correct->execute([$test_id]);
        $correct_answers = $stmt_correct->fetchAll(PDO::FETCH_KEY_PAIR);
        
        $score = 0;
        $total_questions = count($correct_answers);
        foreach ($answers as $question_id => $student_answer) {
            if (isset($correct_answers[$question_id]) && (int)$student_answer === $correct_answers[$question_id]) {
                $score++;
            }
        }
        
        $percentage_score = ($total_questions > 0) ? ($score / $total_questions) * 100 : 0;
        
        $stmt_save = $pdo->prepare("INSERT INTO test_results (test_id, student_id, score, answers) VALUES (?, ?, ?, ?)");
        $stmt_save->execute([$test_id, $student_id, $percentage_score, json_encode($answers)]);
        
        header("Location: grades.php?success=test_submitted");
        exit;
    } catch (PDOException $e) {
        // This will catch any database errors and prevent the 500 error page.
        die("Database error during submission. Please contact an administrator. Error: " . $e->getMessage());
    }
}

// Fetch test details
$stmt_test = $pdo->prepare("SELECT t.title, c.title as course_title, t.duration_minutes, t.start_time FROM tests t JOIN courses c ON t.course_id = c.id WHERE t.id = ? AND t.status = 'Published'");
$stmt_test->execute([$test_id]);
$test = $stmt_test->fetch();
if (!$test) { die("Test not found or is not published."); }

// Calculate remaining time
$start_timestamp = strtotime($test['start_time']);
$end_timestamp = $start_timestamp + ($test['duration_minutes'] * 60);
$current_timestamp = time();
$time_remaining = $end_timestamp - $current_timestamp;

if ($time_remaining <= 0) {
    die("This test has expired. <a href='index.php'>Back to dashboard</a>.");
}

$stmt_questions = $pdo->prepare("SELECT id, question_text, options FROM questions WHERE test_id = ?");
$stmt_questions->execute([$test_id]);
$questions = $stmt_questions->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Take Test: <?php echo htmlspecialchars($test['title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style> 
        body { font-family: 'Inter', sans-serif; } 
        .prose { max-width: 100%; }
        .prose code { background-color: #f3f4f6; padding: 0.2em 0.4em; margin: 0; font-size: 85%; border-radius: 3px; }
        .dark .prose code { background-color: #374151; }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="container mx-auto p-6 md:p-8 max-w-4xl">
        <header class="mb-8 border-b dark:border-dark-border pb-4">
            <div class="flex justify-between items-center">
                <div>
                    <p class="text-indigo-600 dark:text-indigo-400 font-semibold"><?php echo htmlspecialchars($test['course_title']); ?></p>
                    <h1 class="text-4xl font-bold text-gray-900 dark:text-white"><?php echo htmlspecialchars($test['title']); ?></h1>
                </div>
                <div id="timer" class="text-2xl font-bold bg-red-100 text-red-700 dark:bg-red-500/20 dark:text-red-300 px-4 py-2 rounded-lg"></div>
            </div>
        </header>

        <form id="test-form" action="take_test.php?test_id=<?php echo $test_id; ?>" method="POST">
            <input type="hidden" name="action" value="submit_test">
            <div class="space-y-8">
                <?php foreach($questions as $index => $question): ?>
                <div class="bg-white dark:bg-dark-surface p-6 rounded-lg border dark:border-dark-border">
                    <div class="prose dark:prose-invert max-w-none mb-4"><?php echo ($index + 1) . ". " . $question['question_text']; ?></div>
                    <div class="space-y-3">
                        <?php 
                        $options = json_decode($question['options'], true);
                        if (is_array($options)):
                            foreach($options as $opt_index => $option):
                        ?>
                        <label class="flex items-center p-3 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg cursor-pointer">
                            <input type="radio" name="answers[<?php echo $question['id']; ?>]" value="<?php echo $opt_index; ?>" class="h-4 w-4 text-indigo-600 border-gray-300 focus:ring-indigo-500" required>
                            <span class="ml-3 text-gray-700 dark:text-dark-text-secondary"><?php echo htmlspecialchars($option); ?></span>
                        </label>
                        <?php 
                            endforeach; 
                        endif;
                        ?>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <div class="mt-8">
                <button type="submit" class="w-full bg-light-primary dark:bg-dark-primary text-white font-bold py-4 px-6 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover text-lg">Submit Test</button>
            </div>
        </form>
    </div>
    <script>
        lucide.createIcons();
        const timerElement = document.getElementById('timer');
        const testForm = document.getElementById('test-form');
        let timeLeft = <?php echo $time_remaining; ?>;

        const timerInterval = setInterval(() => {
            timeLeft--;
            const minutes = Math.floor(timeLeft / 60);
            const seconds = timeLeft % 60;
            timerElement.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
            if (timeLeft <= 0) {
                clearInterval(timerInterval);
                timerElement.textContent = "Time's Up!";
                testForm.submit();
            }
        }, 1000);
    </script>
</body>
</html>
