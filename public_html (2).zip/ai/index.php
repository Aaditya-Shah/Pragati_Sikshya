<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gemini Chat Box</title>
    <!-- Tailwind CSS for styling -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- marked.js for rendering markdown responses -->
    <script src="https://cdn.jsdelivr.net/npm/marked/marked.min.js"></script>
    <!-- Google Fonts -->
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }
        /* Simple scrollbar styling */
        ::-webkit-scrollbar {
            width: 8px;
        }
        ::-webkit-scrollbar-track {
            background: #f1f1f1;
        }
        ::-webkit-scrollbar-thumb {
            background: #888;
            border-radius: 10px;
        }
        ::-webkit-scrollbar-thumb:hover {
            background: #555;
        }
        .prose p { margin-bottom: 1rem; }
        .prose ul, .prose ol { margin-left: 1.5rem; }
        .prose li { margin-bottom: 0.5rem; }
        .prose pre {
            background-color: #1f2937; /* gray-800 */
            color: #f3f4f6; /* gray-100 */
            padding: 1rem;
            border-radius: 0.5rem;
            overflow-x: auto;
        }
        .prose code {
             background-color: #e5e7eb; /* gray-200 */
             padding: 0.125rem 0.25rem;
             border-radius: 0.25rem;
             font-family: monospace;
        }
        .prose pre code {
            background-color: transparent;
            padding: 0;
        }
    </style>
</head>
<body class="bg-gray-100 dark:bg-gray-900 text-gray-900 dark:text-gray-100 flex flex-col items-center justify-center h-screen p-4">

    <div class="w-full max-w-2xl h-full flex flex-col bg-white dark:bg-gray-800 rounded-2xl shadow-2xl overflow-hidden">
        <!-- Header -->
        <header class="bg-blue-600 dark:bg-blue-700 p-4 flex items-center justify-between text-white shadow-md">
            <h1 class="text-xl font-bold">Gemini Chat</h1>
            <div class="flex items-center space-x-2">
                <span class="relative flex h-3 w-3">
                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-3 w-3 bg-green-500"></span>
                </span>
                <span>Online</span>
            </div>
        </header>

        <!-- Chat Messages -->
        <div id="chat-container" class="flex-1 p-6 overflow-y-auto">
            <!-- Messages will be injected here -->
        </div>

        <!-- Loading Indicator -->
        <div id="loading" class="hidden p-6 pt-0">
            <div class="flex items-center space-x-2">
                <div class="w-2 h-2 rounded-full bg-gray-500 animate-pulse"></div>
                <div class="w-2 h-2 rounded-full bg-gray-500 animate-pulse [animation-delay:0.2s]"></div>
                <div class="w-2 h-2 rounded-full bg-gray-500 animate-pulse [animation-delay:0.4s]"></div>
                <span class="text-sm text-gray-500 dark:text-gray-400">Gemini is thinking...</span>
            </div>
        </div>
        
        <!-- Error Display -->
        <div id="error-display" class="hidden px-6 pb-2 text-sm text-red-500"></div>

        <!-- Input Area -->
        <div class="p-4 border-t border-gray-200 dark:border-gray-700">
            <div class="relative">
                <input type="text" id="user-input" class="w-full pl-4 pr-12 py-3 bg-gray-100 dark:bg-gray-700 rounded-full focus:outline-none focus:ring-2 focus:ring-blue-500 transition duration-300" placeholder="Type your message...">
                <button id="send-button" class="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-blue-600 hover:bg-blue-700 text-white focus:outline-none focus:ring-2 focus:ring-blue-500 transition-transform duration-200 active:scale-90">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M5 13l4 4L19 7" />
                    </svg>
                </button>
            </div>
        </div>
    </div>

    <script>
        const chatContainer = document.getElementById('chat-container');
        const userInput = document.getElementById('user-input');
        const sendButton = document.getElementById('send-button');
        const loadingIndicator = document.getElementById('loading');
        const errorDisplay = document.getElementById('error-display');

        // This app is designed to run in an environment where the API key is provided.
        // For local testing, you might need to replace '' with your actual API key.
        const API_KEY = "AIzaSyDDg1BZqVWCxkl0nPj1l5s7NgIrwYxq3XE";
        const API_URL = `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash-preview-05-20:generateContent?key=${API_KEY}`;
        
        let conversationHistory = [];

        // Function to render messages to the UI
        const renderMessages = () => {
            chatContainer.innerHTML = '';
            conversationHistory.forEach(message => {
                const messageElement = document.createElement('div');
                messageElement.classList.add('mb-4', 'flex', 'flex-col');
                
                const bubble = document.createElement('div');
                bubble.classList.add('p-3', 'rounded-lg', 'max-w-xs', 'md:max-w-md', 'lg:max-w-lg', 'break-words');
                
                // Use the 'prose' class for markdown styling
                bubble.classList.add('prose', 'prose-sm', 'dark:prose-invert');
                bubble.innerHTML = marked.parse(message.parts[0].text);

                if (message.role === 'user') {
                    messageElement.classList.add('items-end');
                    bubble.classList.add('bg-blue-500', 'text-white', 'rounded-br-none');
                } else {
                    messageElement.classList.add('items-start');
                    bubble.classList.add('bg-gray-200', 'dark:bg-gray-700', 'text-gray-900', 'dark:text-gray-100', 'rounded-bl-none');
                }
                
                messageElement.appendChild(bubble);
                chatContainer.appendChild(messageElement);
            });
            chatContainer.scrollTop = chatContainer.scrollHeight;
        };

        // Function to handle API call with exponential backoff
        const callGeminiAPI = async (prompt, retries = 3, delay = 1000) => {
            loadingIndicator.classList.remove('hidden');
            errorDisplay.classList.add('hidden');
            
            try {
                const payload = {
                    contents: [...conversationHistory, { role: 'user', parts: [{ text: prompt }] }]
                };

                const response = await fetch(API_URL, {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify(payload)
                });

                if (!response.ok) {
                    const errorData = await response.json();
                    throw new Error(errorData.error ? errorData.error.message : `HTTP error! status: ${response.status}`);
                }

                const data = await response.json();
                
                if (data.candidates && data.candidates.length > 0 && data.candidates[0].content) {
                    const botMessage = data.candidates[0].content;
                    conversationHistory.push(botMessage);
                    renderMessages();
                } else {
                     // Handle cases where response might be blocked
                    const blockReason = data.promptFeedback?.blockReason;
                    let errorMessage = "I'm sorry, I can't provide a response to that.";
                    if(blockReason) {
                        errorMessage += ` (Reason: ${blockReason})`;
                    }
                    displayError(errorMessage);
                }

            } catch (error) {
                if (retries > 0) {
                    console.warn(`API call failed. Retrying in ${delay / 1000}s... (${retries} retries left)`);
                    await new Promise(res => setTimeout(res, delay));
                    return callGeminiAPI(prompt, retries - 1, delay * 2);
                } else {
                    console.error('Error calling Gemini API:', error);
                    displayError(`Failed to get a response after multiple attempts. Please check your connection or API key. Error: ${error.message}`);
                }
            } finally {
                loadingIndicator.classList.add('hidden');
            }
        };

        const displayError = (message) => {
             const botMessage = { role: 'model', parts: [{ text: `*Error:* ${message}` }] };
             conversationHistory.push(botMessage);
             renderMessages();
        };

        // Function to handle user input
        const handleUserInput = async () => {
            const prompt = userInput.value.trim();
            if (!prompt) return;

            const userMessage = { role: 'user', parts: [{ text: prompt }] };
            conversationHistory.push(userMessage);
            renderMessages();

            userInput.value = '';
            
            await callGeminiAPI(prompt);
        };

        // Event listeners
        sendButton.addEventListener('click', handleUserInput);
        userInput.addEventListener('keydown', (e) => {
            if (e.key === 'Enter') {
                e.preventDefault();
                handleUserInput();
            }
        });

        // Initial welcome message
        const addWelcomeMessage = () => {
            const welcomeMessage = {
                role: 'model',
                parts: [{ text: "Hello! I'm a chat assistant powered by Gemini. How can I help you today?" }]
            };
            conversationHistory.push(welcomeMessage);
            renderMessages();
        };

        // Start the app
        addWelcomeMessage();
    </script>
</body>
</html>

