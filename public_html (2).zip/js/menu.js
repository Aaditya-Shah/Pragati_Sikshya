document.addEventListener('DOMContentLoaded', function() {
    // Initialize variables
    const elements = {
        themeToggle: document.getElementById('theme-toggle'),
        sunIcon: document.getElementById('theme-icon-sun'),
        moonIcon: document.getElementById('theme-icon-moon'),
        sidebar: document.querySelector('.sidebar'),
        sidebarOverlay: document.querySelector('.sidebar-overlay'),
        profileMenu: document.getElementById('profile-menu'),
        profileDropdown: document.getElementById('profile-dropdown'),
        menuItems: document.querySelectorAll('.menu-item, .mobile-nav-item')
    };

    const htmlEl = document.documentElement;

    // Theme management
    function initTheme() {
        const setTheme = (theme) => {
            htmlEl.classList.toggle('dark', theme === 'dark');
            elements.sunIcon.classList.toggle('hidden', theme !== 'dark');
            elements.moonIcon.classList.toggle('hidden', theme === 'dark');
            localStorage.setItem('theme', theme);
        };

        elements.themeToggle?.addEventListener('click', () => {
            setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark');
        });

        setTheme(localStorage.getItem('theme') || 
                (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
    }

function toggleSidebar() {
    const isOpen = sidebar.classList.contains('open');
    sidebar.classList.toggle('open', !isOpen);
    sidebar.classList.toggle('closed', isOpen);
    sidebarOverlay.classList.toggle('hidden', isOpen);
    document.body.style.overflow = isOpen ? '' : 'hidden';
}

// Close sidebar when clicking outside
sidebarOverlay?.addEventListener('click', toggleSidebar);

// Profile Menu Toggle
const profileMenu = document.getElementById('profile-menu');
const profileDropdown = document.getElementById('profile-dropdown');

function toggleProfileMenu() {
    if (!profileDropdown) return;
    
    const isOpen = !profileDropdown.classList.contains('hidden');
    profileDropdown.classList.toggle('hidden', isOpen);
    
    // Close when clicking outside
    if (!isOpen) {
        const closeMenu = (e) => {
            if (!profileMenu?.contains(e.target)) {
                profileDropdown.classList.add('hidden');
                document.removeEventListener('click', closeMenu);
            }
        };
        setTimeout(() => {
            document.addEventListener('click', closeMenu);
        }, 0);
    }
}

// Dropdown Menus
function toggleDropdown(id) {
    const dropdown = document.getElementById(`dropdown-${id}`);
    if (!dropdown) return;

    const isOpen = !dropdown.classList.contains('hidden');
    
    // Close all other dropdowns first
    document.querySelectorAll('[id^="dropdown-"]').forEach(d => {
        if (d !== dropdown) d.classList.add('hidden');
    });

    // Toggle current dropdown
    dropdown.classList.toggle('hidden', isOpen);

    if (!isOpen) {
        const closeDropdown = (e) => {
            if (!dropdown.contains(e.target) && !e.target.closest(`[onclick*="toggleDropdown(${id})"]`)) {
                dropdown.classList.add('hidden');
                document.removeEventListener('click', closeDropdown);
            }
        };
        setTimeout(() => {
            document.addEventListener('click', closeDropdown);
        }, 0);
    }
}

// Close menus on window resize
window.addEventListener('resize', () => {
    if (window.innerWidth >= 1024) {
        sidebar?.classList.remove('open', 'closed');
        sidebarOverlay?.classList.add('hidden');
        document.body.style.overflow = '';
    } else {
        sidebar?.classList.add('closed');
    }
});

// Initialize mobile state
if (window.innerWidth < 1024) {
    sidebar?.classList.add('closed');
}

// Handle active menu items
document.addEventListener('DOMContentLoaded', () => {
    const currentPath = window.location.pathname;
    const menuItems = document.querySelectorAll('.menu-item, .mobile-nav-item');
    
    menuItems.forEach(item => {
        if (currentPath.endsWith(item.getAttribute('href'))) {
            item.classList.add('text-indigo-600', 'dark:text-indigo-400');
            if (item.classList.contains('menu-item')) {
                item.classList.add('bg-indigo-50', 'dark:bg-indigo-500/10');
            }
        }
    });

    // Initialize Lucide icons
    if (window.lucide) {
        lucide.createIcons();
    }
});
    localStorage.setItem('theme', theme);
};

themeToggle.addEventListener('click', () => {
    setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark');
});

// Set initial theme
setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

// Mobile Menu Toggle
const sidebar = document.querySelector('.sidebar');
const sidebarOverlay = document.querySelector('.sidebar-overlay');

function toggleSidebar() {
    const isOpen = sidebar.classList.contains('open');
    sidebar.classList.toggle('open', !isOpen);
    sidebar.classList.toggle('closed', isOpen);
    sidebarOverlay.classList.toggle('hidden', isOpen);
    document.body.style.overflow = isOpen ? '' : 'hidden';
}

// Close sidebar when clicking outside
sidebarOverlay.addEventListener('click', toggleSidebar);

// Profile Menu Toggle
const profileMenu = document.getElementById('profile-menu');
const profileDropdown = document.getElementById('profile-dropdown');

function toggleProfileMenu() {
    const isOpen = !profileDropdown.classList.contains('hidden');
    profileDropdown.classList.toggle('hidden', isOpen);
    
    // Close when clicking outside
    if (!isOpen) {
        document.addEventListener('click', closeProfileMenu);
    }
}

function closeProfileMenu(e) {
    if (!profileMenu.contains(e.target)) {
        profileDropdown.classList.add('hidden');
        document.removeEventListener('click', closeProfileMenu);
    }
}

// Close menus on window resize
window.addEventListener('resize', () => {
    if (window.innerWidth >= 1024) {
        sidebar.classList.remove('open', 'closed');
        sidebarOverlay.classList.add('hidden');
        document.body.style.overflow = '';
    } else {
        sidebar.classList.add('closed');
    }
});

// Initialize mobile state
if (window.innerWidth < 1024) {
    sidebar.classList.add('closed');
}

// Handle active menu items
document.addEventListener('DOMContentLoaded', () => {
    const currentPath = window.location.pathname;
    const menuItems = document.querySelectorAll('.sidebar-menu a');
    
    menuItems.forEach(item => {
        const itemPath = item.getAttribute('href');
        if (currentPath.endsWith(itemPath)) {
            item.classList.add('bg-gray-100', 'dark:bg-dark-bg');
            item.classList.add('text-indigo-600', 'dark:text-indigo-400');
        }
    });
});
