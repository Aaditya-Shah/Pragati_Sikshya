// Initialize icons
lucide.createIcons();

// Theme Toggle
const themeToggle = document.getElementById('theme-toggle');
const sunIcon = document.getElementById('theme-icon-sun');
const moonIcon = document.getElementById('theme-icon-moon');
const htmlEl = document.documentElement;

const setTheme = (theme) => {
    htmlEl.classList.toggle('dark', theme === 'dark');
    sunIcon.classList.toggle('hidden', theme !== 'dark');
    moonIcon.classList.toggle('hidden', theme === 'dark');
    localStorage.setItem('theme', theme);
};

themeToggle.addEventListener('click', () => {
    setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark');
});

setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

// Mobile Menu
function toggleSidebar() {
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    const body = document.body;
    
    sidebar.classList.toggle('-translate-x-full');
    overlay.classList.toggle('hidden');
    body.classList.toggle('overflow-hidden');
}

// Profile Menu
function toggleProfileMenu() {
    const menu = document.getElementById('profile-menu');
    const dropdownExists = menu.querySelector('.profile-dropdown');
    
    if (!dropdownExists) {
        const dropdown = document.createElement('div');
        dropdown.className = 'profile-dropdown';
        dropdown.innerHTML = `
            <div class="px-4 py-2 border-b dark:border-dark-border md:hidden">
                <h4 class="font-semibold">${htmlEscape(window.userName)}</h4>
                <p class="text-sm text-gray-500">${htmlEscape(window.userRole)}</p>
            </div>
            <a href="settings.php" class="flex items-center px-4 py-2 hover:bg-gray-100 dark:hover:bg-dark-bg">
                <i data-lucide="settings" class="w-4 h-4 mr-2"></i>
                Settings
            </a>
            <form action="../auth.php" method="POST" class="border-t dark:border-dark-border">
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="flex items-center w-full px-4 py-2 text-red-500 hover:bg-gray-100 dark:hover:bg-dark-bg">
                    <i data-lucide="log-out" class="w-4 h-4 mr-2"></i>
                    Logout
                </button>
            </form>
        `;
        menu.appendChild(dropdown);
        lucide.createIcons();
    } else {
        dropdownExists.remove();
    }
}

// Mobile Optimizations
function setVH() {
    let vh = window.innerHeight * 0.01;
    document.documentElement.style.setProperty('--vh', `${vh}px`);
}

// Initialize
setVH();
window.addEventListener('resize', setVH);
window.addEventListener('orientationchange', () => setTimeout(setVH, 100));

// Close menus when clicking outside
document.addEventListener('click', function(e) {
    // Close sidebar when clicking outside
    const sidebar = document.getElementById('sidebar');
    const overlay = document.getElementById('sidebar-overlay');
    if (sidebar && overlay && !sidebar.contains(e.target) && !e.target.closest('[onclick*="toggleSidebar"]')) {
        sidebar.classList.add('-translate-x-full');
        overlay.classList.add('hidden');
        document.body.classList.remove('overflow-hidden');
    }

    // Close profile dropdown when clicking outside
    const profileMenu = document.getElementById('profile-menu');
    if (profileMenu && !profileMenu.contains(e.target)) {
        const dropdown = profileMenu.querySelector('.profile-dropdown');
        if (dropdown) dropdown.remove();
    }
});

// Helper function to escape HTML
function htmlEscape(str) {
    return str
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/"/g, '&quot;')
        .replace(/'/g, '&#039;');
}

// Prevent pull-to-refresh on mobile
document.body.style.overscrollBehavior = 'contain';

// Handle touch events optimization
document.addEventListener('touchstart', function() {}, {passive: true});

// Prevent pull-to-refresh when at top of page
document.body.addEventListener('touchmove', function(e) {
    if (window.pageYOffset === 0) {
        e.preventDefault();
    }
}, { passive: false });
