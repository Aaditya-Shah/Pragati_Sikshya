<?php
require_once '../auth.php';
require_login(['Instructor']);

$instructor_id = $_SESSION['user_id'];

$stmt_stats = $pdo->prepare("SELECT (SELECT COUNT(*) FROM course_enrollments ce JOIN courses c ON ce.course_id = c.id WHERE c.instructor_id = ?) as total_students, (SELECT COUNT(*) FROM courses WHERE instructor_id = ?) as total_courses");
$stmt_stats->execute([$instructor_id, $instructor_id]);
$performance = $stmt_stats->fetch();

$stmt_courses = $pdo->prepare("SELECT c.id, c.title, (SELECT COUNT(*) FROM course_enrollments ce WHERE ce.course_id = c.id) as student_count FROM courses c WHERE c.instructor_id = ? LIMIT 5");
$stmt_courses->execute([$instructor_id]);
$courses = $stmt_courses->fetchAll();
?>
<?php require_once '../includes/header-template.php'; ?>
            <main class="p-4 md:p-8">
                <!-- Stats Grid -->
                <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-3 mb-8">
                    <!-- Total Students -->
                    <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <h4 class="text-sm font-semibold text-gray-500 dark:text-dark-text-secondary">Total Students</h4>
                                <p class="text-3xl font-bold mt-1"><?php echo $performance['total_students'] ?? 0; ?></p>
                            </div>
                            <div class="w-12 h-12 rounded-full bg-indigo-100 dark:bg-indigo-500/20 flex items-center justify-center">
                                <i data-lucide="users" class="w-6 h-6 text-indigo-600 dark:text-indigo-400"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Courses Taught -->
                    <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border p-6">
                        <div class="flex items-center justify-between">
                            <div>
                                <h4 class="text-sm font-semibold text-gray-500 dark:text-dark-text-secondary">Courses Taught</h4>
                                <p class="text-3xl font-bold mt-1"><?php echo $performance['total_courses'] ?? 0; ?></p>
                            </div>
                            <div class="w-12 h-12 rounded-full bg-indigo-100 dark:bg-indigo-500/20 flex items-center justify-center">
                                <i data-lucide="book-open" class="w-6 h-6 text-indigo-600 dark:text-indigo-400"></i>
                            </div>
                        </div>
                    </div>

                    <!-- Manage Courses Button -->
                    <a href="courses.php" 
                       class="bg-light-primary dark:bg-dark-primary text-white rounded-lg border dark:border-dark-border 
                              hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover
                              flex items-center justify-center p-6">
                        <h4 class="text-lg md:text-xl font-bold flex items-center space-x-2">
                            <i data-lucide="plus-circle" class="w-6 h-6"></i>
                            <span>Manage Courses</span>
                        </h4>
                    </a>
                </div>
                <!-- Course Overview Section -->
                <div class="space-y-6">
                    <div class="flex items-center justify-between">
                        <h3 class="text-xl font-semibold">My Courses Overview</h3>
                        <a href="courses.php" class="text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300 text-sm font-medium flex items-center space-x-1">
                            <span>View All</span>
                            <i data-lucide="chevron-right" class="w-4 h-4"></i>
                        </a>
                    </div>
                    
                    <?php if(empty($courses)): ?>
                    <!-- Empty State -->
                    <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border p-8 text-center">
                        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-100 dark:bg-indigo-500/20 mb-4">
                            <i data-lucide="book" class="w-8 h-8 text-indigo-600 dark:text-indigo-400"></i>
                        </div>
                        <h4 class="text-lg font-semibold mb-2">No Courses Yet</h4>
                        <p class="text-gray-500 dark:text-gray-400 mb-6">You haven't been assigned to any courses yet.</p>
                        <a href="../admin/courses.php" class="inline-flex items-center space-x-2 text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300">
                            <span>Contact Admin</span>
                            <i data-lucide="arrow-right" class="w-4 h-4"></i>
                        </a>
                    </div>
                    <?php else: ?>
                    <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border overflow-hidden">
                        <!-- Mobile Course List -->
                        <div class="block md:hidden">
                            <?php foreach($courses as $course): ?>
                            <div class="p-4 border-b dark:border-dark-border last:border-0">
                                <div class="flex items-start justify-between mb-2">
                                    <h4 class="font-semibold"><?php echo htmlspecialchars($course['title']); ?></h4>
                                    <div class="dropdown relative">
                                        <button class="p-2 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg">
                                            <i data-lucide="more-vertical" class="w-5 h-5"></i>
                                        </button>
                                    </div>
                                </div>
                                <div class="flex items-center text-sm text-gray-500 dark:text-gray-400 mb-3">
                                    <i data-lucide="users" class="w-4 h-4 mr-1"></i>
                                    <span><?php echo htmlspecialchars($course['student_count']); ?> Students Enrolled</span>
                                </div>
                                <div class="flex gap-2">
                                    <a href="courses.php" class="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                                        <i data-lucide="edit" class="w-4 h-4"></i>
                                        <span>Manage Course</span>
                                    </a>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        </div>

                        <!-- Desktop Course Table -->
                        <table class="hidden md:table w-full text-left">
                            <thead class="border-b dark:border-dark-border">
                                <tr>
                                    <th class="p-4 font-semibold">Course Title</th>
                                    <th class="p-4 font-semibold">Enrolled Students</th>
                                    <th class="p-4 font-semibold">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-dark-border">
                                <?php foreach($courses as $course): ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-dark-bg/50">
                                    <td class="p-4 font-semibold"><?php echo htmlspecialchars($course['title']); ?></td>
                                    <td class="p-4">
                                        <div class="flex items-center space-x-1">
                                            <i data-lucide="users" class="w-4 h-4 text-gray-500"></i>
                                            <span><?php echo htmlspecialchars($course['student_count']); ?></span>
                                        </div>
                                    </td>
                                    <td class="p-4">
                                        <a href="courses.php" class="p-2 inline-flex items-center space-x-1 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg text-gray-600 dark:text-gray-400">
                                            <i data-lucide="edit" class="w-5 h-5"></i>
                                            <span>Manage</span>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                    <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    
    <script src="https://unpkg.com/lucide@latest"></script>
    <script>
        // Initialize icons
        lucide.createIcons();

        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle');
        const sunIcon = document.getElementById('theme-icon-sun');
        const moonIcon = document.getElementById('theme-icon-moon');
        const htmlEl = document.documentElement;

        const setTheme = (theme) => {
            htmlEl.classList.toggle('dark', theme === 'dark');
            sunIcon.classList.toggle('hidden', theme !== 'dark');
            moonIcon.classList.toggle('hidden', theme === 'dark');
            localStorage.setItem('theme', theme);
        };

        themeToggle.addEventListener('click', () => {
            setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark');
        });

        // Set initial theme
        setTheme(localStorage.getItem('theme') || 
                (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        // Mobile Menu Toggle
        const sidebar = document.querySelector('.sidebar');
        const sidebarOverlay = document.querySelector('.sidebar-overlay');
        
        function toggleSidebar() {
            const isOpen = sidebar.classList.contains('open');
            sidebar.classList.toggle('open', !isOpen);
            sidebar.classList.toggle('closed', isOpen);
            sidebarOverlay.classList.toggle('hidden', isOpen);
            document.body.style.overflow = isOpen ? '' : 'hidden';
        }

        // Close sidebar when clicking overlay
        if (sidebarOverlay) {
            sidebarOverlay.addEventListener('click', toggleSidebar);
        }

        // Handle window resize
        window.addEventListener('resize', () => {
            if (window.innerWidth >= 1024) {
                sidebar.classList.remove('open', 'closed');
                sidebarOverlay.classList.add('hidden');
                document.body.style.overflow = '';
            } else {
                sidebar.classList.add('closed');
            }
        });

        // Initialize mobile state
        if (window.innerWidth < 1024) {
            sidebar.classList.add('closed');
        }

        // Dropdown Menus
        function toggleDropdown(id) {
            const dropdown = document.getElementById(`dropdown-${id}`);
            if (!dropdown) return;

            const isOpen = !dropdown.classList.contains('hidden');
            
            // Close all other dropdowns first
            document.querySelectorAll('[id^="dropdown-"]').forEach(d => {
                if (d !== dropdown) d.classList.add('hidden');
            });

            // Toggle current dropdown
            dropdown.classList.toggle('hidden', isOpen);

            if (!isOpen) {
                const closeDropdown = (e) => {
                    if (!dropdown.contains(e.target) && !e.target.closest(`[onclick*="toggleDropdown(${id})"]`)) {
                        dropdown.classList.add('hidden');
                        document.removeEventListener('click', closeDropdown);
                    }
                };
                setTimeout(() => {
                    document.addEventListener('click', closeDropdown);
                }, 0);
            }
        }

        // Profile Menu
        const profileMenu = document.getElementById('profile-menu');
        const profileDropdown = document.getElementById('profile-dropdown');

        function toggleProfileMenu() {
            if (!profileDropdown) return;
            
            const isOpen = !profileDropdown.classList.contains('hidden');
            profileDropdown.classList.toggle('hidden', isOpen);
            
            if (!isOpen) {
                const closeMenu = (e) => {
                    if (!profileMenu.contains(e.target)) {
                        profileDropdown.classList.add('hidden');
                        document.removeEventListener('click', closeMenu);
                    }
                };
                setTimeout(() => {
                    document.addEventListener('click', closeMenu);
                }, 0);
            }
        }
    </script>
</body>
</html>
