<?php
require_once '../auth.php';
require_login(['Instructor']);
require_once '../config.php'; // Ensure config.php is included for BASE_URL and $pdo

$instructor_id = $_SESSION['user_id'];

// Define upload directory for thumbnails
$upload_dir = '../uploads/thumbnails/'; // Adjust this path as needed
if (!is_dir($upload_dir)) {
    mkdir($upload_dir, 0777, true); // Create directory if it doesn't exist
}

// Function to handle file uploads
function handleFileUpload($file_input_name, $upload_dir) {
    if (isset($_FILES[$file_input_name]) && $_FILES[$file_input_name]['error'] === UPLOAD_ERR_OK) {
        $file_tmp_name = $_FILES[$file_input_name]['tmp_name'];
        $file_name = basename($_FILES[$file_input_name]['name']);
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));
        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];

        if (in_array($file_ext, $allowed_ext)) {
            $new_file_name = uniqid('thumbnail_', true) . '.' . $file_ext;
            $destination = $upload_dir . $new_file_name;

            if (move_uploaded_file($file_tmp_name, $destination)) {
                return $destination; // Return the path to the uploaded file
            } else {
                error_log("Failed to move uploaded file: " . $file_tmp_name . " to " . $destination);
                return false;
            }
        } else {
            error_log("Invalid file extension: " . $file_ext);
            return false;
        }
    }
    return null; // No file uploaded or an error occurred
}


// --- Action Handler for All Form Submissions ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Action to schedule a new LIVE class
    if ($_POST['action'] === 'schedule_class') {
        $course_id = $_POST['course_id'];
        $title = $_POST['title'];
        $class_time = $_POST['class_time'];
        $meeting_url = $_POST['meeting_url'];
        $meeting_password = $_POST['meeting_password'];
        $class_type = $_POST['class_type'];
        $thumbnail_path = handleFileUpload('thumbnail_file', $upload_dir); // Handle thumbnail upload

        if ($thumbnail_path === false) {
            $error = "Failed to upload thumbnail or invalid file type.";
        }

        if (!empty($course_id) && !empty($title) && !empty($class_time) && !empty($meeting_url) && $thumbnail_path !== false) {
            $stmt = $pdo->prepare("INSERT INTO live_classes (course_id, instructor_id, title, class_time, class_type, meeting_url, meeting_password, thumbnail_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$course_id, $instructor_id, $title, $class_time, $class_type, $meeting_url, $meeting_password, $thumbnail_path]);
            header("Location: live_class.php?success=1");
            exit;
        } else {
            $error = "Please fill all required fields for the live class and ensure thumbnail is uploaded correctly.";
        }
    }
    // Action to add a new RECORDED class
    elseif ($_POST['action'] === 'add_recorded_class') {
        $course_id = $_POST['course_id'];
        $title = $_POST['title'];
        $video_url = $_POST['video_url'];
        $description = $_POST['description'];
        $duration = $_POST['duration'];
        $video_platform = $_POST['video_platform'];
        $recording_password = $_POST['recording_password'];
        $recording_date = $_POST['recording_date'];

        $thumbnail_path = handleFileUpload('thumbnail_file', $upload_dir);
        if ($thumbnail_path === false) {
            $error_recorded = "Failed to upload thumbnail or invalid file type.";
        }

        if (!empty($course_id) && !empty($title) && !empty($video_url) && !empty($duration) && $thumbnail_path !== false) {
            $stmt = $pdo->prepare("INSERT INTO recorded_classes (course_id, instructor_id, title, video_url, description, duration, thumbnail_url, video_platform, recording_password, recording_date) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
            $stmt->execute([$course_id, $instructor_id, $title, $video_url, $description, $duration, $thumbnail_path, $video_platform, $recording_password, $recording_date]);
            header("Location: live_class.php?tab=recorded&success=1");
            exit;
        } else {
            $error_recorded = "Please fill all required fields for the recorded class and ensure thumbnail is uploaded correctly.";
        }
    }
    // Action to DELETE a class (live or recorded)
    elseif ($_POST['action'] === 'delete_class') {
        $class_id = $_POST['class_id'];
        $type = $_POST['type'];
        if ($type === 'live') {
            // Before deleting, get the thumbnail path and delete the file
            $stmt_get_thumbnail = $pdo->prepare("SELECT thumbnail_url FROM live_classes WHERE id = ? AND instructor_id = ?");
            $stmt_get_thumbnail->execute([$class_id, $instructor_id]);
            $thumbnail_data = $stmt_get_thumbnail->fetch();
            if ($thumbnail_data && !empty($thumbnail_data['thumbnail_url']) && file_exists($thumbnail_data['thumbnail_url'])) {
                unlink($thumbnail_data['thumbnail_url']); // Delete the actual file
            }
            $stmt = $pdo->prepare("DELETE FROM live_classes WHERE id = ? AND instructor_id = ?");
        } else { // type is 'recorded'
            // Before deleting, get the thumbnail path and delete the file
            $stmt_get_thumbnail = $pdo->prepare("SELECT thumbnail_url FROM recorded_classes WHERE id = ? AND instructor_id = ?");
            $stmt_get_thumbnail->execute([$class_id, $instructor_id]);
            $thumbnail_data = $stmt_get_thumbnail->fetch();
            if ($thumbnail_data && !empty($thumbnail_data['thumbnail_url']) && file_exists($thumbnail_data['thumbnail_url'])) {
                unlink($thumbnail_data['thumbnail_url']); // Delete the actual file
            }
            $stmt = $pdo->prepare("DELETE FROM recorded_classes WHERE id = ? AND instructor_id = ?");
        }
        $stmt->execute([$class_id, $instructor_id]);
        header("Location: live_class.php?tab=" . $type . "&deleted=1");
        exit;
    }
    // Action to EDIT a class (live or recorded)
    elseif ($_POST['action'] === 'edit_class') {
        $class_id = $_POST['class_id'];
        $title = $_POST['title'];
        $course_id = $_POST['course_id'];
        $type = $_POST['type'];

        if ($type === 'live') {
            $class_time = $_POST['class_time'];
            $meeting_url = $_POST['meeting_url'];
            $meeting_password = $_POST['meeting_password'];
            $class_type = $_POST['class_type'];
            $current_thumbnail_url = $_POST['current_thumbnail_url'] ?? null;
            $new_thumbnail_path = handleFileUpload('thumbnail_file', $upload_dir);
            $thumbnail_to_save = $current_thumbnail_url;

            // Check if 'remove_thumbnail' checkbox was checked
            if (isset($_POST['remove_thumbnail']) && $_POST['remove_thumbnail'] === '1') {
                if (!empty($current_thumbnail_url) && file_exists($current_thumbnail_url)) {
                    unlink($current_thumbnail_url);
                }
                $thumbnail_to_save = null; // Set thumbnail to null in DB
            } elseif ($new_thumbnail_path !== null) {
                if ($new_thumbnail_path === false) {
                    $error = "Failed to upload new thumbnail or invalid file type.";
                    $thumbnail_to_save = $current_thumbnail_url; 
                } else {
                    if (!empty($current_thumbnail_url) && file_exists($current_thumbnail_url)) {
                        unlink($current_thumbnail_url);
                    }
                    $thumbnail_to_save = $new_thumbnail_path;
                }
            }

            $stmt = $pdo->prepare("UPDATE live_classes SET title = ?, course_id = ?, class_time = ?, meeting_url = ?, meeting_password = ?, class_type = ?, thumbnail_url = ? WHERE id = ? AND instructor_id = ?");
            $stmt->execute([$title, $course_id, $class_time, $meeting_url, $meeting_password, $class_type, $thumbnail_to_save, $class_id, $instructor_id]);
        } else { // type is 'recorded'
            $video_url = $_POST['video_url'];
            $description = $_POST['description'];
            $duration = $_POST['duration'];
            $video_platform = $_POST['video_platform'];
            $recording_password = $_POST['recording_password'];
            $recording_date = $_POST['recording_date'];

            $current_thumbnail_url = $_POST['current_thumbnail_url'] ?? null;
            $new_thumbnail_path = handleFileUpload('thumbnail_file', $upload_dir);
            $thumbnail_to_save = $current_thumbnail_url;

            // Check if 'remove_thumbnail' checkbox was checked
            if (isset($_POST['remove_thumbnail']) && $_POST['remove_thumbnail'] === '1') {
                if (!empty($current_thumbnail_url) && file_exists($current_thumbnail_url)) {
                    unlink($current_thumbnail_url);
                }
                $thumbnail_to_save = null; // Set thumbnail to null in DB
            } elseif ($new_thumbnail_path !== null) {
                if ($new_thumbnail_path === false) {
                    $error_recorded = "Failed to upload new thumbnail or invalid file type.";
                    $thumbnail_to_save = $current_thumbnail_url; 
                } else {
                    if (!empty($current_thumbnail_url) && file_exists($current_thumbnail_url)) {
                        unlink($current_thumbnail_url);
                    }
                    $thumbnail_to_save = $new_thumbnail_path;
                }
            }

            $stmt = $pdo->prepare("UPDATE recorded_classes SET title = ?, course_id = ?, video_url = ?, description = ?, duration = ?, thumbnail_url = ?, video_platform = ?, recording_password = ?, recording_date = ? WHERE id = ? AND instructor_id = ?");
            $stmt->execute([$title, $course_id, $video_url, $description, $duration, $thumbnail_to_save, $video_platform, $recording_password, $recording_date, $class_id, $instructor_id]);
        }
        header("Location: live_class.php?tab=" . $type . "&updated=1");
        exit;
    }
}

// Fetch instructor's courses (works with your single instructor_id structure)
$stmt_courses = $pdo->prepare("SELECT id, title FROM courses WHERE instructor_id = ?");
$stmt_courses->execute([$instructor_id]);
$courses = $stmt_courses->fetchAll();

// Fetch upcoming live classes
$stmt_upcoming = $pdo->prepare("SELECT lc.*, c.title as course_title FROM live_classes lc JOIN courses c ON lc.course_id = c.id WHERE lc.instructor_id = ? AND lc.class_time >= NOW() ORDER BY lc.class_time ASC");
$stmt_upcoming->execute([$instructor_id]);
$upcoming_classes = $stmt_upcoming->fetchAll();

// Fetch recorded classes
$stmt_recorded = $pdo->prepare("SELECT rc.*, c.title as course_title FROM recorded_classes rc JOIN courses c ON rc.course_id = c.id WHERE rc.instructor_id = ? ORDER BY rc.created_at DESC");
$stmt_recorded->execute([$instructor_id]);
$recorded_classes = $stmt_recorded->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Classes Management - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style>
        body { font-family: 'Inter', sans-serif; }
        /* Modal styles */
        .modal-overlay {
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            display: flex;
            justify-content: center;
            align-items: center;
            z-index: 1000;
            opacity: 0;
            visibility: hidden;
            transition: opacity 0.3s ease-in-out, visibility 0.3s ease-in-out;
        }
        .modal-overlay.open {
            opacity: 1;
            visibility: visible;
        }
        .modal-content {
            background-color: white;
            padding: 2rem;
            border-radius: 0.5rem;
            max-width: 90%;
            max-height: 90%;
            overflow-y: auto;
            transform: translateY(-20px);
            transition: transform 0.3s ease-in-out;
            position: relative;
        }
        .dark .modal-content {
            background-color: #252526;
            color: #D4D4D4;
        }
        .modal-overlay.open .modal-content {
            transform: translateY(0);
        }
        .modal-close-button {
            position: absolute;
            top: 1rem;
            right: 1rem;
            background: none;
            border: none;
            font-size: 1.5rem;
            cursor: pointer;
            color: #A9A9A9;
        }
        .modal-close-button:hover {
            color: #D4D4D4;
        }
        /* Hide scrollbar for webkit browsers */
        .modal-content::-webkit-scrollbar {
            width: 0;
            background: transparent;
        }
        .modal-content {
            -ms-overflow-style: none; /* IE and Edge */
            scrollbar-width: none; /* Firefox */
        }

        /* Custom file input styling */
        .custom-file-input {
            display: flex;
            align-items: center;
            cursor: pointer;
            border: 1px solid #ccc;
            border-radius: 0.5rem;
            padding: 0.5rem 1rem;
            background-color: #f3f4f6; /* bg-gray-100 */
            color: #4b5563; /* text-gray-700 */
            transition: all 0.2s ease-in-out;
        }
        .dark .custom-file-input {
            background-color: #1E1E1E; /* dark:bg-dark-bg */
            border-color: #333333; /* dark:border-dark-border */
            color: #D4D4D4; /* dark:text-dark-text */
        }
        .custom-file-input:hover {
            background-color: #e5e7eb; /* hover:bg-gray-200 */
        }
        .dark .custom-file-input:hover {
            background-color: #252526; /* dark:hover:bg-dark-surface */
        }
        .custom-file-input input[type="file"] {
            display: none; /* Hide the actual file input */
        }
        .custom-file-input .file-button {
            background-color: #4f46e5; /* bg-light-primary */
            color: white;
            padding: 0.3rem 0.8rem;
            border-radius: 0.375rem; /* rounded-md */
            margin-right: 0.5rem;
            font-weight: 500;
            white-space: nowrap;
        }
        .dark .custom-file-input .file-button {
            background-color: #007ACC; /* dark:bg-dark-primary */
        }
        .custom-file-input .file-name {
            flex-grow: 1;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-white dark:bg-dark-surface p-6 hidden lg:flex flex-col">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10">
                <i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i>
                <span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span>
            </a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="batches.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="users-2"></i><span>My Batches</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="video"></i><span>Classes</span></a>
                <a href="mock_test.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="file-text"></i><span>Mock Tests</span></a>
                <a href="../chat/" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="message-square"></i><span>Chat</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4 flex justify-between items-center">
                <h1 class="text-2xl font-bold">Classes Management</h1>
                <div class="flex items-center space-x-4">
                    <button id="theme-toggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-bg"><i data-lucide="sun" class="hidden" id="theme-icon-sun"></i><i data-lucide="moon" class="hidden" id="theme-icon-moon"></i></button>
                    <div class="flex items-center space-x-3"><img src="<?php echo BASE_URL . htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full"><div><h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4><p class="text-sm text-gray-500">Instructor</p></div></div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <?php if (isset($error)): ?><div class="bg-red-100 text-red-700 p-3 rounded-md mb-4"><?php echo $error; ?></div><?php endif; ?>
                <?php if (isset($error_recorded)): ?><div class="bg-red-100 text-red-700 p-3 rounded-md mb-4"><?php echo $error_recorded; ?></div><?php endif; ?>
                <?php if (isset($_GET['success']) && !isset($_GET['tab'])): ?><div class="bg-green-100 text-green-700 p-3 rounded-md mb-4">Live class scheduled successfully!</div><?php endif; ?>
                <?php if (isset($_GET['success']) && isset($_GET['tab']) && $_GET['tab'] === 'recorded'): ?><div class="bg-green-100 text-green-700 p-3 rounded-md mb-4">Recorded class added successfully!</div><?php endif; ?>
                <?php if (isset($_GET['deleted'])): ?><div class="bg-red-100 text-red-700 p-3 rounded-md mb-4">Class deleted successfully!</div><?php endif; ?>
                <?php if (isset($_GET['updated'])): ?><div class="bg-blue-100 text-blue-700 p-3 rounded-md mb-4">Class updated successfully!</div><?php endif; ?>

                <div class="border-b border-gray-200 dark:border-gray-700 mb-6">
                    <nav class="-mb-px flex space-x-8" aria-label="Tabs">
                        <button onclick="switchTab('live')" class="tab-button whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm" data-tab="live">Live Classes</button>
                        <button onclick="switchTab('recorded')" class="tab-button whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm" data-tab="recorded">Recorded Classes</button>
                    </nav>
                </div>

                <!-- Live Classes Tab -->
                <div id="live-tab" class="tab-content">
                    <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div class="lg:col-span-1">
                            <h2 class="text-xl font-bold mb-4">Schedule a New Live Class</h2>
                            <div class="bg-white dark:bg-dark-surface p-6 rounded-lg border dark:border-dark-border">
                                <form action="live_class.php" method="POST" class="space-y-4" enctype="multipart/form-data">
                                    <input type="hidden" name="action" value="schedule_class">
                                    <div><label for="course_id" class="block text-sm font-medium mb-1">Course</label><select name="course_id" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required><option value="">Select a course</option><?php foreach($courses as $course): ?><option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['title']); ?></option><?php endforeach; ?></select></div>
                                    <div><label for="title" class="block text-sm font-medium mb-1">Class Title</label><input type="text" name="title" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                    <div><label for="class_time" class="block text-sm font-medium mb-1">Date & Time</label><input type="datetime-local" name="class_time" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                    <div><label for="class_type" class="block text-sm font-medium mb-1">Platform</label><select name="class_type" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required><option value="Zoom">Zoom</option><option value="Native">Native</option></select></div>
                                    <div><label for="meeting_url" class="block text-sm font-medium mb-1">Meeting URL</label><input type="url" name="meeting_url" placeholder="https://zoom.us/j/..." class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                    <div><label for="meeting_password" class="block text-sm font-medium mb-1">Meeting Password (Optional)</label><input type="text" name="meeting_password" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"></div>
                                    <div>
                                        <label for="live_thumbnail_file" class="block text-sm font-medium mb-1">Thumbnail Image (Optional)</label>
                                        <label for="live_thumbnail_file" class="custom-file-input">
                                            <span class="file-button">Choose File</span>
                                            <span class="file-name" id="live_thumbnail_file_name">No file chosen</span>
                                            <input type="file" name="thumbnail_file" id="live_thumbnail_file" accept="image/*" onchange="updateFileName(this, 'live_thumbnail_file_name')">
                                        </label>
                                    </div>
                                    <button type="submit" class="w-full bg-light-primary dark:bg-dark-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover">Schedule Class</button>
                                </form>
                            </div>
                        </div>
                        <div class="lg:col-span-2">
                            <h2 class="text-xl font-bold mb-4">Upcoming Live Classes</h2>
                            <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border overflow-hidden">
                                <div class="space-y-4 p-4">
                                    <?php if(empty($upcoming_classes)): ?>
                                        <p class="text-gray-500">No upcoming classes scheduled.</p>
                                    <?php else: ?>
                                        <?php foreach($upcoming_classes as $class): ?>
                                            <div class="p-4 border-b dark:border-dark-border last:border-b-0 flex flex-col sm:flex-row items-center sm:items-start space-y-3 sm:space-y-0 sm:space-x-4">
                                                <?php 
                                                    $liveThumbnailSrc = '';
                                                    if (!empty($class['thumbnail_url'])) {
                                                        $liveThumbnailSrc = (strpos($class['thumbnail_url'], 'http') === 0) ? 
                                                                        htmlspecialchars($class['thumbnail_url']) : 
                                                                        BASE_URL . htmlspecialchars($class['thumbnail_url']);
                                                    }
                                                ?>
                                                <div class="flex-shrink-0 w-24 h-16 bg-gray-100 dark:bg-dark-bg rounded-md overflow-hidden flex items-center justify-center">
                                                    <?php if($liveThumbnailSrc): ?>
                                                        <img src="<?php echo $liveThumbnailSrc; ?>" alt="Thumbnail" class="w-full h-full object-cover" onerror="this.onerror=null; this.src='data:image/svg+xml;utf8,<svg xmlns=\'http://www.w3.org/2000/svg\' viewBox=\'0 0 24 24\' fill=\'none\' stroke=\'currentColor\' stroke-width=\'2\' stroke-linecap=\'round\' stroke-linejoin=\'round\' class=\'lucide lucide-video w-8 h-8 text-gray-400\'><path d=\'m22 8-6 4 6 4V8Z\'/><path d=\'M14 12H2a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v6a2 2 0 0 1-2 2Z\'/></svg>'; this.classList.add('p-2');">
                                                    <?php else: ?>
                                                        <i data-lucide="video" class="w-8 h-8 text-gray-400"></i>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="flex-grow">
                                                    <p class="font-bold text-lg"><?php echo htmlspecialchars($class['title']); ?></p>
                                                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($class['course_title']); ?></p>
                                                    <p class="text-sm font-semibold text-light-primary dark:text-dark-primary mt-1"><?php echo date('D, M j, Y \a\t g:i A', strtotime($class['class_time'])); ?></p>
                                                    <p class="text-xs text-gray-400">Platform: <?php echo htmlspecialchars($class['class_type']); ?></p>
                                                    <?php if (!empty($class['meeting_password'])): ?>
                                                        <p class="text-xs text-gray-400">Password: <?php echo htmlspecialchars($class['meeting_password']); ?></p>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="flex space-x-2 mt-3 sm:mt-0 flex-shrink-0">
                                                    <a href="<?php echo htmlspecialchars($class['meeting_url']); ?>" target="_blank" class="px-4 py-1 text-sm bg-green-500 text-white rounded-full hover:bg-green-600 flex items-center"><i data-lucide="play" class="w-4 h-4 mr-1"></i> Start</a>
                                                    <button onclick="openEditLiveModal(<?php echo htmlspecialchars(json_encode($class)); ?>, <?php echo htmlspecialchars(json_encode($courses)); ?>)" class="px-3 py-1 text-sm bg-blue-500 text-white rounded-full hover:bg-blue-600 flex items-center"><i data-lucide="edit" class="w-4 h-4 mr-1"></i> Edit</button>
                                                    <button onclick="openDeleteModal(<?php echo $class['id']; ?>, 'live')" class="px-3 py-1 text-sm bg-red-500 text-white rounded-full hover:bg-red-600 flex items-center"><i data-lucide="trash-2" class="w-4 h-4 mr-1"></i> Delete</button>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Recorded Classes Tab -->
                <div id="recorded-tab" class="tab-content hidden">
                     <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                        <div class="lg:col-span-1">
                            <h2 class="text-xl font-bold mb-4">Add Recorded Class</h2>
                            <div class="bg-white dark:bg-dark-surface p-6 rounded-lg border dark:border-dark-border">
                                <form action="live_class.php?tab=recorded" method="POST" class="space-y-4" enctype="multipart/form-data">
                                    <input type="hidden" name="action" value="add_recorded_class">
                                    <div><label for="rec_course_id" class="block text-sm font-medium mb-1">Course</label><select name="course_id" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required><option value="">Select a course</option><?php foreach($courses as $course): ?><option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['title']); ?></option><?php endforeach; ?></select></div>
                                    <div><label for="rec_title" class="block text-sm font-medium mb-1">Video Title</label><input type="text" name="title" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                    <div>
                                        <label for="video_platform" class="block text-sm font-medium mb-1">Video Platform</label>
                                        <select name="video_platform" id="video_platform" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required>
                                            <option value="YouTube">YouTube</option>
                                            <option value="Zoom">Zoom Recording</option>
                                            <option value="Other">Other</option>
                                        </select>
                                    </div>
                                    <div><label for="video_url" class="block text-sm font-medium mb-1">Video URL</label><input type="url" name="video_url" placeholder="https://youtube.com/watch?v=... or https://zoom.us/rec/..." class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                    <div>
                                        <label for="thumbnail_file" class="block text-sm font-medium mb-1">Thumbnail Image</label>
                                        <label for="thumbnail_file" class="custom-file-input">
                                            <span class="file-button">Choose File</span>
                                            <span class="file-name" id="thumbnail_file_name">No file chosen</span>
                                            <input type="file" name="thumbnail_file" id="thumbnail_file" accept="image/*" required onchange="updateFileName(this, 'thumbnail_file_name')">
                                        </label>
                                    </div>
                                    <div><label for="recording_password" class="block text-sm font-medium mb-1">Recording Password (Optional)</label><input type="text" name="recording_password" id="recording_password" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"></div>
                                    <div><label for="recording_date" class="block text-sm font-medium mb-1">Recording Date</label><input type="date" name="recording_date" id="recording_date" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                    <div><label for="duration" class="block text-sm font-medium mb-1">Duration (Minutes)</label><input type="number" name="duration" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                    <div><label for="description" class="block text-sm font-medium mb-1">Description (Optional)</label><textarea name="description" rows="3" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"></textarea></div>
                                    <button type="submit" class="w-full bg-light-primary dark:bg-dark-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover">Add Recorded Class</button>
                                </form>
                            </div>
                        </div>
                        <div class="lg:col-span-2">
                            <h2 class="text-xl font-bold mb-4">My Recorded Classes</h2>
                            <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border overflow-hidden">
                                <div class="space-y-4 p-4">
                                    <?php if(empty($recorded_classes)): ?>
                                        <p class="text-gray-500">No recorded classes added yet.</p>
                                    <?php else: ?>
                                        <?php foreach($recorded_classes as $class): ?>
                                            <div class="p-4 border-b dark:border-dark-border last:border-b-0 flex flex-col sm:flex-row justify-between items-start sm:items-center">
                                                <div class="flex-grow">
                                                    <p class="font-bold text-lg"><?php echo htmlspecialchars($class['title']); ?></p>
                                                    <p class="text-sm text-gray-500"><?php echo htmlspecialchars($class['course_title']); ?></p>
                                                    <p class="text-sm text-gray-500 mt-1"><?php echo htmlspecialchars($class['duration']); ?> minutes</p>
                                                    <p class="text-xs text-gray-400">Platform: <?php echo htmlspecialchars($class['video_platform'] ?? 'N/A'); ?></p>
                                                    <?php if (!empty($class['recording_password'])): ?>
                                                        <p class="text-xs text-gray-400">Password: <?php echo htmlspecialchars($class['recording_password']); ?></p>
                                                    <?php endif; ?>
                                                    <?php if (!empty($class['recording_date'])): ?>
                                                        <p class="text-xs text-gray-400">Recorded On: <?php echo date('M j, Y', strtotime($class['recording_date'])); ?></p>
                                                    <?php endif; ?>
                                                    <?php if (!empty($class['description'])): ?>
                                                        <p class="text-xs text-gray-400 mt-1"><?php echo htmlspecialchars(substr($class['description'], 0, 100)); ?><?php echo (strlen($class['description']) > 100) ? '...' : ''; ?></p>
                                                    <?php endif; ?>
                                                </div>
                                                <div class="flex space-x-2 mt-3 sm:mt-0">
                                                    <a href="<?php echo htmlspecialchars($class['video_url']); ?>" target="_blank" class="px-4 py-1 text-sm bg-gray-500 text-white rounded-full hover:bg-gray-600 flex items-center"><i data-lucide="play-circle" class="w-4 h-4 mr-1"></i> Watch</a>
                                                    <button onclick="openEditRecordedModal(<?php echo htmlspecialchars(json_encode($class)); ?>, <?php echo htmlspecialchars(json_encode($courses)); ?>)" class="px-3 py-1 text-sm bg-blue-500 text-white rounded-full hover:bg-blue-600 flex items-center"><i data-lucide="edit" class="w-4 h-4 mr-1"></i> Edit</button>
                                                    <button onclick="openDeleteModal(<?php echo $class['id']; ?>, 'recorded')" class="px-3 py-1 text-sm bg-red-500 text-white rounded-full hover:bg-red-600 flex items-center"><i data-lucide="trash-2" class="w-4 h-4 mr-1"></i> Delete</button>
                                                </div>
                                            </div>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Edit Live Class Modal -->
    <div id="editLiveModal" class="modal-overlay hidden">
        <div class="modal-content w-full md:w-1/2 lg:w-1/3">
            <button class="modal-close-button" onclick="closeModal('editLiveModal')">&times;</button>
            <h2 class="text-xl font-bold mb-4">Edit Live Class</h2>
            <form action="live_class.php" method="POST" class="space-y-4" enctype="multipart/form-data">
                <input type="hidden" name="action" value="edit_class">
                <input type="hidden" name="type" value="live">
                <input type="hidden" name="class_id" id="edit_live_class_id">
                <input type="hidden" name="current_thumbnail_url" id="edit_live_current_thumbnail_url">
                <div><label for="edit_live_course_id" class="block text-sm font-medium mb-1">Course</label><select name="course_id" id="edit_live_course_id" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></select></div>
                <div><label for="edit_live_title" class="block text-sm font-medium mb-1">Class Title</label><input type="text" name="title" id="edit_live_title" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="edit_live_class_time" class="block text-sm font-medium mb-1">Date & Time</label><input type="datetime-local" name="class_time" id="edit_live_class_time" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="edit_live_class_type" class="block text-sm font-medium mb-1">Platform</label><select name="class_type" id="edit_live_class_type" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required><option value="Zoom">Zoom</option><option value="Native">Native</option></select></div>
                <div><label for="edit_live_meeting_url" class="block text-sm font-medium mb-1">Meeting URL</label><input type="url" name="meeting_url" id="edit_live_meeting_url" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="edit_live_meeting_password" class="block text-sm font-medium mb-1">Meeting Password (Optional)</label><input type="text" name="meeting_password" id="edit_live_meeting_password" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"></div>
                <div>
                    <label for="edit_live_thumbnail_file" class="block text-sm font-medium mb-1">Thumbnail Image (Leave blank to keep current)</label>
                    <label for="edit_live_thumbnail_file" class="custom-file-input">
                        <span class="file-button">Choose File</span>
                        <span class="file-name" id="edit_live_thumbnail_file_name">No file chosen</span>
                        <input type="file" name="thumbnail_file" id="edit_live_thumbnail_file" accept="image/*" onchange="updateFileName(this, 'edit_live_thumbnail_file_name')">
                    </label>
                    <div id="current_live_thumbnail_preview" class="mt-2 text-sm text-gray-500 dark:text-gray-400"></div>
                    <div class="mt-2 flex items-center">
                        <input type="checkbox" id="remove_live_thumbnail" name="remove_thumbnail" value="1" class="mr-2">
                        <label for="remove_live_thumbnail" class="text-sm">Remove current thumbnail</label>
                    </div>
                </div>
                <button type="submit" class="w-full bg-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-600">Save Changes</button>
            </form>
        </div>
    </div>

    <!-- Edit Recorded Class Modal -->
    <div id="editRecordedModal" class="modal-overlay hidden">
        <div class="modal-content w-full md:w-1/2 lg:w-1/3">
            <button class="modal-close-button" onclick="closeModal('editRecordedModal')">&times;</button>
            <h2 class="text-xl font-bold mb-4">Edit Recorded Class</h2>
            <form action="live_class.php" method="POST" class="space-y-4" enctype="multipart/form-data">
                <input type="hidden" name="action" value="edit_class">
                <input type="hidden" name="type" value="recorded">
                <input type="hidden" name="class_id" id="edit_recorded_class_id">
                <input type="hidden" name="current_thumbnail_url" id="edit_recorded_current_thumbnail_url">

                <div><label for="edit_recorded_course_id" class="block text-sm font-medium mb-1">Course</label><select name="course_id" id="edit_recorded_course_id" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></select></div>
                <div><label for="edit_recorded_title" class="block text-sm font-medium mb-1">Video Title</label><input type="text" name="title" id="edit_recorded_title" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div>
                    <label for="edit_recorded_video_platform" class="block text-sm font-medium mb-1">Video Platform</label>
                    <select name="video_platform" id="edit_recorded_video_platform" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required>
                        <option value="YouTube">YouTube</option>
                        <option value="Zoom">Zoom Recording</option>
                        <option value="Other">Other</option>
                    </select>
                </div>
                <div><label for="edit_recorded_video_url" class="block text-sm font-medium mb-1">Video URL</label><input type="url" name="video_url" id="edit_recorded_video_url" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div>
                    <label for="edit_recorded_thumbnail_file" class="block text-sm font-medium mb-1">Thumbnail Image (Leave blank to keep current)</label>
                    <label for="edit_recorded_thumbnail_file" class="custom-file-input">
                        <span class="file-button">Choose File</span>
                        <span class="file-name" id="edit_thumbnail_file_name">No file chosen</span>
                        <input type="file" name="thumbnail_file" id="edit_recorded_thumbnail_file" accept="image/*" onchange="updateFileName(this, 'edit_thumbnail_file_name')">
                    </label>
                    <div id="current_thumbnail_preview" class="mt-2 text-sm text-gray-500 dark:text-gray-400"></div>
                    <div class="mt-2 flex items-center">
                        <input type="checkbox" id="remove_recorded_thumbnail" name="remove_thumbnail" value="1" class="mr-2">
                        <label for="remove_recorded_thumbnail" class="text-sm">Remove current thumbnail</label>
                    </div>
                </div>
                <div><label for="edit_recorded_recording_password" class="block text-sm font-medium mb-1">Recording Password (Optional)</label><input type="text" name="recording_password" id="edit_recorded_recording_password" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"></div>
                <div><label for="edit_recorded_recording_date" class="block text-sm font-medium mb-1">Recording Date</label><input type="date" name="recording_date" id="edit_recorded_recording_date" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="edit_recorded_duration" class="block text-sm font-medium mb-1">Duration (Minutes)</label><input type="number" name="duration" id="edit_recorded_duration" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="edit_recorded_description" class="block text-sm font-medium mb-1">Description (Optional)</label><textarea name="description" id="edit_recorded_description" rows="3" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"></textarea></div>
                <button type="submit" class="w-full bg-blue-500 text-white font-bold py-3 px-6 rounded-lg hover:bg-blue-600">Save Changes</button>
            </form>
        </div>
    </div>

    <!-- Delete Confirmation Modal -->
    <div id="deleteModal" class="modal-overlay hidden">
        <div class="modal-content w-full md:w-1/3">
            <button class="modal-close-button" onclick="closeModal('deleteModal')">&times;</button>
            <h2 class="text-xl font-bold mb-4">Confirm Deletion</h2>
            <p class="mb-6">Are you sure you want to delete this class? This action cannot be undone.</p>
            <form action="live_class.php" method="POST" class="flex justify-end space-x-4">
                <input type="hidden" name="action" value="delete_class">
                <input type="hidden" name="class_id" id="delete_class_id">
                <input type="hidden" name="type" id="delete_class_type">
                <button type="button" onclick="closeModal('deleteModal')" class="px-5 py-2 rounded-lg border border-gray-300 dark:border-dark-border text-gray-700 dark:text-dark-text hover:bg-gray-100 dark:hover:bg-dark-bg">Cancel</button>
                <button type="submit" class="px-5 py-2 rounded-lg bg-red-500 text-white font-bold hover:bg-red-600">Delete</button>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();

        // Theme toggle logic
        const themeToggle = document.getElementById('theme-toggle');
        const sunIcon = document.getElementById('theme-icon-sun');
        const moonIcon = document.getElementById('theme-icon-moon');
        const htmlEl = document.documentElement;

        const setTheme = (theme) => {
            htmlEl.classList.toggle('dark', theme === 'dark');
            sunIcon.classList.toggle('hidden', theme !== 'dark');
            moonIcon.classList.toggle('hidden', theme === 'dark');
            localStorage.setItem('theme', theme);
        };

        themeToggle.addEventListener('click', () => {
            setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark');
        });

        // Set initial theme
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        // Tab switching logic
        function switchTab(tab) {
            document.querySelectorAll('.tab-content').forEach(content => content.classList.add('hidden'));
            document.getElementById(tab + '-tab').classList.remove('hidden');
            document.querySelectorAll('.tab-button').forEach(button => {
                button.classList.remove('text-light-primary', 'dark:text-dark-primary', 'border-light-primary', 'dark:border-dark-primary');
                button.classList.add('text-gray-500', 'border-transparent');
            });
            const activeButton = document.querySelector(`.tab-button[data-tab="${tab}"]`);
            activeButton.classList.add('text-light-primary', 'dark:text-dark-primary', 'border-light-primary', 'dark:border-dark-primary');
            activeButton.classList.remove('text-gray-500', 'border-transparent');
            const url = new URL(window.location);
            url.searchParams.set('tab', tab);
            window.history.pushState({}, '', url);
        }

        document.addEventListener('DOMContentLoaded', () => {
            const urlParams = new URLSearchParams(window.location.search);
            const tab = urlParams.get('tab') || 'live';
            switchTab(tab);
        });

        // Modal functions
        function openModal(modalId) {
            document.getElementById(modalId).classList.remove('hidden');
            document.getElementById(modalId).classList.add('open');
            document.body.classList.add('overflow-hidden'); // Prevent scrolling body
        }

        function closeModal(modalId) {
            document.getElementById(modalId).classList.remove('open');
            document.getElementById(modalId).classList.add('hidden');
            document.body.classList.remove('overflow-hidden'); // Restore scrolling body
        }

        // Function to update file name display for custom file input
        function updateFileName(input, targetId) {
            const fileNameSpan = document.getElementById(targetId);
            if (input.files.length > 0) {
                fileNameSpan.textContent = input.files[0].name;
            } else {
                fileNameSpan.textContent = 'No file chosen';
            }
        }

        // Populate and open Live Class Edit Modal
        function openEditLiveModal(classData, courses) {
            document.getElementById('edit_live_class_id').value = classData.id;
            document.getElementById('edit_live_title').value = classData.title;
            
            // Format datetime-local input
            const classTime = new Date(classData.class_time);
            const year = classTime.getFullYear();
            const month = (classTime.getMonth() + 1).toString().padStart(2, '0');
            const day = classTime.getDate().toString().padStart(2, '0');
            const hours = classTime.getHours().toString().padStart(2, '0');
            const minutes = classTime.getMinutes().toString().padStart(2, '0');
            document.getElementById('edit_live_class_time').value = `${year}-${month}-${day}T${hours}:${minutes}`;

            document.getElementById('edit_live_meeting_url').value = classData.meeting_url;
            document.getElementById('edit_live_meeting_password').value = classData.meeting_password;
            document.getElementById('edit_live_current_thumbnail_url').value = classData.thumbnail_url || ''; // Store current URL
            
            // Display current thumbnail preview
            const liveThumbnailPreviewDiv = document.getElementById('current_live_thumbnail_preview');
            liveThumbnailPreviewDiv.innerHTML = ''; // Clear previous content
            if (classData.thumbnail_url) {
                const img = document.createElement('img');
                img.src = classData.thumbnail_url.startsWith('http') ? classData.thumbnail_url : '<?php echo BASE_URL; ?>' + classData.thumbnail_url;
                img.alt = "Current Thumbnail";
                img.classList.add('max-w-full', 'h-24', 'object-contain', 'rounded-md', 'mt-2');
                liveThumbnailPreviewDiv.appendChild(img);
                const text = document.createElement('p');
                text.textContent = "Current Thumbnail:";
                liveThumbnailPreviewDiv.prepend(text);
                document.getElementById('remove_live_thumbnail').checked = false; // Uncheck remove on open
            } else {
                liveThumbnailPreviewDiv.textContent = "No current thumbnail.";
                document.getElementById('remove_live_thumbnail').checked = false;
            }

            // Reset file input display
            document.getElementById('edit_live_thumbnail_file_name').textContent = 'No file chosen';


            // Populate course dropdown
            const courseSelect = document.getElementById('edit_live_course_id');
            courseSelect.innerHTML = ''; // Clear existing options
            courses.forEach(course => {
                const option = document.createElement('option');
                option.value = course.id;
                option.textContent = course.title;
                if (course.id == classData.course_id) { // Use == for type coercion
                    option.selected = true;
                }
                courseSelect.appendChild(option);
            });

            // Set class type
            document.getElementById('edit_live_class_type').value = classData.class_type;

            openModal('editLiveModal');
        }

        // Populate and open Recorded Class Edit Modal
        function openEditRecordedModal(classData, courses) {
            document.getElementById('edit_recorded_class_id').value = classData.id;
            document.getElementById('edit_recorded_title').value = classData.title;
            document.getElementById('edit_recorded_video_url').value = classData.video_url;
            document.getElementById('edit_recorded_duration').value = classData.duration;
            document.getElementById('edit_recorded_description').value = classData.description;
            document.getElementById('edit_recorded_recording_password').value = classData.recording_password || '';
            document.getElementById('edit_recorded_current_thumbnail_url').value = classData.thumbnail_url || ''; // Store current URL
            document.getElementById('edit_recorded_recording_date').value = classData.recording_date || ''; // Populate recording date
            
            // Display current thumbnail preview
            const thumbnailPreviewDiv = document.getElementById('current_thumbnail_preview');
            thumbnailPreviewDiv.innerHTML = ''; // Clear previous content
            if (classData.thumbnail_url) {
                const img = document.createElement('img');
                img.src = classData.thumbnail_url.startsWith('http') ? classData.thumbnail_url : '<?php echo BASE_URL; ?>' + classData.thumbnail_url;
                img.alt = "Current Thumbnail";
                img.classList.add('max-w-full', 'h-24', 'object-contain', 'rounded-md', 'mt-2');
                thumbnailPreviewDiv.appendChild(img);
                const text = document.createElement('p');
                text.textContent = "Current Thumbnail:";
                thumbnailPreviewDiv.prepend(text);
                document.getElementById('remove_recorded_thumbnail').checked = false; // Uncheck remove on open
            } else {
                thumbnailPreviewDiv.textContent = "No current thumbnail.";
                document.getElementById('remove_recorded_thumbnail').checked = false;
            }

            // Reset file input display
            document.getElementById('edit_thumbnail_file_name').textContent = 'No file chosen';

            // Set video platform
            document.getElementById('edit_recorded_video_platform').value = classData.video_platform || 'YouTube';

            // Populate course dropdown
            const courseSelect = document.getElementById('edit_recorded_course_id');
            courseSelect.innerHTML = ''; // Clear existing options
            courses.forEach(course => {
                const option = document.createElement('option');
                option.value = course.id;
                option.textContent = course.title;
                if (course.id == classData.course_id) {
                    option.selected = true;
                }
                courseSelect.appendChild(option);
            });

            openModal('editRecordedModal');
        }

        // Open Delete Confirmation Modal
        function openDeleteModal(classId, type) {
            document.getElementById('delete_class_id').value = classId;
            document.getElementById('delete_class_type').value = type;
            openModal('deleteModal');
        }

        // Close modals when clicking outside
        document.querySelectorAll('.modal-overlay').forEach(overlay => {
            overlay.addEventListener('click', (e) => {
                if (e.target === overlay) {
                    closeModal(overlay.id);
                }
            });
        });
    </script>
</body>
</html>
