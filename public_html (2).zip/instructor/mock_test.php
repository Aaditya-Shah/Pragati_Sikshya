<?php
require_once '../auth.php';
require_login(['Instructor']);

$instructor_id = $_SESSION['user_id'];

// --- Action Handler ---
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Handle new test creation
    if ($_POST['action'] === 'create_test') {
        $course_id = $_POST['course_id'];
        $title = $_POST['title'];
        $duration = $_POST['duration_minutes'];
        $start_time = $_POST['start_time'];
        $status = $_POST['status']; // 'Draft' or 'Published'

        if (!empty($course_id) && !empty($title) && !empty($duration) && !empty($start_time)) {
            $stmt = $pdo->prepare("INSERT INTO tests (course_id, title, duration_minutes, start_time, status) VALUES (?, ?, ?, ?, ?)");
            $stmt->execute([$course_id, $title, $duration, $start_time, $status]);
            $test_id = $pdo->lastInsertId();
            header("Location: manage_questions.php?test_id=" . $test_id);
            exit;
        }
    }
    // Handle starting a test immediately
    elseif ($_POST['action'] === 'start_now') {
        $test_id = $_POST['test_id'];
        $stmt = $pdo->prepare("UPDATE tests SET start_time = NOW() WHERE id = ? AND course_id IN (SELECT id FROM courses WHERE instructor_id = ?)");
        $stmt->execute([$test_id, $instructor_id]);
    }
    // Handle ending a test immediately
    elseif ($_POST['action'] === 'end_now') {
        $test_id = $_POST['test_id'];
        // Sets start time far in the past, making the end time also in the past
        $stmt = $pdo->prepare("UPDATE tests SET start_time = DATE_SUB(NOW(), INTERVAL 2 YEAR) WHERE id = ? AND course_id IN (SELECT id FROM courses WHERE instructor_id = ?)");
        $stmt->execute([$test_id, $instructor_id]);
    }
    // Handle updating test time and duration
    elseif ($_POST['action'] === 'update_test_time') {
        $test_id = $_POST['test_id'];
        $title = $_POST['title'];
        $start_time = $_POST['start_time'];
        $duration = $_POST['duration_minutes'];
        $stmt = $pdo->prepare("UPDATE tests SET title = ?, start_time = ?, duration_minutes = ? WHERE id = ? AND course_id IN (SELECT id FROM courses WHERE instructor_id = ?)");
        $stmt->execute([$title, $start_time, $duration, $test_id, $instructor_id]);
    }
    // Handle deleting a test
    elseif ($_POST['action'] === 'delete_test') {
        $test_id = $_POST['test_id'];
        $stmt = $pdo->prepare("DELETE FROM tests WHERE id = ? AND course_id IN (SELECT id FROM courses WHERE instructor_id = ?)");
        $stmt->execute([$test_id, $instructor_id]);
    }
    header("Location: mock_test.php?success=1");
    exit;
}

// Fetch instructor's courses for the dropdown
$stmt_courses = $pdo->prepare("SELECT id, title FROM courses WHERE instructor_id = ?");
$stmt_courses->execute([$instructor_id]);
$courses = $stmt_courses->fetchAll();

// Fetch existing tests for the instructor's courses
$stmt_tests = $pdo->prepare("SELECT t.*, c.title as course_title, (SELECT COUNT(*) FROM questions WHERE test_id = t.id) as question_count FROM tests t JOIN courses c ON t.course_id = c.id WHERE c.instructor_id = ? ORDER BY t.start_time DESC");
$stmt_tests->execute([$instructor_id]);
$tests = $stmt_tests->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mock Tests - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-white dark:bg-dark-surface p-6 hidden lg:flex flex-col">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10"><i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i><span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span></a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="batches.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="users-2"></i><span>My Batches</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="mock_test.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="file-text"></i><span>Mock Tests</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4 flex justify-between items-center">
                <h1 class="text-2xl font-bold">Mock Tests</h1>
                <div class="flex items-center space-x-4">
                    <button id="theme-toggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-bg"><i data-lucide="sun" class="hidden" id="theme-icon-sun"></i><i data-lucide="moon" class="hidden" id="theme-icon-moon"></i></button>
                    <div class="flex items-center space-x-3"><img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full"><div><h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4><p class="text-sm text-gray-500">Instructor</p></div></div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <div class="flex justify-end mb-4"><button onclick="openModal('addTestModal')" class="bg-light-primary dark:bg-dark-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover flex items-center space-x-2"><i data-lucide="plus"></i><span>Create Test</span></button></div>
                <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border"><div class="space-y-2 p-4">
                    <?php if(empty($tests)): ?><p class="text-gray-500 p-4">No mock tests created yet.</p><?php else: ?><?php foreach($tests as $test): 
                        $start_timestamp = strtotime($test['start_time']);
                        $end_timestamp = $start_timestamp + ($test['duration_minutes'] * 60);
                        $is_active = (time() >= $start_timestamp && time() < $end_timestamp);
                        $is_upcoming = (time() < $start_timestamp);
                        $is_expired = (time() >= $end_timestamp);
                    ?>
                    <div class="p-4 border-b dark:border-dark-border last:border-b-0">
                        <div class="flex justify-between items-center">
                            <div>
                                <p class="font-bold text-lg flex items-center space-x-2">
                                    <span><?php echo htmlspecialchars($test['title']); ?></span>
                                    <span class="text-xs font-semibold px-2 py-0.5 rounded-full <?php echo $test['status'] === 'Published' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'; ?>"><?php echo $test['status']; ?></span>
                                    <?php if ($is_expired): ?><span class="text-xs font-semibold px-2 py-0.5 rounded-full bg-red-100 text-red-800">Expired</span><?php endif; ?>
                                </p>
                                <p class="text-sm text-gray-500"><?php echo htmlspecialchars($test['course_title']); ?></p>
                                <p class="text-xs text-gray-400 mt-1">Starts: <?php echo date('M j, Y g:i A', strtotime($test['start_time'])); ?> | Duration: <?php echo $test['duration_minutes']; ?> mins</p>
                            </div>
                            <div class="flex items-center space-x-2">
                                <?php if($is_upcoming && $test['status'] === 'Published'): ?>
                                <form action="mock_test.php" method="POST" class="inline-flex"><input type="hidden" name="action" value="start_now"><input type="hidden" name="test_id" value="<?php echo $test['id']; ?>"><button type="submit" class="p-2 rounded-md bg-green-100 text-green-700 hover:bg-green-200" title="Start Test Now"><i data-lucide="play"></i></button></form>
                                <?php endif; ?>
                                <?php if($is_active): ?>
                                <form action="mock_test.php" method="POST" class="inline-flex"><input type="hidden" name="action" value="end_now"><input type="hidden" name="test_id" value="<?php echo $test['id']; ?>"><button type="submit" class="p-2 rounded-md bg-red-100 text-red-700 hover:bg-red-200" title="End Test Now"><i data-lucide="square"></i></button></form>
                                <a href="view_results.php?test_id=<?php echo $test['id']; ?>" class="p-2 rounded-md bg-blue-100 text-blue-700 hover:bg-blue-200" title="Add Extra Time"><i data-lucide="clock"></i></a>
                                <?php endif; ?>
                                <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($test)); ?>)" class="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg" title="Edit Time/Duration"><i data-lucide="calendar-clock"></i></button>
                                <a href="manage_questions.php?test_id=<?php echo $test['id']; ?>" class="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg" title="Manage Questions"><i data-lucide="list-checks"></i></a>
                                <a href="view_results.php?test_id=<?php echo $test['id']; ?>" class="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg" title="View Results"><i data-lucide="bar-chart-2"></i></a>
                                <form action="mock_test.php" method="POST" class="inline-flex" onsubmit="return confirm('Are you sure you want to delete this test? This cannot be undone.');">
                                    <input type="hidden" name="action" value="delete_test">
                                    <input type="hidden" name="test_id" value="<?php echo $test['id']; ?>">
                                    <button type="submit" class="p-2 rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg" title="Delete Test"><i data-lucide="trash-2" class="text-red-500"></i></button>
                                </form>
                            </div>
                        </div>
                    </div>
                    <?php endforeach; ?><?php endif; ?>
                </div></div>
            </main>
        </div>
    </div>

    <!-- Add Test Modal -->
    <div id="addTestModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white dark:bg-dark-surface p-8 rounded-lg w-full max-w-md">
            <h2 class="text-2xl font-bold mb-4">Create New Mock Test</h2>
            <form id="create-test-form" action="mock_test.php" method="POST" class="space-y-4" enctype="multipart/form-data">
                <input type="hidden" name="action" value="create_test">
                <input type="hidden" name="status" id="test_status" value="Draft">
                <div><label for="course_id" class="block text-sm font-medium mb-1">Course</label><select id="course_id" name="course_id" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required><option value="">Select a course</option><?php foreach($courses as $course): ?><option value="<?php echo $course['id']; ?>"><?php echo htmlspecialchars($course['title']); ?></option><?php endforeach; ?></select></div>
                <div><label for="title" class="block text-sm font-medium mb-1">Test Title</label><input type="text" id="title" name="title" placeholder="e.g., Mid-Term Exam" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="duration_minutes" class="block text-sm font-medium mb-1">Duration (Minutes)</label><input type="number" id="duration_minutes" name="duration_minutes" value="30" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="start_time" class="block text-sm font-medium mb-1">Start Time</label><input type="datetime-local" id="start_time" name="start_time" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div class="flex justify-between space-x-2 pt-2">
                    <button type="button" onclick="setStatusAndSubmit('Draft')" class="w-1/2 bg-gray-200 dark:bg-dark-border text-black dark:text-white font-bold py-2 px-4 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-700">Save as Draft</button>
                    <button type="button" onclick="setStatusAndSubmit('Published')" class="w-1/2 bg-light-primary dark:bg-dark-primary text-white font-bold py-2 px-4 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover">Publish & Add Questions</button>
                </div>
            </form>
        </div>
    </div>
    
    <!-- Edit Test Modal -->
    <div id="editTestModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white dark:bg-dark-surface p-8 rounded-lg w-full max-w-md">
            <h2 class="text-2xl font-bold mb-4">Edit Test Time & Duration</h2>
            <form action="mock_test.php" method="POST" class="space-y-4">
                <input type="hidden" name="action" value="update_test_time">
                <input type="hidden" name="test_id" id="edit_test_id">
                <div><label for="edit_title" class="block text-sm font-medium mb-1">Test Title</label><input type="text" name="title" id="edit_title" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="edit_duration_minutes" class="block text-sm font-medium mb-1">Duration (Minutes)</label><input type="number" name="duration_minutes" id="edit_duration_minutes" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div><label for="edit_start_time" class="block text-sm font-medium mb-1">Start Time</label><input type="datetime-local" name="start_time" id="edit_start_time" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                <div class="flex justify-end space-x-4"><button type="button" onclick="closeModal('editTestModal')" class="px-4 py-2 rounded-lg border dark:border-dark-border">Cancel</button><button type="submit" class="px-4 py-2 rounded-lg bg-light-primary dark:bg-dark-primary text-white">Update Test</button></div>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        const themeToggle = document.getElementById('theme-toggle'), sunIcon = document.getElementById('theme-icon-sun'), moonIcon = document.getElementById('theme-icon-moon'), htmlEl = document.documentElement;
        const setTheme = (theme) => { htmlEl.classList.toggle('dark', theme === 'dark'); sunIcon.classList.toggle('hidden', theme !== 'dark'); moonIcon.classList.toggle('hidden', theme === 'dark'); localStorage.setItem('theme', theme); };
        themeToggle.addEventListener('click', () => setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'));
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
        
        function openModal(modalId) { document.getElementById(modalId).classList.remove('hidden'); }
        function closeModal(modalId) { document.getElementById(modalId).classList.add('hidden'); }
        
        function setStatusAndSubmit(status) {
            document.getElementById('test_status').value = status;
            document.getElementById('create-test-form').submit();
        }

        function openEditModal(test) {
            document.getElementById('edit_test_id').value = test.id;
            document.getElementById('edit_title').value = test.title;
            document.getElementById('edit_duration_minutes').value = test.duration_minutes;
            // Format datetime-local correctly
            const startTime = new Date(test.start_time.replace(' ', 'T'));
            const localISO = new Date(startTime.getTime() - (startTime.getTimezoneOffset() * 60000)).toISOString().slice(0, 16);
            document.getElementById('edit_start_time').value = localISO;
            openModal('editTestModal');
        }
    </script>
</body>
</html>
