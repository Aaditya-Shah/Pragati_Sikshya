<?php
require_once '../auth.php';
require_login(['Instructor']); // Ensure only instructors can access this page

$user_id = $_SESSION['user_id'];

// Define upload directory
// This path assumes the 'uploads' directory is one level up from the current 'settings.php' file.
// For example, if settings.php is in 'views/instructor/settings.php', then uploads_dir will be in 'uploads/avatars/'.
$upload_dir = __DIR__ . '/../uploads/avatars/';
if (!is_dir($upload_dir)) {
    // Attempt to create the directory if it doesn't exist
    // 0777 grants full permissions, consider more restrictive permissions like 0755 in production
    mkdir($upload_dir, 0777, true);
}

// Initialize error variable
$error = null;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $avatar_url = null; // Initialize avatar_url, will be updated if a new picture is uploaded

    // Handle profile picture upload
    if (isset($_FILES['profile_picture']) && $_FILES['profile_picture']['error'] === UPLOAD_ERR_OK) {
        $file_tmp_path = $_FILES['profile_picture']['tmp_name'];
        $file_name = $_FILES['profile_picture']['name'];
        $file_size = $_FILES['profile_picture']['size'];
        $file_type = $_FILES['profile_picture']['type'];
        $file_ext = strtolower(pathinfo($file_name, PATHINFO_EXTENSION));

        $allowed_ext = ['jpg', 'jpeg', 'png', 'gif'];
        $max_file_size = 5 * 1024 * 1024; // 5 MB in bytes

        if (in_array($file_ext, $allowed_ext) && $file_size <= $max_file_size) {
            // Generate a unique filename to prevent conflicts and ensure security
            $new_file_name = uniqid('avatar_') . '.' . $file_ext;
            $dest_path = $upload_dir . $new_file_name;

            if (move_uploaded_file($file_tmp_path, $dest_path)) {
                // Construct the URL path relative to the web root
                $avatar_url = '../uploads/avatars/' . $new_file_name;

                // Delete old avatar if it exists and is not a placeholder
                // This prevents accumulation of old avatar files on the server
                if (!empty($_SESSION['user_avatar']) && strpos($_SESSION['user_avatar'], 'placehold.co') === false) {
                    // Construct the absolute path to the old avatar
                    $old_avatar_path = __DIR__ . '/../' . ltrim($_SESSION['user_avatar'], '/');
                    if (file_exists($old_avatar_path)) {
                        unlink($old_avatar_path); // Delete the old file
                    }
                }
            } else {
                $error = "Failed to upload profile picture. Please try again.";
            }
        } else {
            $error = "Invalid file type or size. Allowed formats: JPG, PNG, GIF. Max size: 5MB.";
        }
    }

    // Prepare SQL query for updating user data
    $sql = "UPDATE users SET name = ?, email = ?";
    $params = [$name, $email];

    if (!empty($password)) {
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);
        $sql .= ", password = ?";
        $params[] = $hashed_password;
    }

    if ($avatar_url !== null) { // Only update avatar_url if a new one was successfully uploaded
        $sql .= ", avatar_url = ?";
        $params[] = $avatar_url;
    }

    $sql .= " WHERE id = ?";
    $params[] = $user_id;

    $stmt = $pdo->prepare($sql);
    if ($stmt->execute($params)) {
        // Update session variables to reflect the changes immediately
        $_SESSION['user_name'] = $name;
        if ($avatar_url !== null) {
            $_SESSION['user_avatar'] = $avatar_url; // Update session with new avatar URL
        }
        // Redirect to settings page with success message
        header("Location: settings.php?success=1");
        exit;
    } else {
        $error = "Failed to update profile. Database error.";
    }
}

// Get current user data for display in the form
$stmt = $pdo->prepare("SELECT name, email, avatar_url FROM users WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch(PDO::FETCH_ASSOC); // Fetch as associative array

// Set current avatar for display, with a fallback placeholder image
// This ensures that even if avatar_url is null or empty, an image is displayed.
$current_user_avatar = $user['avatar_url'] ?? 'https://placehold.co/100x100/aabbcc/ffffff?text=Avatar';
// Update session variable with the fetched avatar_url (or fallback)
// This ensures consistency across all pages that use $_SESSION['user_avatar']
$_SESSION['user_avatar'] = $current_user_avatar;
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Settings - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif']
                    },
                    colors: {
                        dark: {
                            bg: '#1E1E1E',
                            surface: '#252526',
                            border: '#333333',
                            text: '#D4D4D4',
                            'text-secondary': '#A9A9A9',
                            primary: '#007ACC',
                            'primary-hover': '#005f9e'
                        },
                        light: {
                            primary: '#4f46e5',
                            'primary-hover': '#4338ca'
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
        }

        /* Custom focus style for inputs and selects */
        input:focus,
        select:focus,
        textarea:focus {
            outline: none;
            border-color: #4f46e5;
            box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.2);
        }

        .dark input:focus,
        .dark select:focus,
        .dark textarea:focus {
            border-color: #007ACC;
            box-shadow: 0 0 0 3px rgba(0, 122, 204, 0.2);
        }

        @media (max-width: 1024px) {
            body.menu-open {
                overflow: hidden;
            }

            .mobile-menu-overlay {
                background-color: rgba(0, 0, 0, 0.5);
                backdrop-filter: blur(4px);
            }
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex min-h-screen">
        <!-- Mobile Menu Overlay -->
        <div id="menu-overlay" class="fixed inset-0 z-40 mobile-menu-overlay hidden lg:hidden" onclick="toggleMenu()"></div>

        <!-- Sidebar -->
        <aside id="mobile-menu" class="fixed inset-y-0 left-0 z-50 w-64 bg-white dark:bg-dark-surface p-6 transform -translate-x-full lg:translate-x-0 transition-transform duration-300 ease-in-out lg:relative lg:flex flex-col shadow-md dark:shadow-none">
            <div class="flex items-center justify-between mb-10">
                <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2">
                    <i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i>
                    <span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span>
                </a>
                <button class="lg:hidden p-2 -mr-2 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg" onclick="toggleMenu()">
                    <i data-lucide="x"></i>
                </button>
            </div>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="mock_test.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200"><i data-lucide="file-text"></i><span>Mock Tests</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors duration-200"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4 flex justify-between items-center sticky top-0 z-10">
                <div class="flex items-center space-x-4">
                    <button class="lg:hidden p-2 -ml-2 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg" onclick="toggleMenu()">
                        <i data-lucide="menu"></i>
                    </button>
                    <h1 class="text-2xl font-bold">Settings</h1>
                </div>
                <div class="flex items-center">
                    <button id="theme-toggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-bg transition-colors duration-200"><i data-lucide="sun" class="hidden" id="theme-icon-sun"></i><i data-lucide="moon" class="hidden" id="theme-icon-moon"></i></button>
                    <div class="relative ml-2">
                        <button id="profile-menu-button" class="flex items-center space-x-3 p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200" onclick="toggleProfileMenu()">
                            <img src="<?php echo htmlspecialchars($current_user_avatar); ?>" alt="Avatar" class="w-8 h-8 rounded-full border border-gray-200 dark:border-dark-border">
                            <div class="hidden md:block">
                                <h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
                                <p class="text-sm text-gray-500">Instructor</p>
                            </div>
                            <i data-lucide="chevron-down" class="hidden md:block w-4 h-4"></i>
                        </button>
                        <div id="profile-menu" class="absolute right-0 mt-2 w-48 py-2 bg-white dark:bg-dark-surface border dark:border-dark-border rounded-lg shadow-lg hidden">
                            <div class="px-4 py-2 border-b dark:border-dark-border md:hidden">
                                <h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4>
                                <p class="text-sm text-gray-500">Instructor</p>
                            </div>
                            <a href="settings.php" class="flex items-center space-x-2 px-4 py-2 text-sm text-gray-700 dark:text-dark-text hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200">
                                <i data-lucide="settings" class="w-4 h-4"></i>
                                <span>Settings</span>
                            </a>
                            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="border-t dark:border-dark-border mt-2">
                                <input type="hidden" name="action" value="logout">
                                <button type="submit" class="w-full flex items-center space-x-2 px-4 py-2 text-sm text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors duration-200">
                                    <i data-lucide="log-out" class="w-4 h-4"></i>
                                    <span>Logout</span>
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <div class="max-w-lg mx-auto bg-white dark:bg-dark-surface p-8 rounded-xl border dark:border-dark-border shadow-md">
                    <h2 class="text-xl font-bold mb-6">Profile Information</h2>
                    <?php if(isset($error)): ?>
                        <div class="bg-red-100 dark:bg-red-900/30 text-red-700 dark:text-red-400 p-4 rounded-lg flex items-center mb-4 shadow-sm">
                            <i data-lucide="alert-circle" class="w-5 h-5 mr-2"></i>
                            <?php echo $error; ?>
                        </div>
                    <?php endif; ?>
                    <?php if(isset($_GET['success'])): ?>
                        <div class="bg-green-100 dark:bg-green-900/30 text-green-700 dark:text-green-400 p-4 rounded-lg flex items-center mb-4 shadow-sm">
                            <i data-lucide="check-circle" class="w-5 h-5 mr-2"></i>
                            Profile updated successfully!
                        </div>
                    <?php endif; ?>
                    <form action="settings.php" method="POST" class="space-y-4" enctype="multipart/form-data">
                        <div class="flex flex-col items-center mb-6">
                            <img id="profile-avatar-preview" src="<?php echo htmlspecialchars($current_user_avatar); ?>" alt="Profile Avatar" class="w-28 h-28 rounded-full object-cover border-4 border-light-primary dark:border-dark-primary shadow-lg mb-4">
                            <label for="profile_picture" class="cursor-pointer bg-gray-200 dark:bg-dark-bg text-gray-700 dark:text-dark-text px-4 py-2 rounded-lg hover:bg-gray-300 dark:hover:bg-dark-border transition-colors duration-200 flex items-center space-x-2">
                                <i data-lucide="image" class="w-5 h-5"></i>
                                <span>Change Profile Picture</span>
                                <input type="file" name="profile_picture" id="profile_picture" accept="image/*" class="hidden">
                            </label>
                            <p class="text-xs text-gray-500 mt-2">Max 5MB (JPG, PNG, GIF)</p>
                        </div>

                        <div>
                            <label for="name" class="block text-sm font-medium mb-1">Full Name</label>
                            <input type="text" name="name" id="name" value="<?php echo htmlspecialchars($user['name']); ?>" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border focus:ring-2 focus:ring-light-primary dark:focus:ring-dark-primary transition-all duration-200" required>
                        </div>
                        <div>
                            <label for="email" class="block text-sm font-medium mb-1">Email Address</label>
                            <input type="email" name="email" id="email" value="<?php echo htmlspecialchars($user['email']); ?>" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border focus:ring-2 focus:ring-light-primary dark:focus:ring-dark-primary transition-all duration-200" required>
                        </div>
                        <div>
                            <label for="password" class="block text-sm font-medium mb-1">New Password (leave blank to keep current)</label>
                            <input type="password" name="password" id="password" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border focus:ring-2 focus:ring-light-primary dark:focus:ring-dark-primary transition-all duration-200">
                        </div>
                        <div class="pt-4">
                            <button type="submit" class="w-full bg-light-primary dark:bg-dark-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover transition-colors duration-200 shadow-lg">Save Changes</button>
                        </div>
                    </form>
                </div>
            </main>
        </div>
    </div>
    <!-- Mobile Menu Modal -->
    <div id="mobileMenu" class="fixed inset-0 bg-black bg-opacity-50 z-50 hidden">
        <div class="bg-white dark:bg-dark-surface w-64 min-h-screen ml-auto p-6 shadow-lg">
            <div class="flex justify-between items-center mb-6">
                <h3 class="text-lg font-semibold">Menu</h3>
                <button onclick="toggleMobileMenu(false)" class="p-2 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg transition-colors duration-200">
                    <i data-lucide="x" class="w-5 h-5"></i>
                </button>
            </div>
            <nav class="space-y-4">
                <a href="mock_test.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200">
                    <i data-lucide="file-text"></i><span>Mock Tests</span>
                </a>
                <a href="view_results.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200">
                    <i data-lucide="bar-chart-2"></i><span>Results</span>
                </a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg transition-colors duration-200">
                    <i data-lucide="settings"></i><span>Settings</span>
                </a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-6">
                <input type="hidden" name="action" value="logout">
                <button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10 transition-colors duration-200">
                    <i data-lucide="log-out"></i><span>Logout</span>
                </button>
            </form>
        </div>
    </div>
    <script>
        lucide.createIcons();

        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle');
        const sunIcon = document.getElementById('theme-icon-sun');
        const moonIcon = document.getElementById('theme-icon-moon');
        const htmlEl = document.documentElement;

        const setTheme = (theme) => {
            htmlEl.classList.toggle('dark', theme === 'dark');
            sunIcon.classList.toggle('hidden', theme !== 'dark');
            moonIcon.classList.toggle('hidden', theme === 'dark');
            localStorage.setItem('theme', theme);
        };

        themeToggle.addEventListener('click', () => {
            setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark');
        });

        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        // Mobile Menu
        const body = document.body;
        const menuOverlay = document.getElementById('menu-overlay');
        const mobileMenu = document.getElementById('mobile-menu');

        function toggleMenu() {
            body.classList.toggle('menu-open');
            menuOverlay.classList.toggle('hidden');
            mobileMenu.classList.toggle('-translate-x-full');
        }

        // Profile Menu
        const profileMenu = document.getElementById('profile-menu');
        const profileMenuButton = document.getElementById('profile-menu-button');
        let isProfileMenuOpen = false;

        function toggleProfileMenu() {
            isProfileMenuOpen = !isProfileMenuOpen;
            profileMenu.classList.toggle('hidden', !isProfileMenuOpen);
        }

        // Close profile menu when clicking outside
        document.addEventListener('click', (e) => {
            if (profileMenu && profileMenuButton && !profileMenuButton.contains(e.target) && !profileMenu.contains(e.target) && isProfileMenuOpen) {
                toggleProfileMenu();
            }
        });

        // Handle mobile viewport height
        function setVH() {
            let vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty('--vh', `${vh}px`);
        }

        window.addEventListener('resize', setVH);
        setVH();

        // Prevent pull-to-refresh
        document.body.style.overscrollBehavior = 'contain';

        // Profile Picture Preview
        const profilePictureInput = document.getElementById('profile_picture');
        const profileAvatarPreview = document.getElementById('profile-avatar-preview');

        if (profilePictureInput && profileAvatarPreview) {
            profilePictureInput.addEventListener('change', function(event) {
                const file = event.target.files[0];
                if (file) {
                    const reader = new FileReader();
                    reader.onload = function(e) {
                        profileAvatarPreview.src = e.target.result;
                    };
                    reader.readAsDataURL(file);
                }
            });
        }
    </script>
</body>
</html>
