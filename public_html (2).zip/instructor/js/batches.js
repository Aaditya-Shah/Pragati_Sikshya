if (!defined('SCRIPT')) die('Direct access not permitted');

// Helper function to toggle dropdown menu
function toggleDropdown(batchId) {
    const dropdown = document.getElementById(`dropdown-${batchId}`);
    if (dropdown) {
        dropdown.classList.toggle('hidden');
    }
}

// Mobile search functionality
document.getElementById('search').addEventListener('input', function(e) {
    const searchTerm = e.target.value.toLowerCase();
    const batchCards = document.querySelectorAll('.batch-card');
    const batchRows = document.querySelectorAll('.batch-row');
    
    // Filter mobile cards
    batchCards.forEach(card => {
        const batchName = card.querySelector('.batch-name').textContent.toLowerCase();
        const courseName = card.querySelector('.course-name').textContent.toLowerCase();
        card.style.display = (batchName.includes(searchTerm) || courseName.includes(searchTerm)) ? 'block' : 'none';
    });
    
    // Filter desktop rows
    batchRows.forEach(row => {
        const batchName = row.querySelector('.batch-name').textContent.toLowerCase();
        const courseName = row.querySelector('.course-name').textContent.toLowerCase();
        row.style.display = (batchName.includes(searchTerm) || courseName.includes(searchTerm)) ? 'table-row' : 'none';
    });
});

// Course filter functionality
document.getElementById('course-filter').addEventListener('change', function(e) {
    const selectedCourse = e.target.value.toLowerCase();
    const batchCards = document.querySelectorAll('.batch-card');
    const batchRows = document.querySelectorAll('.batch-row');
    
    // Filter mobile cards
    batchCards.forEach(card => {
        const courseName = card.querySelector('.course-name').textContent.toLowerCase();
        card.style.display = (!selectedCourse || courseName === selectedCourse) ? 'block' : 'none';
    });
    
    // Filter desktop rows
    batchRows.forEach(row => {
        const courseName = row.querySelector('.course-name').textContent.toLowerCase();
        row.style.display = (!selectedCourse || courseName === selectedCourse) ? 'table-row' : 'none';
    });
});
