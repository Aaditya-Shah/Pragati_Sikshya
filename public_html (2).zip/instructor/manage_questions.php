<?php
require_once '../auth.php';
require_login(['Instructor']);

if (!isset($_GET['test_id'])) {
    header("Location: mock_test.php");
    exit;
}
$test_id = $_GET['test_id'];

// Action Handler
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    // Add Question
    if ($_POST['action'] === 'add_question') {
        $question_text = $_POST['question_text'];
        $options = $_POST['options']; // This will be an array
        $correct_option = $_POST['correct_option'];
        
        $options_json = json_encode($options);
        
        $stmt = $pdo->prepare("INSERT INTO questions (test_id, question_text, options, correct_option) VALUES (?, ?, ?, ?)");
        $stmt->execute([$test_id, $question_text, $options_json, $correct_option]);
    }
    // Update Question
    elseif ($_POST['action'] === 'update_question') {
        $question_id = $_POST['question_id'];
        $question_text = $_POST['question_text'];
        $options = $_POST['options'];
        $correct_option = $_POST['correct_option'];
        $options_json = json_encode($options);

        $stmt = $pdo->prepare("UPDATE questions SET question_text = ?, options = ?, correct_option = ? WHERE id = ? AND test_id = ?");
        $stmt->execute([$question_text, $options_json, $correct_option, $question_id, $test_id]);
    }
    // Delete Question
    elseif ($_POST['action'] === 'delete_question') {
        $question_id = $_POST['question_id'];
        $stmt = $pdo->prepare("DELETE FROM questions WHERE id = ? AND test_id = ?");
        $stmt->execute([$question_id, $test_id]);
    }
    // Publish Test
    elseif ($_POST['action'] === 'publish_test') {
        $stmt = $pdo->prepare("UPDATE tests SET status = 'Published' WHERE id = ?");
        $stmt->execute([$test_id]);
    }
    header("Location: manage_questions.php?test_id=" . $test_id);
    exit;
}

// Fetch Test Details including status
$stmt_test = $pdo->prepare("SELECT title, status FROM tests WHERE id = ?");
$stmt_test->execute([$test_id]);
$test = $stmt_test->fetch();
if (!$test) { die("Test not found."); }

// Fetch Existing Questions
$stmt_questions = $pdo->prepare("SELECT * FROM questions WHERE test_id = ? ORDER BY id ASC");
$stmt_questions->execute([$test_id]);
$questions = $stmt_questions->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Questions - <?php echo htmlspecialchars($test['title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-white dark:bg-dark-surface p-6 hidden lg:flex flex-col">
             <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10"><i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i><span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span></a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="mock_test.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="file-text"></i><span>Mock Tests</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4 flex justify-between items-center">
                <div>
                    <h1 class="text-2xl font-bold">Manage Questions: <?php echo htmlspecialchars($test['title']); ?></h1>
                    <span class="text-sm font-semibold px-2 py-0.5 rounded-full <?php echo $test['status'] === 'Published' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'; ?>"><?php echo $test['status']; ?></span>
                </div>
                <div class="flex items-center space-x-4">
                    <?php if ($test['status'] === 'Draft'): ?>
                    <form action="manage_questions.php?test_id=<?php echo $test_id; ?>" method="POST">
                        <input type="hidden" name="action" value="publish_test">
                        <button type="submit" class="bg-green-500 text-white font-bold py-2 px-4 rounded-lg hover:bg-green-600 flex items-center space-x-2">
                            <i data-lucide="send"></i>
                            <span>Publish Test</span>
                        </button>
                    </form>
                    <?php endif; ?>
                    <button id="theme-toggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-bg"><i data-lucide="sun" class="hidden" id="theme-icon-sun"></i><i data-lucide="moon" class="hidden" id="theme-icon-moon"></i></button>
                    <div class="flex items-center space-x-3"><img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full"><div><h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4><p class="text-sm text-gray-500">Instructor</p></div></div>
                </div>
            </header>
            <main class="p-6 md:p-8 grid grid-cols-1 lg:grid-cols-3 gap-8">
                <div class="lg:col-span-1">
                    <h2 class="text-xl font-bold mb-4">Add New Question</h2>
                    <div class="bg-white dark:bg-dark-surface p-6 rounded-lg border dark:border-dark-border">
                        <form action="manage_questions.php?test_id=<?php echo $test_id; ?>" method="POST" class="space-y-4">
                            <input type="hidden" name="action" value="add_question">
                            <div><label for="question_editor" class="block text-sm font-medium mb-1">Question (HTML allowed)</label><textarea id="question_editor" name="question_text" rows="5" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"></textarea></div>
                            <div><label class="block text-sm font-medium mb-1">Options (Mark correct answer)</label>
                                <div class="space-y-2">
                                    <?php for ($i = 0; $i < 4; $i++): ?>
                                    <div class="flex items-center space-x-2"><input type="radio" name="correct_option" value="<?php echo $i; ?>" required class="h-4 w-4"><input type="text" name="options[]" placeholder="Option <?php echo $i + 1; ?>" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                    <?php endfor; ?>
                                </div>
                            </div>
                            <button type="submit" class="w-full bg-light-primary dark:bg-dark-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover">Add Question</button>
                        </form>
                    </div>
                </div>
                <div class="lg:col-span-2">
                    <h2 class="text-xl font-bold mb-4">Existing Questions</h2>
                    <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border p-4 space-y-4">
                        <?php if(empty($questions)): ?>
                            <p class="text-gray-500 p-4">No questions added to this test yet.</p>
                        <?php else: ?>
                            <?php foreach($questions as $index => $question): ?>
                            <div class="p-4 border-b dark:border-dark-border last:border-b-0">
                                <div class="flex justify-between items-start">
                                    <div class="prose dark:prose-invert max-w-none flex-1"><?php echo ($index + 1) . ". " . $question['question_text']; ?></div>
                                    <div class="flex items-center space-x-1">
                                        <button onclick="openEditModal(<?php echo htmlspecialchars(json_encode($question)); ?>)" class="p-1 text-gray-500 hover:text-indigo-600"><i data-lucide="edit" class="w-4 h-4"></i></button>
                                        <form action="manage_questions.php?test_id=<?php echo $test_id; ?>" method="POST" onsubmit="return confirm('Delete this question?');">
                                            <input type="hidden" name="action" value="delete_question">
                                            <input type="hidden" name="question_id" value="<?php echo $question['id']; ?>">
                                            <button type="submit" class="p-1 text-red-500 hover:text-red-700"><i data-lucide="trash-2" class="w-4 h-4"></i></button>
                                        </form>
                                    </div>
                                </div>
                                <div class="mt-2 space-y-1 pl-4">
                                    <?php 
                                    $options = json_decode($question['options'], true);
                                    foreach($options as $opt_index => $option):
                                        $is_correct = ($opt_index == $question['correct_option']);
                                    ?>
                                    <p class="text-sm <?php echo $is_correct ? 'font-bold text-green-600 dark:text-green-400' : 'text-gray-600 dark:text-dark-text-secondary'; ?>"><?php echo htmlspecialchars($option); ?> <?php echo $is_correct ? '<span class="text-xs">(Correct)</span>' : ''; ?></p>
                                    <?php endforeach; ?>
                                </div>
                            </div>
                            <?php endforeach; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </main>
        </div>
    </div>

    <!-- Edit Question Modal -->
    <div id="editQuestionModal" class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center hidden z-50">
        <div class="bg-white dark:bg-dark-surface p-8 rounded-lg w-full max-w-2xl">
            <h2 class="text-2xl font-bold mb-4">Edit Question</h2>
            <form action="manage_questions.php?test_id=<?php echo $test_id; ?>" method="POST" class="space-y-4">
                <input type="hidden" name="action" value="update_question">
                <input type="hidden" name="question_id" id="edit_question_id">
                <div><label for="edit_question_editor" class="block text-sm font-medium mb-1">Question (HTML allowed)</label><textarea id="edit_question_editor" name="question_text" rows="5" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"></textarea></div>
                <div><label class="block text-sm font-medium mb-1">Options</label>
                    <div id="edit_options_container" class="space-y-2"></div>
                </div>
                <div class="flex justify-end space-x-4"><button type="button" onclick="closeModal('editQuestionModal')" class="px-4 py-2 rounded-lg border dark:border-dark-border">Cancel</button><button type="submit" class="px-4 py-2 rounded-lg bg-light-primary dark:bg-dark-primary text-white">Save Changes</button></div>
            </form>
        </div>
    </div>

    <script>
        lucide.createIcons();
        
        const themeToggle = document.getElementById('theme-toggle'), sunIcon = document.getElementById('theme-icon-sun'), moonIcon = document.getElementById('theme-icon-moon'), htmlEl = document.documentElement;
        const setTheme = (theme) => { htmlEl.classList.toggle('dark', theme === 'dark'); sunIcon.classList.toggle('hidden', theme !== 'dark'); moonIcon.classList.toggle('hidden', theme === 'dark'); localStorage.setItem('theme', theme); };
        themeToggle.addEventListener('click', () => setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'));
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        function openModal(modalId) { document.getElementById(modalId).classList.remove('hidden'); }
        function closeModal(modalId) { document.getElementById(modalId).classList.add('hidden'); }
        
        function openEditModal(question) {
            openModal('editQuestionModal');

            document.getElementById('edit_question_id').value = question.id;
            document.getElementById('edit_question_editor').value = question.question_text;
            
            const options = JSON.parse(question.options);
            const container = document.getElementById('edit_options_container');
            container.innerHTML = '';
            options.forEach((opt, index) => {
                const checked = index == question.correct_option ? 'checked' : '';
                const div = document.createElement('div');
                div.classList.add('flex', 'items-center', 'space-x-2');
                div.innerHTML = `<input type="radio" name="correct_option" value="${index}" ${checked} required class="h-4 w-4"><input type="text" name="options[]" value="${opt}" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required>`;
                container.appendChild(div);
            });
        }
    </script>
</body>
</html>
