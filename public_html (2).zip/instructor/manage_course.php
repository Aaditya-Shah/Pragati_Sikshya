<?php
require_once '../auth.php';
require_login(['Instructor']);

if (!isset($_GET['id'])) {
    header("Location: courses.php");
    exit;
}
$course_id = $_GET['id'];
$instructor_id = $_SESSION['user_id'];

// --- ACTION HANDLER ---
// Handle course details update
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action']) && $_POST['action'] === 'update_course') {
    // First, verify this instructor is assigned to this course before updating
    $stmt_verify = $pdo->prepare("SELECT COUNT(*) FROM course_instructors WHERE course_id = ? AND instructor_id = ?");
    $stmt_verify->execute([$course_id, $instructor_id]);
    if ($stmt_verify->fetchColumn() > 0) {
        $title = $_POST['title'];
        $category = $_POST['category'];
        $description = $_POST['description'];
        $stmt = $pdo->prepare("UPDATE courses SET title = ?, category = ?, description = ? WHERE id = ?");
        $stmt->execute([$title, $category, $description, $course_id]);
        header("Location: manage_course.php?id=" . $course_id . "&success=1");
        exit;
    } else {
        die("You do not have permission to update this course.");
    }
}

// --- DATA FETCHING ---
// Verify this instructor is assigned to the course and fetch its details
$stmt_course = $pdo->prepare("
    SELECT c.* FROM courses c
    JOIN course_instructors ci ON c.id = ci.course_id
    WHERE c.id = ? AND ci.instructor_id = ?
");
$stmt_course->execute([$course_id, $instructor_id]);
$course = $stmt_course->fetch();
if (!$course) { die("Course not found or you do not have permission to manage it."); }

// Fetch enrolled students
$stmt_students = $pdo->prepare("SELECT u.name, u.email FROM users u JOIN course_enrollments ce ON u.id = ce.student_id WHERE ce.course_id = ?");
$stmt_students->execute([$course_id]);
$students = $stmt_students->fetchAll();

// Fetch tests for this course
$stmt_tests = $pdo->prepare("SELECT id, title, status, start_time, duration_minutes FROM tests WHERE course_id = ? ORDER BY start_time DESC");
$stmt_tests->execute([$course_id]);
$tests = $stmt_tests->fetchAll();
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Course: <?php echo htmlspecialchars($course['title']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = { darkMode: 'class', theme: { extend: { fontFamily: { sans: ['Inter', 'sans-serif'] }, colors: { dark: { bg: '#1E1E1E', surface: '#252526', border: '#333333', text: '#D4D4D4', 'text-secondary': '#A9A9A9', primary: '#007ACC', 'primary-hover': '#005f9e' }, light: { primary: '#4f46e5', 'primary-hover': '#4338ca' } } } } }
    </script>
    <style> body { font-family: 'Inter', sans-serif; } </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex min-h-screen">
        <aside class="w-64 bg-white dark:bg-dark-surface p-6 hidden lg:flex flex-col">
            <a href="<?php echo BASE_URL; ?>" class="flex items-center space-x-2 mb-10"><i data-lucide="graduation-cap" class="h-8 w-8 text-light-primary dark:text-dark-primary"></i><span class="text-xl font-bold"><?php echo htmlspecialchars($config['academyName']); ?></span></a>
            <nav class="space-y-2">
                <a href="index.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="layout-dashboard"></i><span>Dashboard</span></a>
                <a href="courses.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg bg-indigo-100 dark:bg-dark-primary/20 text-light-primary dark:text-dark-primary font-semibold"><i data-lucide="book-open"></i><span>My Courses</span></a>
                <a href="batches.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="users-2"></i><span>My Batches</span></a>
                <a href="live_class.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="video"></i><span>Live Classes</span></a>
                <a href="mock_test.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="file-text"></i><span>Mock Tests</span></a>
                <a href="../chat/" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="message-square"></i><span>Chat</span></a>
                <a href="settings.php" class="flex items-center space-x-3 px-4 py-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg"><i data-lucide="settings"></i><span>Settings</span></a>
            </nav>
            <form action="<?php echo BASE_URL; ?>auth.php" method="POST" class="mt-auto"><input type="hidden" name="action" value="logout"><button type="submit" class="w-full flex items-center space-x-3 px-4 py-2 rounded-lg text-red-500 hover:bg-red-50 dark:hover:bg-red-500/10"><i data-lucide="log-out"></i><span>Logout</span></button></form>
        </aside>
        <div class="flex-1">
            <header class="bg-white dark:bg-dark-surface shadow-sm p-4 flex justify-between items-center">
                <h1 class="text-2xl font-bold">Manage Course: <?php echo htmlspecialchars($course['title']); ?></h1>
                <div class="flex items-center space-x-4">
                    <button id="theme-toggle" class="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-dark-bg"><i data-lucide="sun" class="hidden" id="theme-icon-sun"></i><i data-lucide="moon" class="hidden" id="theme-icon-moon"></i></button>
                    <div class="flex items-center space-x-3"><img src="<?php echo htmlspecialchars($_SESSION['user_avatar']); ?>" alt="Avatar" class="w-10 h-10 rounded-full"><div><h4 class="font-semibold"><?php echo htmlspecialchars($_SESSION['user_name']); ?></h4><p class="text-sm text-gray-500">Instructor</p></div></div>
                </div>
            </header>
            <main class="p-6 md:p-8">
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    <div class="lg:col-span-1">
                        <h2 class="text-xl font-bold mb-4">Course Details</h2>
                        <div class="bg-white dark:bg-dark-surface p-6 rounded-lg border dark:border-dark-border">
                            <?php if(isset($_GET['success'])): ?><div class="bg-green-100 text-green-700 p-3 rounded-md mb-4">Course updated successfully!</div><?php endif; ?>
                            <form action="manage_course.php?id=<?php echo $course_id; ?>" method="POST" class="space-y-4">
                                <input type="hidden" name="action" value="update_course">
                                <div><label for="title" class="block text-sm font-medium mb-1">Course Title</label><input type="text" name="title" value="<?php echo htmlspecialchars($course['title']); ?>" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                <div><label for="category" class="block text-sm font-medium mb-1">Category</label><input type="text" name="category" value="<?php echo htmlspecialchars($course['category']); ?>" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border" required></div>
                                <div><label for="description" class="block text-sm font-medium mb-1">Description</label><textarea name="description" rows="5" class="w-full p-2 rounded-lg bg-gray-100 dark:bg-dark-bg border border-gray-300 dark:border-dark-border"><?php echo htmlspecialchars($course['description']); ?></textarea></div>
                                <button type="submit" class="w-full bg-light-primary dark:bg-dark-primary text-white font-bold py-3 px-6 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover">Save Changes</button>
                            </form>
                        </div>
                    </div>
                    <div class="lg:col-span-2 space-y-8">
                        <div>
                            <h2 class="text-xl font-bold mb-4">Mock Tests for this Course</h2>
                            <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border p-6">
                                <table class="w-full text-left">
                                    <thead class="border-b dark:border-dark-border"><tr><th class="p-4 font-semibold">Test Title</th><th class="p-4 font-semibold">Status</th><th class="p-4 font-semibold">Actions</th></tr></thead>
                                    <tbody>
                                        <?php if(empty($tests)): ?>
                                            <tr><td colspan="3" class="p-4 text-center text-gray-500">No tests created for this course yet. <a href="mock_test.php" class="text-indigo-600 hover:underline">Create one now</a>.</td></tr>
                                        <?php else: ?>
                                            <?php foreach($tests as $test): ?>
                                            <tr class="border-b dark:border-dark-border last:border-0">
                                                <td class="p-4"><div class="font-semibold"><?php echo htmlspecialchars($test['title']); ?></div><div class="text-xs text-gray-500">Starts: <?php echo date('M j, Y g:i A', strtotime($test['start_time'])); ?></div></td>
                                                <td class="p-4"><span class="text-xs font-semibold px-2 py-0.5 rounded-full <?php echo $test['status'] === 'Published' ? 'bg-green-100 text-green-800' : 'bg-gray-100 text-gray-800'; ?>"><?php echo $test['status']; ?></span></td>
                                                <td class="p-4 space-x-2">
                                                    <a href="manage_questions.php?test_id=<?php echo $test['id']; ?>" class="p-2 inline-block rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg" title="Manage Questions"><i data-lucide="edit"></i></a>
                                                    <a href="view_results.php?test_id=<?php echo $test['id']; ?>" class="p-2 inline-block rounded-md hover:bg-gray-100 dark:hover:bg-dark-bg" title="View Results"><i data-lucide="bar-chart-2"></i></a>
                                                </td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                        <div>
                            <h2 class="text-xl font-bold mb-4">Enrolled Students</h2>
                            <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border p-6">
                                <table class="w-full text-left">
                                    <thead class="border-b dark:border-dark-border"><tr><th class="p-4 font-semibold">Student Name</th><th class="p-4 font-semibold">Email</th></tr></thead>
                                    <tbody>
                                        <?php if(empty($students)): ?>
                                            <tr><td colspan="2" class="p-4 text-center text-gray-500">No students are enrolled in this course yet.</td></tr>
                                        <?php else: ?>
                                            <?php foreach($students as $student): ?>
                                            <tr class="border-b dark:border-dark-border last:border-0">
                                                <td class="p-4 font-semibold"><?php echo htmlspecialchars($student['name']); ?></td>
                                                <td class="p-4 text-gray-500"><?php echo htmlspecialchars($student['email']); ?></td>
                                            </tr>
                                            <?php endforeach; ?>
                                        <?php endif; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    </div>
    <script>
        lucide.createIcons();
        const themeToggle = document.getElementById('theme-toggle'), sunIcon = document.getElementById('theme-icon-sun'), moonIcon = document.getElementById('theme-icon-moon'), htmlEl = document.documentElement;
        const setTheme = (theme) => { htmlEl.classList.toggle('dark', theme === 'dark'); sunIcon.classList.toggle('hidden', theme !== 'dark'); moonIcon.classList.toggle('hidden', theme === 'dark'); localStorage.setItem('theme', theme); };
        themeToggle.addEventListener('click', () => setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'));
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));
    </script>
</body>
</html>
