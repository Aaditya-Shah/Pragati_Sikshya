<?php
require_once '../auth.php';
require_login(['Instructor']);

$instructor_id = $_SESSION['user_id'];

// Fetch instructor's courses with student count
$stmt_courses = $pdo->prepare("
    SELECT 
        c.id,
        c.title,
        c.category,
        (SELECT COUNT(*) FROM course_enrollments ce WHERE ce.course_id = c.id) as student_count
    FROM courses c
    WHERE c.instructor_id = ?
    ORDER BY c.title ASC
");
$stmt_courses->execute([$instructor_id]);
$courses = $stmt_courses->fetchAll();
?>
<?php require_once '../includes/header-template.php'; ?>
            <main class="p-4 md:p-8">
                <!-- Header with Action Button -->
                <div class="flex items-center justify-between mb-6">
                    <h1 class="text-2xl font-bold">My Courses</h1>
                    <a href="manage_course.php" class="flex items-center space-x-2 bg-light-primary dark:bg-dark-primary text-white px-4 py-2 rounded-lg hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover transition-colors">
                        <i data-lucide="plus" class="w-5 h-5"></i>
                        <span class="hidden sm:inline">New Course</span>
                    </a>
                </div>

                <!-- Mobile Search and Filter Bar -->
                <div class="flex flex-col md:flex-row gap-4 mb-6">
                    <div class="relative flex-1">
                        <input type="text" id="search" placeholder="Search courses..." class="w-full pl-10 pr-4 py-2 rounded-lg border border-gray-300 dark:border-dark-border bg-white dark:bg-dark-surface focus:ring-2 focus:ring-indigo-500 dark:focus:ring-dark-primary">
                        <i data-lucide="search" class="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400"></i>
                    </div>
                    <div class="flex gap-2">
                        <select id="category-filter" class="px-4 py-2 rounded-lg border border-gray-300 dark:border-dark-border bg-white dark:bg-dark-surface">
                            <option value="">All Categories</option>
                            <?php
                            $categories = array_unique(array_column($courses, 'category'));
                            foreach($categories as $category):
                            ?>
                            <option value="<?php echo htmlspecialchars($category); ?>"><?php echo htmlspecialchars($category); ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <?php if(empty($courses)): ?>
                    <!-- Empty State -->
                    <div class="text-center py-12">
                        <div class="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-100 dark:bg-dark-primary/20 mb-4">
                            <i data-lucide="book-open" class="w-8 h-8 text-indigo-600 dark:text-indigo-400"></i>
                        </div>
                        <h3 class="text-lg font-semibold mb-2">No Courses Yet</h3>
                        <p class="text-gray-500 dark:text-gray-400 mb-6">You haven't been assigned to any courses yet.</p>
                        <a href="../admin/courses.php" class="inline-flex items-center space-x-2 text-indigo-600 dark:text-indigo-400 hover:text-indigo-700 dark:hover:text-indigo-300">
                            <span>Contact Admin</span>
                            <i data-lucide="arrow-right" class="w-4 h-4"></i>
                        </a>
                    </div>
                <?php else: ?>
                    <!-- Mobile Course List -->
                    <div class="grid gap-4 md:hidden">
                        <?php foreach($courses as $course): ?>
                        <div class="bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border p-4">
                            <div class="flex items-start justify-between mb-3">
                                <h3 class="font-semibold"><?php echo htmlspecialchars($course['title']); ?></h3>
                                <div class="dropdown relative">
                                    <button class="p-2 hover:bg-gray-100 dark:hover:bg-dark-bg rounded-lg" onclick="toggleDropdown(<?php echo $course['id']; ?>)">
                                        <i data-lucide="more-vertical" class="w-5 h-5"></i>
                                    </button>
                                    <div id="dropdown-<?php echo $course['id']; ?>" class="hidden absolute right-0 mt-2 w-48 bg-white dark:bg-dark-surface rounded-lg shadow-lg border dark:border-dark-border z-10">
                                        <a href="manage_course.php?id=<?php echo $course['id']; ?>" class="flex items-center space-x-2 px-4 py-2 hover:bg-gray-100 dark:hover:bg-dark-bg">
                                            <i data-lucide="edit" class="w-4 h-4"></i>
                                            <span>Manage Course</span>
                                        </a>
                                        <a href="live_class.php" class="flex items-center space-x-2 px-4 py-2 hover:bg-gray-100 dark:hover:bg-dark-bg">
                                            <i data-lucide="video" class="w-4 h-4"></i>
                                            <span>Schedule Live Class</span>
                                        </a>
                                        <a href="mock_test.php" class="flex items-center space-x-2 px-4 py-2 hover:bg-gray-100 dark:hover:bg-dark-bg">
                                            <i data-lucide="file-text" class="w-4 h-4"></i>
                                            <span>Create Mock Test</span>
                                        </a>
                                    </div>
                                </div>
                            </div>
                            <div class="space-y-2 text-sm text-gray-500 dark:text-gray-400">
                                <p class="flex items-center space-x-2">
                                    <i data-lucide="tag" class="w-4 h-4"></i>
                                    <span><?php echo htmlspecialchars($course['category']); ?></span>
                                </p>
                                <p class="flex items-center space-x-2">
                                    <i data-lucide="users" class="w-4 h-4"></i>
                                    <span><?php echo htmlspecialchars($course['student_count']); ?> Students Enrolled</span>
                                </p>
                            </div>
                            <div class="flex gap-2 mt-4">
                                <a href="manage_course.php?id=<?php echo $course['id']; ?>" class="flex-1 flex items-center justify-center space-x-2 px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                                    <i data-lucide="edit" class="w-4 h-4"></i>
                                    <span>Manage</span>
                                </a>
                                <a href="live_class.php" class="flex items-center justify-center w-10 h-10 rounded-lg border dark:border-dark-border hover:bg-gray-100 dark:hover:bg-dark-bg">
                                    <i data-lucide="video" class="w-5 h-5"></i>
                                </a>
                                <a href="mock_test.php" class="flex items-center justify-center w-10 h-10 rounded-lg border dark:border-dark-border hover:bg-gray-100 dark:hover:bg-dark-bg">
                                    <i data-lucide="file-text" class="w-5 h-5"></i>
                                </a>
                            </div>
                        </div>
                        <?php endforeach; ?>
                    </div>

                    <!-- Desktop Table View -->
                    <div class="hidden md:block bg-white dark:bg-dark-surface rounded-lg border dark:border-dark-border overflow-hidden">
                        <table class="w-full text-left">
                            <thead class="border-b dark:border-dark-border">
                                <tr>
                                    <th class="p-4 font-semibold">Course Title</th>
                                    <th class="p-4 font-semibold">Category</th>
                                    <th class="p-4 font-semibold">Enrolled Students</th>
                                    <th class="p-4 font-semibold">Actions</th>
                                </tr>
                            </thead>
                            <tbody class="divide-y divide-gray-200 dark:divide-dark-border">
                                <?php foreach($courses as $course): ?>
                                <tr class="hover:bg-gray-50 dark:hover:bg-dark-bg/50">
                                    <td class="p-4 font-semibold"><?php echo htmlspecialchars($course['title']); ?></td>
                                    <td class="p-4">
                                        <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800 dark:bg-indigo-500/20 dark:text-indigo-300">
                                            <?php echo htmlspecialchars($course['category']); ?>
                                        </span>
                                    </td>
                                    <td class="p-4">
                                        <div class="flex items-center space-x-1">
                                            <i data-lucide="users" class="w-4 h-4 text-gray-500"></i>
                                            <span><?php echo htmlspecialchars($course['student_count']); ?></span>
                                        </div>
                                    </td>
                                    <td class="p-4">
                                        <div class="flex items-center space-x-2">
                                            <a href="manage_course.php?id=<?php echo $course['id']; ?>" class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg" title="Manage Course">
                                                <i data-lucide="edit" class="w-5 h-5 text-gray-600 dark:text-gray-400"></i>
                                            </a>
                                            <a href="live_class.php" class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg" title="Schedule Live Class">
                                                <i data-lucide="video" class="w-5 h-5 text-gray-600 dark:text-gray-400"></i>
                                            </a>
                                            <a href="mock_test.php" class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg" title="Create Mock Test">
                                                <i data-lucide="file-text" class="w-5 h-5 text-gray-600 dark:text-gray-400"></i>
                                            </a>
                                        </div>
                                    </td>
                                </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                <?php endif; ?>
                </div>
            </main>
        </div>
    </div>
    <script>
        lucide.createIcons();
        
        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle'), sunIcon = document.getElementById('theme-icon-sun'), moonIcon = document.getElementById('theme-icon-moon'), htmlEl = document.documentElement;
        const setTheme = (theme) => { htmlEl.classList.toggle('dark', theme === 'dark'); sunIcon.classList.toggle('hidden', theme !== 'dark'); moonIcon.classList.toggle('hidden', theme === 'dark'); localStorage.setItem('theme', theme); };
        themeToggle.addEventListener('click', () => setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark'));
        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        // Search and Filter Functionality
        const searchInput = document.getElementById('search');
        const categoryFilter = document.getElementById('category-filter');
        const mobileList = document.querySelector('.grid.gap-4.md\\:hidden');
        const desktopTable = document.querySelector('.hidden.md\\:block table tbody');

        function filterCourses() {
            const searchTerm = searchInput.value.toLowerCase();
            const selectedCategory = categoryFilter.value.toLowerCase();

            // Filter Mobile View
            if (mobileList) {
                const mobileCourseCards = mobileList.children;
                Array.from(mobileCourseCards).forEach(card => {
                    const title = card.querySelector('h3').textContent.toLowerCase();
                    const category = card.querySelector('[data-lucide="tag"]').nextElementSibling.textContent.toLowerCase();
                    
                    const matchesSearch = title.includes(searchTerm);
                    const matchesCategory = !selectedCategory || category === selectedCategory;
                    
                    card.style.display = matchesSearch && matchesCategory ? 'block' : 'none';
                });
            }

            // Filter Desktop View
            if (desktopTable) {
                const tableRows = desktopTable.children;
                Array.from(tableRows).forEach(row => {
                    const title = row.cells[0].textContent.toLowerCase();
                    const category = row.cells[1].textContent.toLowerCase();
                    
                    const matchesSearch = title.includes(searchTerm);
                    const matchesCategory = !selectedCategory || category === selectedCategory;
                    
                    row.style.display = matchesSearch && matchesCategory ? '' : 'none';
                });
            }
        }

        searchInput.addEventListener('input', filterCourses);
        categoryFilter.addEventListener('change', filterCourses);

        // Mobile Dropdown Toggle
        function toggleDropdown(courseId) {
            const dropdown = document.getElementById('dropdown-' + courseId);
            const allDropdowns = document.querySelectorAll('[id^="dropdown-"]');
            
            allDropdowns.forEach(d => {
                if (d.id !== 'dropdown-' + courseId) {
                    d.classList.add('hidden');
                }
            });
            
            dropdown.classList.toggle('hidden');
        }

        // Close dropdowns when clicking outside
        document.addEventListener('click', (event) => {
            if (!event.target.closest('.dropdown')) {
                const dropdowns = document.querySelectorAll('[id^="dropdown-"]');
                dropdowns.forEach(d => d.classList.add('hidden'));
            }
        });
    </script>
</body>
</html>
