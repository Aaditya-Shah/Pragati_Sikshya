<?php
require_once '../auth.php';
require_login(['Admin', 'Instructor', 'Student']);

// Get all users for the chat list, except the current user
// IMPORTANT: Fetch the avatar_url along with other user data
$stmt = $pdo->prepare("SELECT id, name, role, avatar_url FROM users WHERE id != ?");
$stmt->execute([$_SESSION['user_id']]);
$users = $stmt->fetchAll(PDO::FETCH_ASSOC); // Fetch as associative array for easier JS mapping

// Get the current user's avatar for display in the header
$current_user_avatar = $_SESSION['user_avatar'] ?? 'https://placehold.co/100x100/aabbcc/ffffff?text=Avatar';

// Prepare user data for JavaScript
$users_js = [];
foreach ($users as $user) {
    $users_js[$user['id']] = [
        'name' => htmlspecialchars($user['name']),
        'avatar_url' => htmlspecialchars($user['avatar_url'] ?? 'https://placehold.co/100x100/aabbcc/ffffff?text=Avatar')
    ];
}
// Add current user to JS data for rendering own messages
$users_js[$_SESSION['user_id']] = [
    'name' => htmlspecialchars($_SESSION['user_name']),
    'avatar_url' => htmlspecialchars($current_user_avatar)
];

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <title>Live Chat - <?php echo htmlspecialchars($config['academyName']); ?></title>
    <script src="https://cdn.tailwindcss.com"></script>
    <script src="https://unpkg.com/lucide@latest"></script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <script>
        tailwind.config = {
            darkMode: 'class',
            theme: {
                extend: {
                    fontFamily: {
                        sans: ['Inter', 'sans-serif']
                    },
                    colors: {
                        dark: {
                            bg: '#1E1E1E',
                            surface: '#252526',
                            border: '#333333',
                            text: '#D4D4D4',
                            'text-secondary': '#A9A9A9',
                            primary: '#007ACC',
                            'primary-hover': '#005f9e'
                        },
                        light: {
                            primary: '#4f46e5',
                            'primary-hover': '#4338ca'
                        }
                    }
                }
            }
        }
    </script>
    <style>
        body {
            font-family: 'Inter', sans-serif;
            height: 100vh;
            height: calc(var(--vh, 1vh) * 100);
            overflow-x: hidden;
            -webkit-overflow-scrolling: touch;
        }

        @media (max-width: 768px) {
            .contact-list {
                position: fixed; /* Ensure it's fixed for mobile slide-out */
                top: 0;
                left: 0;
                height: 100%;
                width: 80%; /* Adjust as needed */
                max-width: 320px; /* Limit width on larger mobile devices */
                transform: translateX(-100%);
                transition: transform 0.3s ease-in-out;
                box-shadow: 2px 0 5px rgba(0,0,0,0.2);
            }

            .contact-list.active {
                transform: translateX(0);
            }

            .chat-area {
                width: 100%; /* Take full width on mobile */
                transform: translateX(0);
                transition: transform 0.3s ease-in-out;
            }

            .chat-area.hidden-mobile {
                transform: translateX(100%);
            }
        }
    </style>
</head>
<body class="bg-gray-50 dark:bg-dark-bg text-gray-800 dark:text-dark-text">
    <div class="flex h-screen">
        <aside class="contact-list w-full md:w-80 bg-white dark:bg-dark-surface p-6 flex flex-col border-r dark:border-dark-border z-30">
            <div class="flex items-center justify-between mb-4">
                <h2 class="text-2xl font-bold">Contacts</h2>
                <button id="close-contacts" class="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg">
                    <i data-lucide="x" class="w-6 h-6"></i>
                </button>
            </div>
            <div class="overflow-y-auto flex-1">
                <?php foreach($users as $user): ?>
                <div class="p-3 flex items-center space-x-3 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg cursor-pointer user-contact" data-userid="<?php echo $user['id']; ?>" data-username="<?php echo htmlspecialchars($user['name']); ?>" data-useravatar="<?php echo htmlspecialchars($user['avatar_url'] ?? 'https://placehold.co/100x100/aabbcc/ffffff?text=Avatar'); ?>">
                    <img src="<?php echo htmlspecialchars($user['avatar_url'] ?? 'https://placehold.co/100x100/aabbcc/ffffff?text=Avatar'); ?>" class="w-10 h-10 rounded-full object-cover border border-gray-200 dark:border-dark-border">
                    <div>
                        <p class="font-semibold"><?php echo htmlspecialchars($user['name']); ?></p>
                        <p class="text-sm text-gray-500"><?php echo htmlspecialchars($user['role']); ?></p>
                    </div>
                </div>
                <?php endforeach; ?>
            </div>
            <a href="<?php echo BASE_URL . strtolower($_SESSION['user_role']); ?>/" class="mt-auto text-center w-full bg-gray-200 dark:bg-dark-border p-2 rounded-lg hover:bg-gray-300 dark:hover:bg-gray-700 transition-colors duration-200">Back to Dashboard</a>
        </aside>
        <div class="chat-area flex-1 flex flex-col">
            <header id="chat-header-main" class="bg-white dark:bg-dark-surface p-4 flex items-center border-b dark:border-dark-border">
                <button id="show-contacts" class="md:hidden p-2 -ml-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg mr-2">
                    <i data-lucide="menu" class="w-6 h-6"></i>
                </button>
                <div class="flex items-center space-x-3">
                    <img id="chat-partner-avatar" src="https://placehold.co/100x100/aabbcc/ffffff?text=Select" class="w-10 h-10 rounded-full object-cover border border-gray-200 dark:border-dark-border hidden">
                    <h1 id="chat-with" class="text-xl font-bold">Select a contact to start chatting</h1>
                </div>
                <button id="theme-toggle" class="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-dark-bg ml-auto">
                    <i data-lucide="sun" class="hidden" id="theme-icon-sun"></i>
                    <i data-lucide="moon" class="hidden" id="theme-icon-moon"></i>
                </button>
            </header>
            <main id="chat-box" class="flex-1 p-6 overflow-y-auto bg-gray-100 dark:bg-dark-bg">
                <!-- Messages will be loaded here -->
            </main>
            <footer class="bg-white dark:bg-dark-surface p-4 border-t dark:border-dark-border">
                <form id="chat-form" class="flex items-center space-x-2">
                    <input type="hidden" id="receiver_id" name="receiver_id">
                    <input type="text" id="message-input" name="message" class="w-full p-2 rounded-lg bg-gray-200 dark:bg-dark-border border-transparent focus:outline-none focus:ring-2 focus:ring-light-primary dark:focus:ring-dark-primary" placeholder="Type your message..." autocomplete="off" disabled>
                    <button type="submit" id="send-button" class="bg-light-primary dark:bg-dark-primary text-white p-2 rounded-full hover:bg-light-primary-hover dark:hover:bg-dark-primary-hover transition-colors duration-200" disabled><i data-lucide="send"></i></button>
                </form>
            </footer>
        </div>
    </div>
    <script>
        lucide.createIcons();
        const currentUserId = <?php echo $_SESSION['user_id']; ?>;
        // Pass PHP users data to JavaScript
        const usersData = <?php echo json_encode($users_js); ?>;

        let activeUserId = null;
        let chatInterval;

        const chatBox = document.getElementById('chat-box');
        const chatHeader = document.getElementById('chat-with');
        const chatPartnerAvatar = document.getElementById('chat-partner-avatar');
        const receiverIdInput = document.getElementById('receiver_id');
        const messageInput = document.getElementById('message-input');
        const sendButton = document.getElementById('send-button');
        const chatForm = document.getElementById('chat-form');

        document.querySelectorAll('.user-contact').forEach(contact => {
            contact.addEventListener('click', () => {
                // Remove active class from all contacts
                document.querySelectorAll('.user-contact').forEach(c => c.classList.remove('bg-gray-200', 'dark:bg-dark-border'));
                // Add active class to the clicked contact
                contact.classList.add('bg-gray-200', 'dark:bg-dark-border');

                activeUserId = contact.dataset.userid;
                const activeUserName = contact.dataset.username;
                const activeUserAvatar = contact.dataset.useravatar;

                chatHeader.textContent = activeUserName;
                chatPartnerAvatar.src = activeUserAvatar;
                chatPartnerAvatar.classList.remove('hidden'); // Show avatar in header

                receiverIdInput.value = activeUserId;
                messageInput.disabled = false;
                sendButton.disabled = false;
                loadMessages();
                if (chatInterval) clearInterval(chatInterval);
                chatInterval = setInterval(loadMessages, 3000); // Poll every 3 seconds

                // On mobile, hide contacts list and show chat area
                if (window.innerWidth < 768) {
                    hideContacts();
                }
            });
        });

        async function loadMessages() {
            if (!activeUserId) return;
            const response = await fetch(`chat_handler.php?action=get_messages&receiver_id=${activeUserId}`);
            const messages = await response.json();
            chatBox.innerHTML = ''; // Clear existing messages

            messages.forEach(msg => {
                const isCurrentUser = (msg.sender_id == currentUserId);
                const senderData = usersData[msg.sender_id];
                const senderAvatar = senderData ? senderData.avatar_url : 'https://placehold.co/100x100/aabbcc/ffffff?text=User'; // Fallback

                const messageContainer = document.createElement('div');
                messageContainer.classList.add('flex', 'items-end', 'mb-4', isCurrentUser ? 'justify-end' : '');

                // Avatar for received messages
                if (!isCurrentUser) {
                    const avatarImg = document.createElement('img');
                    avatarImg.src = senderAvatar;
                    avatarImg.alt = 'Avatar';
                    avatarImg.classList.add('w-8', 'h-8', 'rounded-full', 'object-cover', 'border', 'border-gray-200', 'dark:border-dark-border', 'mr-2');
                    messageContainer.appendChild(avatarImg);
                }

                const messageBubble = document.createElement('div');
                messageBubble.classList.add('p-3', 'rounded-lg', 'max-w-xs');
                if (isCurrentUser) {
                    messageBubble.classList.add('bg-light-primary', 'dark:bg-dark-primary', 'text-white');
                } else {
                    messageBubble.classList.add('bg-white', 'dark:bg-dark-surface', 'text-gray-800', 'dark:text-dark-text', 'border', 'dark:border-dark-border');
                }
                messageBubble.textContent = msg.message;
                messageContainer.appendChild(messageBubble);

                // Avatar for sent messages (optional, but good for consistency)
                if (isCurrentUser) {
                     const avatarImg = document.createElement('img');
                    avatarImg.src = senderAvatar;
                    avatarImg.alt = 'Avatar';
                    avatarImg.classList.add('w-8', 'h-8', 'rounded-full', 'object-cover', 'border', 'border-gray-200', 'dark:border-dark-border', 'ml-2');
                    messageContainer.appendChild(avatarImg);
                }

                chatBox.appendChild(messageContainer);
            });
            chatBox.scrollTop = chatBox.scrollHeight; // Scroll to bottom
        }

        chatForm.addEventListener('submit', async (e) => {
            e.preventDefault();
            if (!messageInput.value.trim()) return;

            const formData = new FormData(chatForm);
            formData.append('action', 'send_message');

            await fetch('chat_handler.php', {
                method: 'POST',
                body: formData
            });

            messageInput.value = ''; // Clear input field
            loadMessages(); // Reload messages to show the sent message
        });

        // Mobile navigation
        const showContactsBtn = document.getElementById('show-contacts');
        const closeContactsBtn = document.getElementById('close-contacts');
        const contactList = document.querySelector('.contact-list');
        const chatArea = document.querySelector('.chat-area');

        function showContacts() {
            contactList.classList.add('active');
            chatArea.classList.add('hidden-mobile');
        }

        function hideContacts() {
            contactList.classList.remove('active');
            chatArea.classList.remove('hidden-mobile');
        }

        showContactsBtn.addEventListener('click', showContacts);
        closeContactsBtn.addEventListener('click', hideContacts);

        // Theme Toggle
        const themeToggle = document.getElementById('theme-toggle');
        const sunIcon = document.getElementById('theme-icon-sun');
        const moonIcon = document.getElementById('theme-icon-moon');
        const htmlEl = document.documentElement;

        const setTheme = (theme) => {
            htmlEl.classList.toggle('dark', theme === 'dark');
            sunIcon.classList.toggle('hidden', theme !== 'dark');
            moonIcon.classList.toggle('hidden', theme === 'dark');
            localStorage.setItem('theme', theme);
        };

        themeToggle.addEventListener('click', () => {
            setTheme(localStorage.getItem('theme') === 'dark' ? 'light' : 'dark');
        });

        setTheme(localStorage.getItem('theme') || (window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light'));

        // Mobile Optimizations
        function setVH() {
            let vh = window.innerHeight * 0.01;
            document.documentElement.style.setProperty('--vh', `${vh}px`);
        }

        setVH();
        window.addEventListener('resize', setVH);
        window.addEventListener('orientationchange', () => setTimeout(setVH, 100));

        // Prevent pull-to-refresh
        document.body.style.overscrollBehavior = 'contain';
    </script>
</body>
</html>
