<?php
require_once '../auth.php';
require_login(['Admin', 'Instructor', 'Student']);

header('Content-Type: application/json');

$action = $_REQUEST['action'] ?? null;
$current_user_id = $_SESSION['user_id'];

if ($action === 'get_messages' && isset($_GET['receiver_id'])) {
    $receiver_id = $_GET['receiver_id'];
    $stmt = $pdo->prepare("
        SELECT * FROM chat_messages 
        WHERE (sender_id = ? AND receiver_id = ?) OR (sender_id = ? AND receiver_id = ?)
        ORDER BY sent_at ASC
    ");
    $stmt->execute([$current_user_id, $receiver_id, $receiver_id, $current_user_id]);
    $messages = $stmt->fetchAll();
    echo json_encode($messages);
    exit;
}

if ($action === 'send_message' && isset($_POST['receiver_id']) && isset($_POST['message'])) {
    $receiver_id = $_POST['receiver_id'];
    $message = trim($_POST['message']);
    if (!empty($message)) {
        $stmt = $pdo->prepare("INSERT INTO chat_messages (sender_id, receiver_id, message) VALUES (?, ?, ?)");
        $stmt->execute([$current_user_id, $receiver_id, $message]);
        echo json_encode(['status' => 'success']);
    } else {
        echo json_encode(['status' => 'error', 'message' => 'Message cannot be empty.']);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'Invalid action.']);
?>
